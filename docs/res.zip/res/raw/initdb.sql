//用户表
CREATE TABLE IF NOT EXISTS tuser (_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id VARCHAR, user_name VARCHAR, user_photo VARCHAR, password VARCHAR, token VARCHAR,
    hj_credit FLOAT, hj_currency FLOAT, hj_learned_class_num INTEGER, hj_total_class_num INTEGER, punch_time TIMESTAMP, last_login_time TIMESTAMP, interface_type INTEGER);

//班级表
CREATE TABLE IF NOT EXISTS tclass (_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id VARCHAR, class_id INTEGER, class_kind INTEGER, class_name VARCHAR, class_short_name VARCHAR, class_midle_icon_url VARCHAR,
    class_big_icon_url VARCHAR, class_origin_price VARCHAR, class_now_price VARCHAR,
    teacher_name VARCHAR, class_summery VARCHAR, score INTEGER, punchable INTEGER,  punch_time TIMESTAMP, lesson_num INTEGER, study_num INTEGER,
     ensure_pass INTEGER, ensure_pass_user INTEGER, class_type INTEGER, clearance_type INTEGER,
    class_open_time TIMESTAMP, class_end_time TIMESTAMP, class_valid_date INTEGER, long_time_class, class_key varchar, new_downloads INTEGER DEFAULT 0);

//班级最后播放记录标
CREATE TABLE IF NOT EXISTS tclass_record(_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id VARCHAR, class_id INTEGER,
        last_study_id INTEGER, last_study_num INTEGER, last_study_name VARCHAR, last_study_time VARCHAR);


//单元信息表
CREATE TABLE IF NOT EXISTS tclass_unit (_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id VARCHAR, class_id INTEGER,
    unit_id INTEGER, unit_name VARCHAR, unit_study_progress DOUBLE, unit_last_lesson_id VARCHAR,
    unit_last_lesson_num VARCHAR, unit_last_lesson_name VARCHAR, unit_num INTEGER, download_prompt_status VARCHAR);

//课程信息表
CREATE TABLE IF NOT EXISTS tlesson_info (_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id VARCHAR,
    class_id INTEGER, unit_id INTEGER, lesson_id INTEGER, lesson_name VARCHAR, lesson_score DOUBLE,
    lesson_correct_rate DOUBLE, lesson_study_time INTEGER, lesson_play_time VARCHAR,
    lesson_download_path VARCHAR, isonline_play INTEGER, lesson_type INTEGER, media_type INTEGER,
    is_study INTEGER, is_lock INTEGER, is_clearance_lock INTEGER, is_draft INTEGER,
    lesson_version INTEGER, lesson_num INTEGER, download_prompt_status VARCHAR
    );



//选课中心
CREATE TABLE IF NOT EXISTS tclass_center (_id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER,
    class_name VARCHAR, class_short_name VARCHAR, class_midle_icon_url VARCHAR,
    class_big_icon_url VARCHAR, class_origin_price VARCHAR, class_now_price VARCHAR,
    classification_id INTEGER, teacher_name VARCHAR, class_summery VARCHAR, total_lesson_num INTEGER,
    class_open_time TIMESTAMP, class_end_time TIMESTAMP, class_valid_date INTEGER, promotion_img_url VARCHAR,
    opening INTEGER, class_key VARCHAR, long_time_class INTEGER);


//课程类别
CREATE TABLE IF NOT EXISTS tclass_type (_id INTEGER PRIMARY KEY AUTOINCREMENT, classification_id INTEGER,
    classification_name VARCHAR, type INTEGER, parent_code INTEGER);

//下载中心列表
CREATE TABLE IF NOT EXISTS tdownload (_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id VARCHAR NOT NULL,
						class_id 		VARCHAR NOT NULL,
						lesson_id		VARCHAR NOT NULL,
						class_name		VARCHAR NOT NULL,
						class_key       VARCHAR,
						lesson_version INTEGER,
						islock          INTEGER,
						lesson_name		VARCHAR NOT NULL,
						download_url		VARCHAR,
						download_status 	INTEGER DEFAULT 0,
						file_size       VARCHAR,
						downloaded_size   VARCHAR,
						error_code   INTEGER DEFAULT 0,
						add_time			TIMESTAMP,
						prompted    INTEGER DEFAULT 0
						);


//学习记录表
CREATE TABLE IF NOT EXISTS tstudy_record (_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id VARCHAR NOT NULL,
						class_id 		VARCHAR,
						lesson_id		VARCHAR NOT NULL,
						study_score		VARCHAR,
						study_sign		INTEGER,
						study_time		VARCHAR DEFAULT '0',
						play_position 	VARCHAR DEFAULT '0',
			            study_record    TEXT
						);

//离线同步数据
CREATE TABLE IF NOT EXISTS toffline_synce (_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id VARCHAR NOT NULL,
						url 		VARCHAR NOT NULL,
						post_data		TEXT,
						callback_class		VARCHAR,
						callback_method		VARCHAR,
						add_time			TIMESTAMP
						);

//最后进班时间
CREATE TABLE IF NOT EXISTS tlast_enter_class_time (_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id             VARCHAR NOT NULL,
						class_id            INTEGER,
						last_enter_time		TIMESTAMP
						);
						
//打卡记录表
CREATE TABLE IF NOT EXISTS tpuncher_log (_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id             VARCHAR NOT NULL,
						class_id            INTEGER DEFAULT 0,
						record_date		TIMESTAMP,
						puncher_time		TIMESTAMP,
						puncher_able	INTEGER DEFAULT 0
						);