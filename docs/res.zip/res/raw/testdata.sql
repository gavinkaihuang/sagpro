//INSERT INTO tclass (user_id, class_id, class_name)  values (1, 1, '沪江网校');
//INSERT INTO tclass (user_id, class_id, class_name)  values (1, 2, '沪江网校2');
//INSERT INTO tclass (user_id, class_id, class_name)  values (1, 2, '沪江网校3');
//INSERT INTO tclass (user_id, class_id, class_name)  values (1, 2, '沪江网校4');