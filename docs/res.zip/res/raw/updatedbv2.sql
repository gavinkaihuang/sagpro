//更新数据库表，添加字段，用于记录班级是否体验班
ALTER TABLE tclass ADD is_exp_class VARCHAR;
