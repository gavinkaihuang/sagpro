//更新课程信息表增加
ALTER TABLE tlesson_info ADD unfold INTEGER DEFAULT 0;
//增加是否请假字段
ALTER TABLE tlesson_info ADD is_leave VARCHAR;
//用户配置
CREATE TABLE IF NOT EXISTS tuser_config (_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, class_id INTEGER ,last_position INTEGER, unit_id INTEGER, lesson_id INTEGER, config_info  TEXT);
//选课中心增加优惠劵价格
ALTER TABLE tclass_center ADD class_pc_price VARCHAR;