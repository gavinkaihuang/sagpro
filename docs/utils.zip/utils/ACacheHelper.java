package com.hujiang.hjclass.utils;

import android.text.TextUtils;

import com.hujiang.hjclass.MainApplication;

import java.io.Serializable;

/**
 * Created by lvhuacheng on 2017/1/4.
 */

public class ACacheHelper {

    public static void saveString(String key, String value){
        if(TextUtils.isEmpty(key) || TextUtils.isEmpty(value)){
            return;
        }
        if(MainApplication.aCache == null){
            return;
        }
        MainApplication.aCache.put(key,value);
    }

    public static String getString(String key){
        if(TextUtils.isEmpty(key)){
            return null;
        }
        if(MainApplication.aCache == null){
            return null;
        }
        return MainApplication.aCache.getAsString(key);
    }

    public static void saveObject(String key, Serializable value){
        if(TextUtils.isEmpty(key) || value == null){
            return;
        }
        if(MainApplication.aCache == null){
            return;
        }
        MainApplication.aCache.put(key,value);
    }

    public static void saveObject(String key, Serializable value, int saveTime){
        if(TextUtils.isEmpty(key) || value == null){
            return;
        }
        if(MainApplication.aCache == null){
            return;
        }
        MainApplication.aCache.put(key,value,saveTime);
    }

    public static Object getObject(String key){
        if(TextUtils.isEmpty(key)){
            return null;
        }
        if(MainApplication.aCache == null){
            return null;
        }
        return MainApplication.aCache.getAsObject(key);
    }
}
