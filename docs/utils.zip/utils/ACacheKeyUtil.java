package com.hujiang.hjclass.utils;

import com.hujiang.loginmodule.LoginUtils;

/**
 * Created by lvhuacheng on 2016/11/19.
 */

public class ACacheKeyUtil {

    public static String getUserLabelCacheKey(){
        return "user_label_"+ LoginUtils.getUserId();
    }

    public static String getStudyStructureKey(){
        return "study_structure_"+ LoginUtils.getUserId();
    }

    public static String getStudyCardCacheKey(String cardId){
        return "study_card_" + cardId + "_" + LoginUtils.getUserId();
    }

    public static String getAllLabelCacheKey(){
        return "all_label";
    }

    public static String getClassReserveCacheKey(String cardId){
        return "class_reserve_" + cardId + "_" + LoginUtils.getUserId();
    }

    public static String getLearningSystemBreTestStatusCacheKey(){
        return "learning_system_bre_test_status";
    }

    public static String getLearningSystemBreTestLinkCacheKey(){
        return "learning_system_bre_test_link";
    }

    public static String getLearningSystemLessonUnitExpandStatusCacheKey(){
        return "learning_system_lesson_unit_expand_status";
    }

    public static String getLearningSystemStudySolutionLinkCacheKey(){
        return "learning_system_study_solution_link";
    }

    /**
     * 已被统计的广告链接缓存key
     * @return
     */
    public static String getADCardAlreadyStatisticCacheKey(){
        return "ad_card_already_statistic_"+ LoginUtils.getUserId();
    }
}
