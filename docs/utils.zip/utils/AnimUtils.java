package com.hujiang.hjclass.utils;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import com.hujiang.hjclass.R;

/**
 * Created by Gavin on 13-11-12.
 */
public class AnimUtils {

    public static final int TRANSITION_ANIMATION_NONE = 0;//进入动画无，退出动画无
    public static final int TRANSITION_ANIMATION_RIGHT = 1;//进入动画右，退出动画右
    public static final int TRANSITION_ANIMATION_TOP = 2;//进入动画上，退出动画上
    public static final int TRANSITION_ANIMATION_BOTTOM = 3;//进入动画下，退出动画下
    public static final int TRANSITION_ANIMATION_NONE_RIGHT = 4;//进入动画无，退出动画右

    /**
     * 启动Activity的动画
     * @param activity
     */
    public static void startActivityAnim(Activity activity,int animType) {
        if(activity == null){
            return;
        }
        switch(animType){
            case TRANSITION_ANIMATION_NONE:
                activity.overridePendingTransition(R.anim.nothing, R.anim.nothing);
                break;
            case TRANSITION_ANIMATION_RIGHT:
                activity.overridePendingTransition(R.anim.push_left_in, R.anim.nothing);
                break;
            case TRANSITION_ANIMATION_TOP:
                activity.overridePendingTransition(R.anim.translate_top_in, R.anim.nothing);
                break;
            case TRANSITION_ANIMATION_BOTTOM:
                activity.overridePendingTransition(R.anim.translate_bottom_in, R.anim.nothing);
                break;
            case TRANSITION_ANIMATION_NONE_RIGHT:
                activity.overridePendingTransition(R.anim.nothing, R.anim.nothing);
                break;
        }
    }

    /**
     * 关闭Acitivity的动画
     * @param activity
     */
    public static void finishActivityAnim(Activity activity,int animType) {
        if(activity == null){
            return;
        }
        switch(animType){
            case TRANSITION_ANIMATION_NONE:
                activity.overridePendingTransition(R.anim.nothing, R.anim.nothing);
                break;
            case TRANSITION_ANIMATION_RIGHT:
                activity.overridePendingTransition(R.anim.nothing, R.anim.push_right_out);
                break;
            case TRANSITION_ANIMATION_TOP:
                activity.overridePendingTransition(R.anim.nothing, R.anim.translate_top_out);
                break;
            case TRANSITION_ANIMATION_BOTTOM:
                activity.overridePendingTransition(R.anim.nothing, R.anim.translate_bottom_out);
                break;
            case TRANSITION_ANIMATION_NONE_RIGHT:
                activity.overridePendingTransition(R.anim.nothing, R.anim.push_right_out);
                break;
        }
    }


    /**
     * 启动Activity的动画
     * @param activity
     */
    public static void startActivityAnim(Activity activity) {
        //activity.overridePendingTransition(R.anim.push_left_in, R.anim.nothing);
    }

    /**
     * 关闭Acitivity的动画
     * @param activity
     */
    public static void finishActivityAnim(Activity activity) {
        //activity.overridePendingTransition(R.anim.nothing, R.anim.push_right_out);
    }

    /**
     * 从底部启动Activity
     * @param activity
     */
    public static void startActivityFromBottomAnim(Activity activity) {
        activity.overridePendingTransition(R.anim.translate_bottom_in, R.anim.nothing);
    }

    /**
     * 关闭Acitivity去底部
     * @param activity
     */
    public static void finishActivityToBottomAnim(Activity activity) {
        activity.overridePendingTransition(R.anim.nothing, R.anim.translate_bottom_out);
    }

    /**
     * 从顶部启动Activity
     * @param activity
     */
    public static void startActivityFromTopAnim(Activity activity) {
        activity.overridePendingTransition(R.anim.translate_top_in, R.anim.nothing);
    }

    /**
     * 从顶部离开Activity
     * @param activity
     */
    public static void finishActivityFromTopAnim(Activity activity) {
        activity.overridePendingTransition(R.anim.nothing,R.anim.translate_top_out);
    }

    /**
     * 获取旋转动画
     * @param ctx
     * @param ms    每转耗时 (单位:毫秒)
     * @return
     */
    public static Animation getRotateAnim(Context ctx, long ms){
        if(ctx == null){
            return null;
        }
        Animation rotateAnim = AnimationUtils.loadAnimation(ctx.getApplicationContext(), R.anim.rotate_360);
        rotateAnim.setDuration(ms);
        LinearInterpolator lin = new LinearInterpolator();
        rotateAnim.setInterpolator(lin);
        return rotateAnim;
    }

    /**
     * 重载 startTargetViewAnim（）
     * @param anchorView
     */
    public static void startTargetViewAnim(View anchorView){
        startTargetViewAnim(anchorView,500,0,0);
    }

    /**
     * 点赞动画
     *
     * @param anchorView
     * @param offsetY
     * @param offsetX
     */
    public static void startTargetViewAnim(View anchorView, int duration,int offsetY, int offsetX){
        final View targetView = locationView(anchorView,offsetX,offsetY);

        AnimatorSet animatorSet = new AnimatorSet();
        ValueAnimator translateAnimator = ObjectAnimator.ofFloat(0, -100f);
        translateAnimator.setDuration(duration);
        translateAnimator.setStartDelay(50);
        translateAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                targetView.setTranslationY((Float) valueAnimator.getAnimatedValue());
            }
        });
        translateAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                targetView.setVisibility(View.GONE);

            }
        });

        ValueAnimator alphaAnimator = ObjectAnimator.ofFloat(1.0f, 0.0f);
        alphaAnimator.setDuration(duration);
        alphaAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                targetView.setAlpha((Float) valueAnimator.getAnimatedValue());
            }
        });

        ValueAnimator scaleAnimator = ObjectAnimator.ofFloat(1.0f, 3f);
        scaleAnimator.setDuration(duration);
        scaleAnimator.setStartDelay(300);
        scaleAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                targetView.setScaleX((Float) valueAnimator.getAnimatedValue());
                targetView.setScaleY((Float) valueAnimator.getAnimatedValue());
            }
        });

        animatorSet.setInterpolator(new AccelerateDecelerateInterpolator());
        animatorSet.playTogether(translateAnimator,alphaAnimator,scaleAnimator);
        animatorSet.start();
    }

    /**
     * 参考View(anchorView),定位一个targetView
     * @param anchorView 参考的View
     * @param offsetX
     * @param offsetY
     * @return
     */
    private static View locationView(View anchorView,int offsetX,int offsetY){
        if (anchorView == null || !(anchorView.getContext() instanceof Activity))return null;
        Activity activity = (Activity) anchorView.getContext();
        ViewGroup rootView = (ViewGroup) activity.findViewById(Window.ID_ANDROID_CONTENT);
        if (rootView == null || !(rootView instanceof FrameLayout)) return null;

        //targetView 被定位的View
        View targetView = rootView.findViewById(R.id.hj_rl_praised_animator_parent);
        if (targetView != null){
            rootView.removeView(targetView);
        }
        targetView = View.inflate(activity,R.layout.layout_target_view,null);
        Rect rect = new Rect();
        anchorView.getGlobalVisibleRect(rect);
        int[] location = new int[2];
        rootView.getLocationOnScreen(location);
        rect.offset(-location[0], -location[1]);

        int widthMeasureSpec = View.MeasureSpec.makeMeasureSpec((1 << 30) - 1, View.MeasureSpec.AT_MOST);
        int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec((1 << 30) - 1, View.MeasureSpec.AT_MOST);
        targetView.measure(widthMeasureSpec,heightMeasureSpec);

        int topMargin = rect.top  + ((anchorView.getMeasuredHeight() - targetView.getMeasuredHeight()) / 2) + offsetY;
        int leftMargin = rect.left  + ((anchorView.getMeasuredWidth() - targetView.getMeasuredWidth()) / 2) + offsetX;

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = topMargin;
        lp.leftMargin = leftMargin;
        rootView.addView(targetView,lp);
        return targetView;
    }
}
