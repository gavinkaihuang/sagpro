/**
 *
 */
package com.hujiang.hjclass.utils;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.SparseIntArray;
import com.hujiang.hjclass.download.DownloadControl;
import com.hujiang.ocs.download.OCSDownloadInfo;

/**
 * @author lidongkai
 */
public class BackgroundDelUtil {
    final public static int UI_DELETE_FINISHED = 0;
    final public static int UI_DELETE_PROGRESS_UPDATE = 1;

    private Context mContext;
    SparseIntArray mSelectedItems = null;
    Handler mHandler = null;

    /**
     *
     */
    public BackgroundDelUtil(Context context) {
        mContext = context;
        initDownloadControl();
    }

    public void setHandler(Handler handler) {
        mHandler = handler;
    }

    public void deleteLessons(SparseIntArray items) {
        mSelectedItems = this.cloneArray(items);
        mDownloadControllerHandler.sendEmptyMessage(0);
    }

    private void initDownloadControl() {
        HandlerThread thread = new HandlerThread("downloadedControlHandler");
        thread.start();
        mDownloadLooper = thread.getLooper();
        mDownloadControllerHandler = new DownloadControllerHandler(mDownloadLooper);
    }

    private volatile Looper mDownloadLooper;
    private volatile DownloadControllerHandler mDownloadControllerHandler;

    private final class DownloadControllerHandler extends Handler {
        public DownloadControllerHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            if (mSelectedItems == null) {
                if (mHandler != null)
                    mHandler.sendEmptyMessage(UI_DELETE_FINISHED);
                return;
            }
            SparseIntArray selectedItems = cloneArray(mSelectedItems);
            final int size = selectedItems.size();
            if (size == 0) {
                if (mHandler != null) {
                    mHandler.sendEmptyMessage(UI_DELETE_FINISHED);
                }
                return;
            }

            for (int i = 0; i < size; i++) {
                final int lessonId = selectedItems.keyAt(i);
                final int classId = selectedItems.get(lessonId);
                final int x=i;
                DownloadControl.getInstance().delete((long) classId, (long) lessonId, new DownloadControl.DownloadListener() {
                    @Override
                    public void deleteResult(OCSDownloadInfo ocsDownloadInfo) {
                     updateProgress(x, size, lessonId);
                     ClassUtils.clearClassPromptSign(mContext, String.valueOf(classId));
                        if (x == (size-1)) {
                            if (mHandler != null) {
                                mHandler.sendEmptyMessage(UI_DELETE_FINISHED);
                            }
                        }
                    }
                });
            }

        }


        private void updateProgress(int pos, int max, int lessonId) {
            if (mHandler != null) {
                Message msg = new Message();
                msg.what = UI_DELETE_PROGRESS_UPDATE;
                msg.arg1 = pos;
                msg.arg2 = max;
                msg.obj = lessonId;
                mHandler.sendMessage(msg);
            }
        }
    }

    public SparseIntArray cloneArray(SparseIntArray selectedItems) {
        if (selectedItems == null)
            return null;
        SparseIntArray array = new SparseIntArray();
        int size = selectedItems.size();
        for (int i = 0; i < size; i++) {
            int key = selectedItems.keyAt(i);
            int value = selectedItems.get(key);
            array.put(key, value);
        }
        return array;
    }

}
