package com.hujiang.hjclass.utils;

/**
 * Created by Gavin on 13-10-28.
 */
import android.graphics.Bitmap;
import android.support.v4.util.LruCache;


//public class BitmapCache implements ImageCache {

public class BitmapCache  {

    private LruCache<String, Bitmap> mCache;

    public BitmapCache() {
        int maxSize = 10 * 1024 * 1024;
        mCache = new LruCache<String, Bitmap>(maxSize) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return value.getRowBytes() * value.getHeight();
            }
        };
    }


    public Bitmap getBitmap(String url) {
        return mCache.get(url);
    }


    public void putBitmap(String url, Bitmap bitmap) {
        mCache.put(url, bitmap);
    }

}
