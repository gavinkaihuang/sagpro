package com.hujiang.hjclass.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Created by lvhuacheng on 2016/1/25.
 */
public class BitmapUtil {

    private static final String TAG = "BitmapUtil";

    private static InputStream Bitmap2InputStream(Bitmap bm, int quality) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, quality, baos);
        InputStream is = new ByteArrayInputStream(baos.toByteArray());
        return is;
    }

    /**
     * 计算图片的缩放比例
     * @param options
     * @param reqWidth
     * @param reqHeight
     * @return
     */
    private static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        if(reqWidth == 0 || reqHeight == 0){
            return 1;
        }
        // 源图片的高度和宽度
        int height = options.outHeight;
        int width = options.outWidth;
        LogUtil.info(TAG, "decodeBitmap_by_ratio,srcWidth = "+width+", srcHeight = "+height);
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            // 计算出实际宽高和目标宽高的比率
            int heightRatio = Math.round((float) height / (float) reqHeight);
            int widthRatio = Math.round((float) width / (float) reqWidth);
            LogUtil.info(TAG, "decodeBitmap_by_ratio,widthRatio = "+widthRatio+", heightRatio = "+heightRatio);
            //选择宽和高中最大的比率作为inSampleSize的值，这样可以保证最终图片的宽和高
            //一定都会小于等于目标的宽和高。
            inSampleSize = heightRatio > widthRatio ? heightRatio : widthRatio;
            LogUtil.info(TAG, "decodeBitmap_by_ratio,source_inSampleSize = "+inSampleSize);
            /**
             * 要设置inSampleSize是多少呢？
             * 假设原图是1500x700的，我们给缩略图留出的空间是100x100的，那么inSampleSize=min(1500/100, 700/100)=7，我们可以得到的缩略图是原图的1/7吗？
             * 但是事实没有那么完美，虽然设置了inSampleSize=7，但是得到的缩略图却是原图的1/4，原因是inSampleSize只能是2的整数次幂，如果不是的话，向下取得最大的2的整数次幂，7向下寻找2的整数次幂，就是4
             */
            inSampleSize = DigitalUtil.get2NthNearNumber(inSampleSize);
            LogUtil.info(TAG, "decodeBitmap_by_ratio,ret_inSampleSize = "+inSampleSize);
        }
        if(inSampleSize == 0){
            inSampleSize = 1;
        }
        return inSampleSize;
    }

    /**
     * 按比例缩放图片
     * wRatio = reqWidth/imageWidth，hRatio = reqHeight/imageHeight，ratio = max(wRatio,hRatio))
     * @param sourceBitmap
     * @param reqWidth
     * @param reqHeight
     * @param recycleSourceBitmap
     * @return
     */
    public static Bitmap decodeBitmap_by_ratio(Bitmap sourceBitmap,int reqWidth, int reqHeight,boolean recycleSourceBitmap) {
        if(sourceBitmap == null){
            return sourceBitmap;
        }
        try{
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.outHeight = sourceBitmap.getHeight();
            options.outWidth = sourceBitmap.getWidth();
            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
            if(options.inSampleSize == 1){
                return sourceBitmap;
            }
//            LogUtil.error(TAG,"reqWidth: "+reqWidth+", reqHeight: "+reqHeight);
//            LogUtil.error(TAG,"srcWidth: "+options.outWidth+", srcHeight: "+options.outHeight);
//            LogUtil.error(TAG,"inSampleSize: "+options.inSampleSize);
            InputStream is = Bitmap2InputStream(sourceBitmap,100);
            Bitmap resultBitmap = BitmapFactory.decodeStream(is, null, options);
            if(recycleSourceBitmap && !sourceBitmap.isRecycled()){
                sourceBitmap.recycle();
            }
//            LogUtil.error(TAG,"resWidth: "+resultBitmap.getWidth()+", resHeight: "+resultBitmap.getHeight());
            return resultBitmap;
        }catch(Exception e){
            LogUtil.error(TAG,e);
        }
        return null;
    }

    /**
     * 按比例缩放图片
     * @param sourceBitmap
     * @param ratio
     * @param recycleSourceBitmap
     * @return
     */
    public static Bitmap decodeBitmap_by_ratio(Bitmap sourceBitmap, float ratio, boolean recycleSourceBitmap){
        if(sourceBitmap == null || ratio == 1){
            return sourceBitmap;
        }
        int reqWidth = (int)(sourceBitmap.getWidth() *  ratio);
        int reqHeight = (int)(sourceBitmap.getHeight() *  ratio);
        return decodeBitmap_by_ratio(sourceBitmap, reqWidth, reqHeight, recycleSourceBitmap);
    }

    /**
     * 按尺寸缩放图片
     * @param sourceBitmap
     * @param ratio
     * @param recycleSourceBitmap
     * @return
     */
    public static Bitmap decodeBitmap_by_size(Bitmap sourceBitmap, float ratio, boolean recycleSourceBitmap){
        if(sourceBitmap == null || ratio == 1){
            return sourceBitmap;
        }
        int reqWidth = (int)(sourceBitmap.getWidth() *  ratio);
        int reqHeight = (int)(sourceBitmap.getHeight() *  ratio);
        return decodeBitmap_by_size(sourceBitmap, reqWidth, reqHeight, recycleSourceBitmap);
    }

    /**
     * 按尺寸缩放图片
     * @param sourceBitmap          原图片
     * @param reqWidth              缩放后图片的宽度
     * @param reqHeight             缩放后图片的高度
     * @param recycleSourceBitmap   是否释放原图片
     * @return
     */
    public static Bitmap decodeBitmap_by_size(Bitmap sourceBitmap, int reqWidth, int reqHeight ,boolean recycleSourceBitmap){
        if(sourceBitmap == null){
            return sourceBitmap;
        }
        try{
            int height = sourceBitmap.getHeight();
            int width = sourceBitmap.getWidth();
//            LogUtil.error(TAG,"reqWidth: "+reqWidth+", reqHeight: "+reqHeight);
//            LogUtil.error(TAG,"srcWidth: "+width+", srcHeight: "+height);
            if(sourceBitmap.getWidth() == reqWidth && sourceBitmap.getHeight() == reqHeight){
                return sourceBitmap;
            }
            //缩放图片的尺寸
            float scaleWidth  = (float) reqWidth / width;
            float scaleHeight = (float) reqHeight / height;
            //得到缩放后的Bitmap对象
            Matrix matrix = new Matrix();
            matrix.postScale(scaleWidth, scaleHeight);
            Bitmap resultBitmap = Bitmap.createBitmap(sourceBitmap, 0, 0, width, height, matrix, false);
            if(recycleSourceBitmap && !sourceBitmap.isRecycled()){
                sourceBitmap.recycle();
            }
//            LogUtil.error(TAG,"resWidth: "+resultBitmap.getWidth()+", resHeight: "+resultBitmap.getHeight());
            return resultBitmap;
        }catch(Exception e){
            LogUtil.error(TAG, e);
        }
        return null;
    }

    /**
     * 解析字符串颜色值,解析不成功返回：Color.WHITE
     * @param colorString
     * @return
     */
    public static int parseColor(String colorString){
        int ret = Color.WHITE;
        try{
            ret = Color.parseColor(colorString);
        }catch(Exception e){
            ret = Color.WHITE;
        }
        return ret;
    }
}
