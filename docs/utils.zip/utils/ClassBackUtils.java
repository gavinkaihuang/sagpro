package com.hujiang.hjclass.utils;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;

import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.db.ClassPorvider;
import com.hujiang.BaseTableColumns;
import com.hujiang.hjclass.db.tables.TClassColumns;
import com.hujiang.hjclass.db.tables.TLessonInfoColumns;
import com.hujiang.hjclass.db.tables.URIList;

/**
 * Created by Gavin on 13-11-29.
 */
public class ClassBackUtils {

    /**
     * 学习结束更新学习状态到我的课程表
     * @param userID
     * @param classID
     * @param lessonID
     * @param status
     * @return
     */
    @Deprecated
    public static boolean updateLessonStudyStatus(String userID, String classID, String lessonID, int status) {
        ClassPorvider classPorvider = new ClassPorvider();

        try {
            int studyedLessonNo = 0;
            //取得数据库中原来的课程数目
            try {
                Cursor cursor = classPorvider.query(URIList.CLASS_URI,
                        BaseTableColumns.listColumns(TClassColumns.class), TClassColumns.USESR_ID + "=? and " + TClassColumns.CLASS_ID + "=?", new String[]{userID,
                        classID}, null);
                if (cursor.moveToFirst()) {
                    studyedLessonNo = cursor.getInt(cursor.getColumnIndex(TClassColumns.STUDY_LESSON_NUM));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            studyedLessonNo += 1;
            ContentValues contentValues = new ContentValues();
            contentValues.put(TClassColumns.STUDY_LESSON_NUM, studyedLessonNo);
            classPorvider.update(URIList.CLASS_URI, contentValues, TClassColumns.USESR_ID + "=? and " + TClassColumns.CLASS_ID + "=?", new String[]{userID, classID});

            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 更新课程学习时间
     * @param userID
     * @param lessonID
     * @param studyTime
     * @return
     */
    @Deprecated
    public static boolean updateLessonStudyTime(String userID,  String lessonID, String studyTime ,String playPosition) {
        ClassPorvider classPorvider = new ClassPorvider();

        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put(TLessonInfoColumns.LESSON_STUDY_TIME, studyTime);
            contentValues.put(TLessonInfoColumns.LESSON_PLAY_TIME, playPosition);
            int reno = classPorvider.update(URIList.LESSON_INFO_URI, contentValues, TLessonInfoColumns.LESSON_ID + "=? and " + TLessonInfoColumns.USER_ID + "=?"
                        , new String[] { lessonID, userID});
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


    /**
     * 通知我的班级更新列表
     */
    public static void sendUpdateClassLessonInfoBroadCast() {
        Intent uiIntent=new Intent();
        uiIntent.setAction(Constant.BROAD_UPDATE_MY_CLASS_LESSON);
        MainApplication.getContext().sendBroadcast(uiIntent);
    }

//    public static void sendUpdateClassLessonI
}
