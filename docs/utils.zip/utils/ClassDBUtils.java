package com.hujiang.hjclass.utils;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

import com.hujiang.hjclass.BuildConfig;
import com.hujiang.hjclass.db.ClassPorvider;
import com.hujiang.hjclass.db.tables.TClassDownloadColumns;
import com.hujiang.hjclass.db.tables.TDownloadColumns;
import com.hujiang.hjclass.db.tables.TUserColumns;
import com.hujiang.hjclass.db.tables.URIList;
import com.hujiang.ocs.download.OCSDownloadStatus;


/**
 * Created by Gavin on 13-10-26.
 */
public class ClassDBUtils {

    /**
     * 保存用户信息， 用户登录时使用
     * @param context
     * @param userid
     * @param username
     * @param password
     * @param token
     * @return
     */
    public static Uri saveOrUpdateUserInfo(Context context, String userid, String username,  String password, String token) {

        ContentValues values = new ContentValues();
        values.put(TUserColumns.USESR_ID, userid);
        values.put(TUserColumns.USER_NAME, username);
        values.put(TUserColumns.PASSWORD, password);
        values.put(TUserColumns.TOKEN, token);

        return saveOrUpdateUserInfo(context, userid, values);
    }



    /**
     * 新增或更新用户信息
     * @param context
     * @param userid
     * @param contentValues
     * @return
     */
    public static Uri saveOrUpdateUserInfo(Context context, String userid, ContentValues contentValues) {
        Uri oneUri =null;
        String[] selectionValue = new String[] {userid};
        if(context != null) {
        	  Cursor cursor = null;
			try {
				cursor = context.getContentResolver().query(URIList.USER_URI, null, TUserColumns.USESR_ID + "=?", selectionValue, null);
				if (cursor.moveToFirst()) {
					int value = context.getContentResolver().update(URIList.USER_URI, contentValues, TUserColumns.USESR_ID + "=?", selectionValue);
					oneUri = ContentUris.withAppendedId(URIList.USER_URI, value);
				} else {
					oneUri = context.getContentResolver().insert(URIList.USER_URI, contentValues);
				}
			} catch (Exception e) {
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}
        }
        return oneUri;
    }

  //有下载中、有暂停无下载中、全部等待、
    public final static int DOWNLOAD_NO_ACTION = 0;
    public final static int DOWNLOAD_HAS_DOWNLOADING = 1;
    public final static int DOWNLOAD_HAS_PAUSED = 2;
    public final static int DOWNLOAD_ALL_WAITING = 3;
    public static int getClassDownloadStatus(String classId, String userId) {
        int rt = DOWNLOAD_NO_ACTION;

        ClassPorvider cp = new ClassPorvider();
        String projection = TClassDownloadColumns.LESSON_NAME;
        String table = URIList.TABLE_NAME_TCLASS_DOWNLOAD;
        String pre_selection = TClassDownloadColumns.USER_ID + "=" + userId + " and " + TClassDownloadColumns.CLASS_ID + "=" + classId + " and "+ TClassDownloadColumns.DOWNLOAD_STATUS;
        String downloading_selection = pre_selection 
                + " in ( " 
                + OCSDownloadStatus.STATUS_STARTED + ","
                + OCSDownloadStatus.STATUS_DOWNLOAD_COMPLETED + ","
                + OCSDownloadStatus.STATUS_UNZIP + ","
                + OCSDownloadStatus.STATUS_UNZIP_COMPLETE
                + " )";
        String paused_selection = pre_selection + " = " + OCSDownloadStatus.STATUS_PAUSED;
        String waiting_selection = pre_selection 
                + " in ( " 
                + OCSDownloadStatus.STATUS_PENDED + ","
                + OCSDownloadStatus.STATUS_DECODE
                + " )";
        String sql = "";

        if(classId != null && !classId.isEmpty()
                && userId != null && !userId.isEmpty()) {
            //查询是否有正在下载的任务
            sql = String.format("select %s from %s where %s", projection, table, downloading_selection);
            Cursor c = cp.rawQuery(sql, null);
            if(existRecord(c, TClassDownloadColumns.LESSON_NAME)) {

                closeCursor(c);
                rt = DOWNLOAD_HAS_DOWNLOADING;
            } else {
                closeCursor(c);
                sql = String.format("select %s from %s where %s", projection, table, paused_selection);
                c = cp.rawQuery(sql, null);
                if(existRecord(c, TClassDownloadColumns.LESSON_NAME)) {

                    closeCursor(c);
                    rt = DOWNLOAD_HAS_PAUSED;
                } else {
                    closeCursor(c);
                    sql = String.format("select %s from %s where %s", projection, table, waiting_selection);
                    c = cp.rawQuery(sql, null);
                    if(existRecord(c, TClassDownloadColumns.LESSON_NAME)) {

                        rt = DOWNLOAD_ALL_WAITING;
                    }
                    closeCursor(c);
                }
            }
        }

        return rt;
    }

    
    private static boolean existRecord(Cursor c, String column) {
        if(c != null && c.getCount() > 0) {
            if(BuildConfig.DEBUG) {
                c.moveToFirst();
                String str = c.getString(c.getColumnIndexOrThrow(column));

            }
            return true;
        }
        return false;
    }

    private static void closeCursor(Cursor c) {
        if(c != null) {
            c.close();
        }
    }

    public final static int TYPE_INT = 1;
    public final static int TYPE_LONG = 2;
    public final static int TYPE_STRING = 3;
    public static Object getSingleItem(Uri uri, int value_type, 
            String target_column, String[] selection_columns, String[] selection_args) {
        Object rt = null;
        Cursor c = getSimpleCursor(uri, target_column, selection_columns, selection_args);
        int count = (c != null) ? c.getCount() : 0;
        if(count > 0) {
            c.moveToFirst();
            switch(value_type) {
            case TYPE_INT:
                rt = c.getInt(c.getColumnIndexOrThrow(target_column));
                break;
            case TYPE_LONG:
                rt = c.getLong(c.getColumnIndexOrThrow(target_column));
                break;
            case TYPE_STRING:
                rt = c.getString(c.getColumnIndexOrThrow(target_column));
                break;
            }
        }


        if (c != null) {
            c.close();
        }

        return rt;
    }

    public static Cursor getSimpleCursor(Uri uri, String target_column,
            String[] selection_columns, String[] selection_args) {
        Cursor rt = null;
        if(selection_columns == null || selection_args == null
                || selection_columns.length == 0 || selection_args.length == 0 
                ||selection_columns.length != selection_args.length)
            return rt;
        String[] projection = {
                target_column,
            };
        String selection = "";
        for(int i  = 0; i < selection_columns.length; i ++) {
            selection += selection_columns[i] + "=?";
            if(i < (selection_columns.length - 1))
                selection += " and ";

        }

        ClassPorvider provider = new ClassPorvider();

        rt = provider.query(uri, projection,
                selection, selection_args, null);
        return rt;
    }
}
