package com.hujiang.hjclass.utils;

import android.content.Intent;
import android.text.TextUtils;

import com.hujiang.hjclass.AppConfig;
import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.db.business.ClassBusiness;
import com.hujiang.hjclass.db.tables.TClassColumns;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.util.NetStatusUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by lvhuacheng on 2016/4/25.
 */
public class ClassTaskRemedyUtil {

    private static final String TAG = "ClassTaskRemedyUtil";

    private static final String LOCK = "REMEDY_SET";

    private static ClassTaskRemedyUtil instance = null;

    private ExecutorService fixedThreadPool = null;

    private HashSet<String> remedySet = null;

    private class TaskRunnable implements Runnable{

        private String classId;

        public TaskRunnable(String classId){
            this.classId = classId;
        }

        @Override
        public void run() {
            String taskIcons = requestData(classId,1);
            if(taskIcons != null){
                if(ClassBusiness.updateClassTask(LoginUtils.getUserId(MainApplication.getContext()),classId,"3",taskIcons)){
                    sendBrocast(classId);
                }
            }
            deleteClassTaskRemedy(classId);
        }
    }

    private ClassTaskRemedyUtil(){

    }

    public static synchronized ClassTaskRemedyUtil getInstance(){
        if(instance == null){
            instance = new ClassTaskRemedyUtil();
        }
        instance.init();
        return instance;
    }

    private void init(){
        if(remedySet == null){
            remedySet = new HashSet<String>();
        }
        if(fixedThreadPool == null){
            fixedThreadPool = Executors.newFixedThreadPool(5);
        }
    }

    private String requestData(String classId,int actionId){
        String url = String.format(AppConfig.HOST_URL_FOR_4 + Constant.URL_CLASSTASK,classId,actionId);
        LogUtil.error(TAG,"url = "+url);
        String result = ServerConnecter.requestByGet(url);
        LogUtil.error(TAG,"result = "+result);
        JSONObject parentObject = JsonParserUtil.getJSONObject(result);
        if(parentObject == null){
            return null;
        }
        int status = JsonParserUtil.getJSONObjectValue_Int(parentObject,"status");
        if(status != 0){
            return null;
        }
        JSONObject contentObject = JsonParserUtil.getJSONObject(parentObject,"content");
        if(contentObject == null){
            return null;
        }
        JSONArray taskInfoArray = JsonParserUtil.getJSONArray(contentObject,"task_info");
        if(!JsonParserUtil.isNotEmpty(taskInfoArray)){
            return "";
        }
        StringBuffer sb = new StringBuffer();
        String taskIcon = null;
        for(int i=0;i<taskInfoArray.length();i++){
            taskIcon = JsonParserUtil.getJSONObjectValue(JsonParserUtil.getJSONObject(taskInfoArray,i),"task_icon");
            if(!TextUtils.isEmpty(taskIcon)){
                sb.append(taskIcon).append(",");
            }
        }
        if(sb.length() <= 0){
            return "";
        }
        return sb.substring(0,sb.length()-1);
    }

    private void sendBrocast(String classId){
        synchronized (LOCK){
            LogUtil.error(TAG,"sendBrocast,classId = "+classId);
            Intent intent = new Intent(Constant.BROADCAST_CLASS_TASK_STATUS_CHANGE);
            intent.putExtra(TClassColumns.CLASS_ID, classId);
            MainApplication.getContext().sendBroadcast(intent);
        }
    }

    private void deleteClassTaskRemedy(String classId){
        synchronized (LOCK){
            LogUtil.error(TAG,"deleteClassTaskRemedy,classId = "+classId);
            remedySet.remove(classId);
        }
    }

    public void addClassTaskRemedy(String classId){
        if(TextUtils.isEmpty(classId)){
            return;
        }
        if(!NetStatusUtils.getNetConnected(MainApplication.getContext())){
            return;
        }
        LogUtil.error(TAG,"addClassTaskRemedy,classId = "+classId);
        synchronized (LOCK){
            if(remedySet.contains(classId)){
                return;
            }
            remedySet.add(classId);
            fixedThreadPool.execute(new TaskRunnable(classId));
        }
    }
}
