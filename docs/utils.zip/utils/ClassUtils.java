package com.hujiang.hjclass.utils;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.View;

import com.hujiang.BaseTableColumns;
import com.hujiang.bi.utils.BIUtils;
import com.hujiang.common.util.FileUtils;
import com.hujiang.hjclass.AppConfig;
import com.hujiang.hjclass.Constant.CommonConstant;
import com.hujiang.hjclass.Constant.StatusConstant;
import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.R;
import com.hujiang.hjclass.activity.SchemeActivity;
import com.hujiang.hjclass.activity.UnbindAccountsActivity;
import com.hujiang.hjclass.activity.discount.DiscountIndex;
import com.hujiang.hjclass.activity.forums.ForumsActivity;
import com.hujiang.hjclass.activity.forums.ForumsDetailActivity;
import com.hujiang.hjclass.activity.forums.HomeworkDetailActivity;
import com.hujiang.hjclass.activity.lesson.LearningSystemLessonListActivity;
import com.hujiang.hjclass.activity.lesson.LessonListForCursorActivity;
import com.hujiang.hjclass.activity.lesson.NewClassIndex;
import com.hujiang.hjclass.activity.main.GlobalContinuesLearnUtlis;
import com.hujiang.hjclass.activity.main.MainActivity;
import com.hujiang.hjclass.activity.player.PlayerNoteActivity;
import com.hujiang.hjclass.adapter.model.ClassTaskModel;
import com.hujiang.hjclass.adapter.model.TaskBean;
import com.hujiang.hjclass.adapter.model.TaskCardEntity;
import com.hujiang.hjclass.adapter.model.TaskPostResutModel;
import com.hujiang.hjclass.db.ClassPorvider;
import com.hujiang.hjclass.db.business.ClassTaskBusiness;
import com.hujiang.hjclass.db.business.DownloadBusiness;
import com.hujiang.hjclass.db.business.LessonBusiness;
import com.hujiang.hjclass.db.tables.TClassCenterColumns;
import com.hujiang.hjclass.db.tables.TClassColumns;
import com.hujiang.hjclass.db.tables.TClassDownloadColumns;
import com.hujiang.hjclass.db.tables.TLessonInfoColumns;
import com.hujiang.hjclass.db.tables.URIList;
import com.hujiang.hjclass.download.DownloadControl;
import com.hujiang.hjclass.interfaces.LessonDeleteCallback;
import com.hujiang.hjclass.interfaces.LoginCallBack;
import com.hujiang.hjclass.model.ClassDownloadModel;
import com.hujiang.hjclass.model.ContinueLearnModel;
import com.hujiang.hjclass.model.LearningSystemClassTaskSubmitModel;
import com.hujiang.hjclass.player.MyOCSPlayerConfig;
import com.hujiang.hjclass.player.MyPlayerCallback;
import com.hujiang.hjclass.widgets.ClassAlertDialogTwo;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.note.ClassNoteDetailActivity;
import com.hujiang.note.NotePicEditActivity;
import com.hujiang.ocs.download.OCSDownloadStatus;
import com.hujiang.ocs.player.OCSPlayer;
import com.hujiang.ocs.player.entity.OCSItemEntity;
import com.hujiang.preferences.ClassPerferenceChangKey;
import com.hujiang.preferences.ClassPerferenceConstantKey;
import com.hujiang.preferences.ClassPerferenceSmall;
import com.hujiang.trunk.HJFile;
import com.hujiang.trunk.TrunkFileUtils;
import com.hujiang.util.AppPara;
import com.hujiang.util.HJClassActivityPath;
import com.hujiang.util.StringUtils;
import com.hujiang.widget.ClassAlertDialog;
import com.hujiang.widget.ErrorAlertDialog;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static com.hujiang.util.HJClassActivityPath.ClassListByCategoryActivity;

/**
 * Created by Gavin on 13-11-26.
 */
public class ClassUtils {

    public final static int RED_DOT_GONE = 1;

    private static final String TAG = "ClassUtils";

    /**
     *
     * 班级列表是否显示红点
     *
     * @param context
     * @param userID
     * @param classID
     * @return
     */
    public static boolean isClassHasPromptSign(Context context, String userID, String classID) {
        boolean hasPrompt = false;
        String[] columns = new String[2];
        columns[0] = TClassDownloadColumns.LESSON_ID;
        ClassPorvider classPorvider = new ClassPorvider();
        Cursor cursor = classPorvider.query(URIList.TDOWNLOAD_URI, columns, TClassDownloadColumns.USER_ID + "=? and " + TClassDownloadColumns.CLASS_ID + "=? and " + TClassDownloadColumns.DOWNLOAD_STATUS
                + "=?", new String[]{userID, classID, "" + OCSDownloadStatus.STATUS_ALL_COMPLETE}, null);
        if (cursor != null && cursor.getCount() > 0)
            hasPrompt = true;

        if (cursor != null)
            cursor.close();
        return hasPrompt;
    }

    public static void setClassPromptSign(Context context, String userID, String classID, boolean show) {
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put(TClassColumns.NEW_DOWNLOADS, show ? "1" : "0");
            ClassPorvider cp = new ClassPorvider();
            int rt = cp.update(URIList.CLASS_URI, contentValues, TClassColumns.USESR_ID + "=? and " + TClassColumns.CLASS_ID + "=?", new String[]{userID, classID}, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void clearClassPromptSign(Context context, String classID) {
        try {
            // debugInfo.loge("classID:" + classID);
            ContentValues contentValues = new ContentValues();
            contentValues.put(TClassColumns.NEW_DOWNLOADS, "0");
            ClassPorvider cp = new ClassPorvider();
            int rt = cp.update(URIList.CLASS_URI, contentValues, TClassColumns.CLASS_ID + "=?", new String[]{classID});
            // debugInfo.loge("rt:" + rt);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param context
     * @param userID
     * @param classID
     * @param lessonID
     * @return 0 可以播放； -1 不可以播放； －2 文件损坏
     */
    public static int checkClassPlayStatus(Context context, String userID, String classID, String lessonID) {
        try {
            String trunkFile = TrunkFileUtils.getTrunkFile(userID);
            HJFile hjFile = HJFile.getInstance();
            int validateValue = hjFile.validateLessonId(trunkFile, Integer.parseInt(userID), Integer.parseInt(lessonID));
            if (validateValue != 0) {
                return -1;
            }
            String filePath = DownloadUtils.getDownloadPath(classID, lessonID) + "/index.hjmp3";
            // DebugUtils.println("video file is " + filePath);
            File file = new File(filePath);
            if (!file.exists() && !isOldLessonVersion(userID, classID, lessonID))
                return -2;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    private static boolean isOldLessonVersion(String userID, String classID, String lessonID) {
        boolean rt = false;
        String[] selection_columns = {TLessonInfoColumns.USER_ID, TLessonInfoColumns.LESSON_ID, TLessonInfoColumns.CLASS_ID};
        String[] selection_args = {userID, lessonID, classID};
        if (lessonID != null && !lessonID.isEmpty() && userID != null && !userID.isEmpty() && classID != null && !classID.isEmpty()) {
            Object version = ClassDBUtils.getSingleItem(URIList.LESSON_INFO_URI, ClassDBUtils.TYPE_INT, TLessonInfoColumns.LESSON_VERSION, selection_columns, selection_args);
            if (version != null) {
                int lessonVersion = (Integer) version;
                if (lessonVersion != 4) {
                    rt = true;
                }
            }
        }
        return rt;
    }

    /**
     * 播放课程
     */
    public static void playVideo(Context activity, String userId, String classId, String lessonId, int playTime) {
        try {
            ClassDownloadModel downloadinfo = DownloadBusiness.getDownloadInfo(LoginUtils.getUserId(), classId, lessonId);
            if (downloadinfo == null) {
                return;
            }
            if (TextUtils.isEmpty(downloadinfo.filePath)) {
                HJToast.show(activity.getResources().getString(R.string.prompt_class_file_broken));
                try {
                    DownloadControl.getInstance().delete(Long.parseLong(classId), Long.parseLong(lessonId));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return;
            }
            OCSItemEntity ocsItemEntity = new OCSItemEntity();
            ocsItemEntity.mLessonID = Long.parseLong(lessonId);
            ocsItemEntity.mLessonName = downloadinfo.lessonName;
            ocsItemEntity.mClassID = Long.parseLong(classId);
            ocsItemEntity.mClassName = downloadinfo.className;
            ocsItemEntity.mMediaPath = FileUtils.getFilePathDir(downloadinfo.filePath);
            ocsItemEntity.mPlayPosition = playTime;
            ocsItemEntity.mUserID = LoginUtils.getUserId();
            ocsItemEntity.mUserToken = LoginUtils.getUserToken();
            ocsItemEntity.mUserName = LoginUtils.getUsername();
            ocsItemEntity.mLessonType = Integer.parseInt(downloadinfo.isAudition); //是否试听课
            OCSPlayer.instance().play(ocsItemEntity, new MyPlayerCallback(), new MyOCSPlayerConfig(), PlayerNoteActivity.class);//
            // 保存最后学习项
            GlobalContinuesLearnUtlis.setLastStudyClassID(classId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 计算百分比
     *
     * @param downloadSize
     * @param totalSize
     * @return
     */
    public static int caculatorPercentage(long downloadSize, long totalSize) {
        if (totalSize <= 0)
            return 0;

        return (int) (downloadSize * 100 / totalSize);
    }

    /**
     * 计算百分比含小数点(保留一位小数)
     *
     * @param downloadSize
     * @param totalSize
     * @return
     */
    public static float caculatorPercentagePoint(long downloadSize, long totalSize) {
        if (totalSize <= 0)
            return 0;
        int percent = (int) (downloadSize * 1000 / totalSize);
        return (float) (percent / 10.0);
    }

    /**
     * 计算当前下载的进度
     */
    public static int caculatorPercentage(String value1, String value2) {
        try {
            long lvalue1 = Long.valueOf(value1);
            long lvalue2 = Long.valueOf(value2);
            return caculatorPercentage(lvalue1, lvalue2);
        } catch (Exception e) {
            //
        }
        return 0;
        // if (value1 == null || value2 == null || "".equals(value1) || "".equals(value2)
        // || "0".equals(value2))
        // return 0;
        //
        // try {
        // int ivalue1 = Integer.parseInt(value1);
        // int ivalue2 = Integer.parseInt(value2);
        // double value = 1.0 * ivalue1 / ivalue2;
        // return value;
        // } catch (NumberFormatException e) {
        // return 0;
        // }
    }

    /**
     * 同步NDK出错窗口
     *
     * @param activity
     * @param result
     */
    public static void showNDKAlertDialog(final Activity activity, int result) {
        if (activity == null)
            return;
        String message = null;

        if (result == 88020007) {
            message = activity.getString(R.string.bind_over_max_accounts_title);
        }
        if (message == null)
            return;
        final ClassAlertDialog classAlertDialog = new ClassAlertDialog(activity);
        classAlertDialog.setMessage(message);
        classAlertDialog.setLeftButton(activity.getString(R.string.btn_logout), new View.OnClickListener() {
            public void onClick(View v) {
                classAlertDialog.dismiss();
                LoginUtils.clearLoginInfo(activity);
                CommonIntent.requireLogin(activity);
            }
        });
        classAlertDialog.setRightButton(activity.getString(R.string.btn_bing), new View.OnClickListener() {
            public void onClick(View v) {
                classAlertDialog.dismiss();
                String url = AppConfig.UNBIND_URL;
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                activity.startActivity(intent);
                activity.overridePendingTransition(R.anim.nothing, R.anim.slide_in_from_bottom);
            }
        });
        classAlertDialog.show();
    }

    public static void showBindOverFiveDevicesAlertDialog(final Activity activity, final LoginCallBack classBack) {
        if (activity == null)
            return;
        final ClassAlertDialog classAlertDialog = new ClassAlertDialog(activity);
        classAlertDialog.setTitle(activity.getString(R.string.bind_over_max_devices_title));
        classAlertDialog.setTitleTextSize(16);
        classAlertDialog.setLeftButton(activity.getString(R.string.btn_logout), new View.OnClickListener() {
            public void onClick(View v) {
                if (classBack != null)
                    classBack.handLogout();
                classAlertDialog.dismiss();
                LoginUtils.clearLoginInfo(activity);
                CommonIntent.requireLogin(activity);
            }
        });
        classAlertDialog.setRightButton(activity.getString(R.string.btn_bing), new View.OnClickListener() {
            public void onClick(View v) {
                if (LoginUtils.checkNet(activity)) {
                    classAlertDialog.dismiss();
                    Intent intent = new Intent(activity, UnbindAccountsActivity.class);
                    activity.startActivity(intent);
                    activity.overridePendingTransition(R.anim.nothing, R.anim.slide_in_from_bottom);
                } else {
                    HJToast.makeText(activity, activity.getResources().getString(R.string.networkIsUnavailable), HJToast.LENGTH_LONG).show();
                }

            }
        });
        classAlertDialog.setCancelable(false);
        classAlertDialog.show();
    }

    public static void showBindOverFiveAccountsAlertDialog(final Activity activity) {
        if (activity == null)
            return;
        final ErrorAlertDialog errorAlertDialog = new ErrorAlertDialog(activity, com.hujiang.R.layout.widget_error_bind_five_accouts_dialog);
        errorAlertDialog.setTitle(activity.getString(R.string.bind_over_max_accounts_title));
        errorAlertDialog.setMessageTextSize(16);
        errorAlertDialog.setLeftButtomGone();
        errorAlertDialog.setLeftButton(activity.getString(R.string.btn_logout), new View.OnClickListener() {
            public void onClick(View v) {
                errorAlertDialog.dismiss();
                LoginUtils.clearLoginInfo(activity);
                CommonIntent.requireLogin(activity);
            }
        });
        errorAlertDialog.setRightButton(activity.getString(R.string.bind_over_max_accounts_contact_service), new View.OnClickListener() {
            public void onClick(View v) {
                errorAlertDialog.dismiss();
                Uri uri = Uri.parse("http://wpa.qq.com/msgrd?v=3&uin=200906792&site=qq&menu=yes");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                activity.startActivity(intent);
                activity.overridePendingTransition(R.anim.nothing, R.anim.slide_in_from_bottom);
            }
        });
        errorAlertDialog.setCancelable(false);
        errorAlertDialog.show();
    }

    /**
     * 课程列表调用
     *
     * @param activity
     * @param message
     */
    public static void showNoTrunkFileNDKAlertDialog(final Activity activity, String message, final boolean closeActivity) {

        final ClassAlertDialogTwo classAlertDialog = new ClassAlertDialogTwo(activity);
        classAlertDialog.setMessage(message);
        classAlertDialog.setButton1(activity.getString(R.string.btn_logout), new View.OnClickListener() {
            public void onClick(View v) {
                classAlertDialog.dismiss();
                LoginUtils.clearLoginInfo(activity);
                CommonIntent.requireLogin(activity);

                if (closeActivity)
                    activity.finish();

                startToMainActivity(activity);
            }
        });
        classAlertDialog.setButton2(activity.getString(R.string.btn_bing), new View.OnClickListener() {
            public void onClick(View v) {
                classAlertDialog.dismiss();
                String url = AppConfig.UNBIND_URL;
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                activity.startActivity(intent);
                activity.overridePendingTransition(R.anim.nothing, R.anim.slide_in_from_bottom);

                if (closeActivity)
                    activity.finish();
            }
        });
        classAlertDialog.show();
    }

    /**
     * 长按删除课程dialog
     *
     * @param activity
     * @param classBack
     */
    public static void showDeleteLessonAlertDialog(final Activity activity, final String lessonName, final LessonDeleteCallback classBack) {
        if (activity == null)
            return;
        final ClassAlertDialog classAlertDialog = new ClassAlertDialog(activity);
        classAlertDialog.setTitle(activity.getString(R.string.class_lesson_delete_lesson));
        classAlertDialog.setMessage(lessonName);
        classAlertDialog.setMessageTextSize(12);
        // classAlertDialog.setSencondDescriptionMessage(lessonName);
        // classAlertDialog.setSencondDescriptionMessageTextSize(10);
        classAlertDialog.setLeftButton(activity.getString(R.string.cancel), new View.OnClickListener() {
            public void onClick(View v) {
                classAlertDialog.dismiss();
            }
        });
        classAlertDialog.setRightButton(activity.getString(R.string.btn_delete), new View.OnClickListener() {
            public void onClick(View v) {
                classAlertDialog.dismiss();
                classBack.handleLessonDelete();
            }
        });
        classAlertDialog.setCancelable(false);
        classAlertDialog.show();
    }

    /**
     * 提示网络状态Dialog
     *
     * @param activity
     * @param message
     */
    public static void showNetWorkAlertDialog(final Activity activity, String message, final boolean closeActivity) {

        try {
            final ClassAlertDialogTwo classAlertDialog = new ClassAlertDialogTwo(activity);
            classAlertDialog.setMessage(message);
            classAlertDialog.setButton1(activity.getString(R.string.hj_half_screen_btn_cancel), new View.OnClickListener() {
                public void onClick(View v) {
                    classAlertDialog.dismiss();
                }
            });
            classAlertDialog.setButton2(activity.getString(R.string.btn_netsetting), new View.OnClickListener() {
                public void onClick(View v) {
                    classAlertDialog.dismiss();
                    activity.startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
                }
            });
            classAlertDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void startToMainActivity(Activity activity) {
        MainActivity.start(activity,SchemeActivity.ACTION_SELECTED_CLASS_PAGE);
    }

    public static void startToMainActivity(Activity activity, int entry) {
        MainActivity.start(activity,entry);
    }

    public static void switchToDiscountView(Activity activity, String code, int cardType, String fee) {
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = HJClassActivityPath.MainActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        res.putExtra(MainActivity.ACTION_SWITCHING, SchemeActivity.ACTION_DISCOUNT_PAGE);
        res.putExtra(DiscountConstants.DISCOUNT_SHOW_CARD_CODE, code);
        res.putExtra(DiscountConstants.DISCOUNT_SHOW_CARD_TYPE, cardType);
        if (fee != null) {
            res.putExtra(DiscountConstants.DISCOUNT_SHOW_CARD_FEE, fee);
        }
        activity.startActivity(res);
    }

    public static void switchToCouponView(Activity activity, int cardType, String code) {
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = HJClassActivityPath.MainActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        res.putExtra(MainActivity.ACTION_SWITCHING, SchemeActivity.ACTION_DISCOUNT_PAGE);
        res.putExtra(DiscountIndex.KEY_COUPON_TYPE, cardType);
        res.putExtra(DiscountIndex.KEY_COUPON_CODE, code);
        activity.startActivity(res);
    }

    public static int getSignHashCode(Activity activity) {
        PackageManager pm = activity.getPackageManager();
        String packageName = activity.getPackageName();
        // DebugUtils.println("packageName is " + packageName);
        try {
            PackageInfo pi = pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES);
            Signature sig = pi.signatures[0];
            // Log.w("test", bytArrayToHex(sig.toByteArray()));
            return pi.signatures[0].hashCode();
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * @param context
     * @return
     */
    public static String getQudaoKey(Context context) {
        String qudao = AppPara.getMetaData(context, "UMENG_CHANNEL");
        qudao = qudao.replaceAll("\\{", "");
        qudao = qudao.replaceAll("\\}", "");

        String appVersion = "";
        PackageManager manager = context.getPackageManager();
        try {
            PackageInfo info = manager.getPackageInfo(context.getPackageName(), 0);
            appVersion = info.versionName; // 版本名
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        qudao = qudao + "_" + appVersion;
        return qudao;
    }

    /**
     * 检查试听课程是否存在
     *
     * @param context
     * @param classKey
     * @return
     */
    public static boolean isIntroClassExist(Context context, String classKey) {
        String[] selection_args = {classKey};
        ClassPorvider provider = new ClassPorvider();
        boolean existClass = false;
        Cursor c = provider.query(URIList.CLASS_CENTER_URI, BaseTableColumns.listColumns(TClassCenterColumns.class), TClassCenterColumns.CLASS_KEY + "=?", selection_args, null);
        int count = (c != null) ? c.getCount() : 0;

        if (count > 0) {
            existClass = true;
        }
        if (c != null) {
            c.close();
        }

        return existClass;
    }

    public static void startupLessonList(Context context, String classID) {
        String[] projection = {TClassColumns.CLASS_SHORT_NAME, TClassColumns.CLASS_KEY,
                // TClassColumns.LAST_STUDY_NUM,
                // TClassColumns.LAST_STUDY_NAME,
                TClassColumns.CLASS_KIND, TClassColumns.TOTAL_LESSON_NUM, TClassColumns.STUDY_LESSON_NUM,};

        ClassPorvider cp = new ClassPorvider();
        Cursor cursor = cp.query(URIList.CLASS_URI, projection, TClassColumns.CLASS_ID + "=?", new String[]{classID + ""}, null);
        if (cursor == null) {
            return;
        }
        if (cursor.moveToFirst()) {

            String studyLesson = StringUtils.notNull(cursor.getString(cursor.getColumnIndex(TClassColumns.TOTAL_LESSON_NUM)));
            String totalLesson = StringUtils.notNull(cursor.getString(cursor.getColumnIndex(TClassColumns.TOTAL_LESSON_NUM)));
            String prompt = studyLesson + "/" + totalLesson;

            String className = cursor.getString(cursor.getColumnIndex(TClassColumns.CLASS_SHORT_NAME));
            String classKey = cursor.getString(cursor.getColumnIndex(TClassColumns.CLASS_KEY));
            String classKind = cursor.getString(cursor.getColumnIndex(TClassColumns.CLASS_KIND));// 2为已经毕业

            Bundle bundle = new Bundle();
            bundle.putString(TClassColumns.CLASS_ID, classID);
            bundle.putString(TClassColumns.CLASS_SHORT_NAME, className); // 没有单元的课程，默认加一个单元，已课程名为单元名字
            bundle.putString(TClassColumns.CLASS_KEY, classKey);
            bundle.putString(TClassColumns.CLASS_KIND, classKind);// 是否已经毕业
            bundle.putString("LESSON_PROMPT", prompt);
            //   bundle.putString(LessonListPullActivity.LAUNCH_LESSONLIST_FROM_SUB_ENTRY, LessonListPullActivity.LAUNCH_LESSONLIST_FROM_SUB_ENTRY);
            Intent intent = new Intent(context, LessonListForCursorActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtras(bundle);
            context.startActivity(intent);
            // AnimUtils.startActivityAnim(mContext);
            cursor.close();
        }
    }

    /**
     * 跳转到消息中心
     *
     * @param activity
     * @param title
     * @param url
     */
    public static void switchToMessageView(Activity activity, String title, String url) {
        switchToMessageView(activity, title, url, true);
    }

    public static void switchToMessageView(Activity activity, String title, String url, boolean hasToolbar) {
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = HJClassActivityPath.MessageActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        res.putExtra(Constant.EXTRA_MESSAGE_URL, url);
        res.putExtra(Constant.EXTRA_MESSAGE_TITLE, title);

        if (hasToolbar) {
            res.putExtra(Constant.EXTRA_MESSAGE_IS_ACTIVITY, true);
        }

        activity.startActivity(res);
    }

    /**
     * 跳转到班级介绍页
     *
     * @param activity
     * @param id
     * @param bundle
     */
    public static void switchToClassIntroBox(Activity activity, String id, Bundle bundle) {
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = HJClassActivityPath.ClassInfoBoxActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        res.putExtras(bundle);
        res.putExtra(TClassCenterColumns.CLASS_ID, id);
        activity.startActivity(res);
    }

    /**
     * 融云push跳转到课程首页
     *
     * @param activity
     * @param idString
     */
    public static void switchToClassIndexViewFromRongyunPush(Activity activity, String idString) {
        if(activity == null || TextUtils.isEmpty(idString)){
            return;
        }
//        Intent res = new Intent();
//        String mPackage = AppPara.getPackageName(activity);
//        String mClass = HJClassActivityPath.NewClassIndex;
//        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
//        res.putExtra(NewClassIndex.KEY_CLASS_ID, idString);
//        res.putExtra(NewClassIndex.FROM_RONGYUN_PUSH, true);
//        activity.startActivity(res);
        NewClassIndex.startClassIndex(activity, idString, true);
    }

    /**
     * 跳转到课程首页
     *
     * @param activity
     * @param idString
     */
    public static void switchToClassIndexView(Activity activity, String idString) {
        if(activity == null || TextUtils.isEmpty(idString)){
            return;
        }
//        Intent res = new Intent();
//        String mPackage = AppPara.getPackageName(activity);
//        String mClass = HJClassActivityPath.NewClassIndex;
//        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
//        res.putExtra(NewClassIndex.KEY_CLASS_ID, idString);
//        activity.startActivity(res);
        NewClassIndex.startClassIndex(activity, idString);
    }

    /**
     * 跳转到任务课程首页
     *
     * @param activity
     * @param idString
     */
    public static void switchToTaskClassIndexView(Activity activity, String idString) {
        if(activity == null || TextUtils.isEmpty(idString)){
            return;
        }
//        Intent res = new Intent();
//        String mPackage = AppPara.getPackageName(activity);
//        String mClass = HJClassActivityPath.NewClassIndex;
//        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
//        res.putExtra(NewClassIndex.KEY_CLASS_ID, idString);
//        activity.startActivity(res);
        NewClassIndex.startClassIndex(activity, idString);
    }

    /**
     * 跳转到答疑页
     *
     * @param activity
     * @param questionId
     * @param url
     */
    public static void switchToQuestionDetailView(Activity activity, String questionId, String url) {
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = HJClassActivityPath.QuestionAnswerReplyActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        res.putExtra("question_id", questionId);
        res.putExtra("url", url);
        activity.startActivity(res);
    }

    /**
     * 跳转到讨论区
     *
     * @param activity
     * @param discussDetailUrl
     */
    public static void switchToForumDetailView(Activity activity, String discussDetailUrl, boolean isExperience) {
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = HJClassActivityPath.ForumsDetailActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        res.putExtra(ForumsDetailActivity.DISCUSS_DETAIL_URL, discussDetailUrl);
        res.putExtra(NotePicEditActivity.ISEXPERIENCE, isExperience);
        activity.startActivity(res);
    }

    /**
     * 跳转到答疑页
     *
     * @param activity
     * @param questionAnswerClassId
     */
    public static void switchQuestionAnswerView(Activity activity, String questionAnswerClassId) {
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = HJClassActivityPath.QuestionAnswerActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        res.putExtra(Constant.INTENT_QUESTION_ANSWER_CLASS_ID, questionAnswerClassId);
        activity.startActivity(res);
    }

    /**
     * 跳转到讨论区
     *
     * @param activity
     * @param keyClassId
     */
    public static void switchToDisscussView(Activity activity, String keyClassId) {
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = HJClassActivityPath.ForumsActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        res.putExtra(ForumsActivity.KEY_CLASS_ID, keyClassId);
        activity.startActivity(res);
    }

    public static void switchToExperienceCenter(Activity activity) {
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = HJClassActivityPath.ExperienceCenterActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        activity.startActivity(res);
    }

    public static void switchToClassListByCategory(Activity activity, String parentCategoryId, String subCategoryId, String thirdCategoryId) {
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = ClassListByCategoryActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        res.putExtra(Constant.KEY_FIRST_CATEGORY, parentCategoryId);
        if (!TextUtils.isEmpty(subCategoryId)) {
            res.putExtra(Constant.KEY_SECOND_CATEGORY, subCategoryId);
        }
        if(!TextUtils.isEmpty(thirdCategoryId)){
            res.putExtra(Constant.KEY_THIRD_CATEGORY, thirdCategoryId);
        }
        activity.startActivity(res);
    }

    public static void switchToClassCategories(Activity activity) {
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = HJClassActivityPath.ClassCategoryActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        activity.startActivity(res);
    }

    /**
     * 跳转到已毕业班级首页
     * @param activity
     * @param classId
     */
    public static void switchToGraduateClassHome(Activity activity, String classId){
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);
        String mClass = HJClassActivityPath.GraduatClassedHome;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        res.putExtra(TClassColumns.CLASS_ID, classId);
        activity.startActivity(res);
    }

    /**
     * 跳转到笔记详情
     * @param activity
     * @param noteId
     */
    public static void switchToNoteDetail(Activity activity, String noteId){
        ClassNoteDetailActivity.startClassNoteDetailActivityByScheme(activity,noteId);
    }

    /**
     * 跳转到消息中心
     * @param activity
     */
    public static void switchToMessageCenter(Activity activity){
        Intent res = new Intent();
        String mPackage = AppPara.getPackageName(activity);

        String mClass = HJClassActivityPath.MessageCenterActivity;
        res.setComponent(new ComponentName(mPackage, mPackage + mClass));
        activity.startActivity(res);
    }

    /************************************************************************开始学/继续学逻辑-start************************************************************************/

    /**
     * 开始学/继续学
     *
     * @param activity
     * @param continueLearnModel 课程信息
     */
    public static void continueToLearn(Activity activity, ContinueLearnModel continueLearnModel) {
        if (activity == null || continueLearnModel == null || !continueLearnModel.check()) {
            return;
        }
        if (continueLearnModel.isContinueLearn()) {
            // 继续学, 跳转到播放器
            if (continueLearnModel.getLastLessonNum() < 0) {
                return;
            }
            gotoPlay(activity, continueLearnModel);
            BIUtils.onclickClassContinue(activity.getApplicationContext(), false, continueLearnModel.getClassId(), String.valueOf(continueLearnModel.getLastLessonNum()));
        } else {
            // 开始学，直接跳转到课程表
            gotoLessonListActivity(activity, continueLearnModel, false);
            BIUtils.onclickClassContinue(activity.getApplicationContext(), true, continueLearnModel.getClassId(), "0");// BI统计
        }
    }

    /**
     * 进入播放器
     *
     * @param activity
     * @param continueLearnModel 课程信息
     */
    private static void gotoPlay(Activity activity, ContinueLearnModel continueLearnModel) {
        ClassPorvider classPorvider = new ClassPorvider();
        Cursor cursor = null;
        Context context = activity.getApplicationContext();
        try {
            String userId = LoginUtils.getUserId(context);
            String selection = TLessonInfoColumns.USER_ID + "=? and " + TLessonInfoColumns.CLASS_ID + "=? and " + TLessonInfoColumns.LESSON_NUM + "=?";
            String[] selectionArgs = new String[]{userId, continueLearnModel.getClassId(), String.valueOf(continueLearnModel.getLastLessonNum())};
            cursor = classPorvider.query(URIList.LESSON_INFO_URI, null, selection, selectionArgs, null);
            if (cursor.moveToFirst()) {
                int lessonId = cursor.getInt(cursor.getColumnIndex(TLessonInfoColumns.LESSON_ID));
                String is_leave = cursor.getString(cursor.getColumnIndex(TLessonInfoColumns.IS_LEAVE));
                //已请假
                if ("true".equalsIgnoreCase(is_leave)) {
                    HJToast.makeText(context, R.string.prompt_class_leave, HJToast.LENGTH_LONG).show();
                    return;
                }

                int downloadStatus = getDownLoadstatus(activity.getApplicationContext(), continueLearnModel.getClassId(), String.valueOf(lessonId), userId);
                //未下载
                if (downloadStatus == Constant.DOWNLOAD_STATUS_CAN_DOWNLOAD) {
                    gotoLessonListActivity(activity, continueLearnModel, true);
                    return;
                }

                //正在下载或等待下载
                if (downloadStatus == OCSDownloadStatus.STATUS_STARTED || downloadStatus == OCSDownloadStatus.STATUS_PENDED || downloadStatus == OCSDownloadStatus.STATUS_UNZIP || downloadStatus == OCSDownloadStatus.STATUS_UNZIP_COMPLETE || downloadStatus == OCSDownloadStatus.STATUS_DECODE || downloadStatus == OCSDownloadStatus.STATUS_PENDING_UNZIP) {
                    HJToast.show(R.string.prompt_downloading1);// downloading
                    return;
                }

                BIUtils.onclickLesmainBegin(context, false, continueLearnModel.getClassId(), String.valueOf(lessonId));// BI统计
                PlayTool mPlayTool = new PlayTool();
                mPlayTool.play(activity, continueLearnModel.getClassId(), String.valueOf(lessonId));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null)
                cursor.close();
        }
    }

    /**
     * 得到课程的下载状态
     *
     * @param context
     * @param classId
     * @param lessonId
     * @param userId
     * @return
     */
    private static int getDownLoadstatus(Context context, String classId, String lessonId, String userId) {
        int status = TDownloadUtil.getIntByColumn(context, TClassDownloadColumns.DOWNLOAD_STATUS, classId, lessonId, userId);
        return status;
    }

    /**
     * 跳转到课程表界面
     *
     * @param activity
     * @param continueLearnModel 课程信息
     * @param promptedDownload   是否提示下载
     */
    private static void gotoLessonListActivity(Activity activity, ContinueLearnModel continueLearnModel, boolean promptedDownload) {
        String shortClassName = continueLearnModel.getShortClassName();
        if (TextUtils.isEmpty(shortClassName)) {
            shortClassName = continueLearnModel.getClassName();
        }
        Bundle bundle = new Bundle();
        bundle.putString(TClassColumns.CLASS_ID, continueLearnModel.getClassId());
        bundle.putString(TClassColumns.CLASS_SHORT_NAME, shortClassName); // 没有单元的课程，默认加一个单元，已课程名为单元名字
        bundle.putString(TClassColumns.CLASS_KEY, continueLearnModel.getClassKey());
        bundle.putString(TClassColumns.CLASS_KIND, continueLearnModel.getClassKind());// 是否已经毕业
        bundle.putBoolean("ACTIVATION_CONTINUE_LEARN", promptedDownload); //传递是否触发继续学按钮
        Intent intent = new Intent(activity, LessonListForCursorActivity.class);
        intent.putExtras(bundle);
        activity.startActivity(intent);
        AnimUtils.startActivityAnim(activity);
    }

    /************************************************************************开始学/继续学逻辑-end************************************************************************/

    public static void switchToHomeworkDetail(SchemeActivity schemeActivity, String url, boolean isTeacher) {
        String homeworkThreadId = getHomeworkThreadId(url);
        HomeworkDetailActivity.start(schemeActivity,url,homeworkThreadId, isTeacher);
        AnimUtils.startActivityAnim(schemeActivity);
    }

    private static String getHomeworkThreadId(String url){
        String[] split = url.split("/");
        if(split != null && split.length > 0){
            for (int i = 0; i < split.length; i++) {
                System.out.println(split[i]);
            }
            String str = split[split.length-1];
            System.out.println(str);
            String[] xx = str.split("\\?");
            if(xx != null && xx.length > 0){
                return xx[0];
            }
        }
        return "";
    }

    /**
     * 计算班级中用户学习进度
     * @param cursor
     * @return
     */
    public static double calculateMyStudyProgress(Cursor cursor){
        try{
            double progress = 0;
            //本地数据库保存的学习进度
            String classStudyProgress = cursor.getString(cursor.getColumnIndex(TClassColumns.CLASS_STUDY_PROGRESS));
            if(!TextUtils.isEmpty(classStudyProgress)){
                try{
                    progress = Double.parseDouble(classStudyProgress);
                }catch(Exception e){
                    progress = 0;
                }
                if(progress > 0){
                    return formatStudyProgress(progress);
                }
            }
            //根据已学习课程和课程总数计算学习进度
            int studyLessonNum = cursor.getInt(cursor.getColumnIndex(TClassColumns.CLASS_STUDYLESSON_NUM));
            int lessonNum = cursor.getInt(cursor.getColumnIndex(TClassColumns.CLASS_LESSON_NUM));
            if(studyLessonNum <= 0 || lessonNum <= 0){
                return 0;
            }
            progress = ((double) studyLessonNum / (double) lessonNum) * 100;
            if(progress < 0){
                return 0;
            }
            if(progress >= 100){
                return 100;
            }
            if(progress > 0 && progress < 1){
                return 1;
            }
            return formatStudyProgress(progress);
        }catch (Exception e){
            LogUtil.error("calculateMyStudyProgress",e);
        }
        return 0;
    }

    /**
     * 格式化学习进度
     * @param pro
     * @return
     */
    public static double formatStudyProgress(double pro){
        double p = DigitalUtil.round(pro, 1);
        if (p >= 100) {
            return 100;
        }
        if (p < 0) {
            return 0;
        }
        return p;
    }

    /**
     * 打开开心词场
     * @param context
     * @param cishuLink 跳转到词场的scheme
     */
    public static void gotoCiChang(Context context, String cishuLink) {
        if(context == null || TextUtils.isEmpty(cishuLink)){
            return;
        }
        LogUtil.error("ClassUtils","gotoCiChang: "+cishuLink);
        if(!IntentUtil.callWebBrowser(context,cishuLink)){
            IntentUtil.callWebBrowser(context, CommonConstant.URL_HUJIANG_WORD_GAME_DOWNLOAD);
        }
    }

    public static String getUserIconUrl(String url){
        if(TextUtils.isEmpty(url)){
            return url;
        }
        int index = url.indexOf("?");
        if(index < 0){
            url += "?";
        }else{
            url += "&";
        }
        url += "time=" + getUserIconUrlTime();
        return url;
    }

    public static long getUserIconUrlTime(){
        try{
            return PreferenceManager.getDefaultSharedPreferences(MainApplication.getContext()).getLong("avatarExtra", 0);
        }catch (Exception e){

        }
        return 0;
    }

    public static void saveUserIconUrlTime(long time) {
        try {
            PreferenceManager.getDefaultSharedPreferences(MainApplication.getContext()).edit().putLong("avatarExtra", time).commit();
        } catch (Exception e) {

        }
    }

    /**
     * 更新班级任务卡片数据源
     * @param sourceEntity 源缓存数据
     * @return  更新后的数据
     */
    public static TaskCardEntity updateTaskCardEntity(TaskCardEntity sourceEntity){
        if(sourceEntity == null || sourceEntity.getData() == null || sourceEntity.getData().getItems() == null){
            LogUtil.error(TAG,"sourceEntity == null || sourceEntity.getData() == null || sourceEntity.getData().getItems() == null !");
            return sourceEntity;
        }
        List<TaskBean> items = sourceEntity.getData().getItems();
        ArrayList<TaskBean> newTaskBeans = new ArrayList<>();
        for (int i = 0; i < items.size(); i++) {
            TaskBean taskBean = items.get(i);
            if(taskBean == null){
                continue;
            }
            String class_id = taskBean.getClass_id();
            List<ClassTaskModel.ContentEntity.TaskInfoEntity> taskInfo = ClassTaskBusiness.getTaskInfo(class_id);
            if(taskInfo == null){
                newTaskBeans.add(taskBean);
                continue;
            }
            taskBean.setTask_info(taskInfo);
            int learnedNum = taskBean.getTask_finish_count();
            for (int j = 0; j < taskInfo.size(); j++) {
                ClassTaskModel.ContentEntity.TaskInfoEntity taskInfoEntity = taskInfo.get(j);
                if(taskInfoEntity == null){
                    continue;
                }
                if(3 == taskInfoEntity.task_type && "false".equals(taskInfoEntity.is_finished)){
                    boolean lessonLearned = LessonBusiness.isLessonLearned(LoginUtils.getUserId(), taskInfoEntity.lesson_id);
                    if(lessonLearned){
                        learnedNum++;
                    }
                }
            }
            LogUtil.error(TAG,"learned num : "+learnedNum);
            if(learnedNum <= taskBean.getTask_count()){
                taskBean.setTask_finish_count(learnedNum);
            }
            newTaskBeans.add(taskBean);
        }
        sourceEntity.getData().setItems(newTaskBeans);
        return sourceEntity;
    }

    /**
     * 是否选择了学习首页
     * @return
     */
    public static boolean isSelectStudyHome(){
        return ClassPerferenceSmall.getInstance(MainApplication.getContext()).getSharedBoolean(ClassPerferenceChangKey.getIsSelectStudyKey(LoginUtils.getUserId()),true);
    }

    /**
     * 重置是否选择了学习首页标志
     * @param flag
     */
    public static void restSelectStudyHomeFlag(boolean flag){
        ClassPerferenceSmall.getInstance(MainApplication.getContext()).saveSharedBoolean(ClassPerferenceChangKey.getIsSelectStudyKey(LoginUtils.getUserId()),flag);
    }

    /**
     * BI打点需要转换一下反馈的当前用户状态
     * @param userState
     * @return
     */
    public static String getBIUserState(String userState){
        String state;
        if (userState.equals("1")) {
            state = "new";
        }else if (userState.equals("2")) {
            state = "student";
        }else if (userState.equals("3")){
            state = "graduate";
        }else {
            state = "";
        }
        return state;
    }

    public static TaskPostResutModel generateTaskPostResutModel(LearningSystemClassTaskSubmitModel model){
        if(model == null || model.getData() == null){
            return null;
        }
        LearningSystemClassTaskSubmitModel.LearningSystemClassTaskSubmitContent submitContent = model.getData();
        TaskPostResutModel resutModel = new TaskPostResutModel();
        resutModel.is_all_finish = submitContent.isAllFinish();
        resutModel.cover_small_icon = submitContent.getCoverSmallIcon();
        resutModel.growth_value = submitContent.getGrowthValue();
        resutModel.share_title = submitContent.getShareTitle();
        resutModel.share_description = submitContent.getShareDescription();
        resutModel.share_image_url = submitContent.getShareImageUrl();
        resutModel.share_link = submitContent.getShareLink();
        resutModel.level = submitContent.getLevel();
        if(submitContent.getFinishedUsers() != null && submitContent.getFinishedUsers().size() > 0){
            List<TaskPostResutModel.FinishedTaskUser> finished_users = new ArrayList<>();
            for(LearningSystemClassTaskSubmitModel.FinishedLSCTaskUser lscUser : submitContent.getFinishedUsers()){
                TaskPostResutModel.FinishedTaskUser finishedTaskUser = new TaskPostResutModel.FinishedTaskUser();
                finishedTaskUser.user_id = lscUser.getUserId();
                finishedTaskUser.user_Name = lscUser.getUserName();
                finishedTaskUser.user_ico = lscUser.getUserIcon();
                finishedTaskUser.is_can_praise = "0".equals(lscUser.getPraiseStatus());
                finished_users.add(finishedTaskUser);
            }
            resutModel.finished_users = finished_users;
        }
        return resutModel;
    }

    /**
     * 跳转到新课程列表
     *
     * @param activity
     * @param idString
     */
    public static void switchToLearningSystemLessonList(Activity activity, String idString) {
        if(activity == null || TextUtils.isEmpty(idString)){
            return;
        }
        LearningSystemLessonListActivity.start(activity,idString);
    }

    public static void gotoHomeWork(Activity act, String link) {
        if (TextUtils.isEmpty(link)) {
            HJToast.show(MainApplication.getContext().getString(R.string.lesson_list_toast_error));
            return;
        }
        String homeworkPostId = getHomeworkPostId(link);
        if(TextUtils.isEmpty(homeworkPostId)){
            return;
        }
        HomeworkDetailActivity.start(act, link, homeworkPostId, false);
    }


    private static String getHomeworkPostId(String homeworkUrl){
        int first = homeworkUrl.lastIndexOf("/")+1;
        int last = homeworkUrl.indexOf("?");
        if(first < last){
            return homeworkUrl.substring(first,last);
        }
        return null;
    }


    public static boolean isLessonTask(String taskType) {
        return StatusConstant.LEARNING_SYSTEM_TASK_ITEM_TYPE_LESSON.equalsIgnoreCase(taskType) || StatusConstant.LEARNING_SYSTEM_TASK_ITEM_TYPE_REVIEW.equalsIgnoreCase(taskType);
    }

    public static void gotoMarket(Context context){
        try {
            String packageName = context.getPackageName();
            Uri uri = Uri.parse("market://details?id=" + packageName);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            context.startActivity(intent);
        } catch (Exception e) {
            HJToast.show(R.string.market_not_install);
        }
    }

    public static boolean canShowMarketCommentDialog(){
        ClassPerferenceSmall instance = ClassPerferenceSmall.getInstance(MainApplication.getContext());
        if(!instance.getSharedBoolean(ClassPerferenceChangKey.getCanShowMarketCommentDialogKey(LoginUtils.getUserId()), true)){
            return false;
        }
        long currentVersionStartTime = instance.getSharedLong(ClassPerferenceConstantKey.CURRENT_VERSION_START_TIME, 0);
        if(System.currentTimeMillis() - currentVersionStartTime < 48 * 60 * 60 * 1000){
            return false;
        }
        if(!instance.getSharedBoolean(ClassPerferenceChangKey.getIsStudyLessonKey(LoginUtils.getUserId()), false)){
            return false;
        }
        return true;
    }
}