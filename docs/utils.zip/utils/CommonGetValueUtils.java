/**
 * 
 */
package com.hujiang.hjclass.utils;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;


/**
 * example:
    <code>
    String[] selection_columns = {DiscountExtendDBHelper.COLUMN_CARD_CODE};
    String[] selection_args = {code};
    DiscountExtendDBHelper helper = DiscountExtendDBHelper.getInstance(mContext);
    Object data = CommonGetValueUtils.getItemValue(helper.getReadableDatabase(), 
            DiscountExtendDBHelper.getTableName(), 
            CommonGetValueUtils.TYPE_INT, 
            DiscountExtendDBHelper.COLUMN_CARD_STATUS, 
            selection_columns, 
            selection_args, 
            null);
    if(data != null) {
        int status = (Integer) data;
        return (status != DiscountExtendDBHelper.CARD_STATUS_NEW);
    }
    </code>
 *
 */

/**
 * @author lidongkai
 *
 */
public class CommonGetValueUtils {
    public final static int TYPE_INT = 1;
    public final static int TYPE_LONG = 2;
    public final static int TYPE_STRING = 3;
    public final static int TYPE_DOUBLE = 4;

    public interface QueryValuesCallback {
        void fetchData(Cursor cursor);
    }

    public static Object getItemValue(Context context, Uri uri, int value_type, 
            String target_column, String[] selection_columns, String[] selection_args, QueryValuesCallback callback) {
        Object rt = null;
        Cursor c = getSimpleCursor(context, uri, target_column, selection_columns, selection_args);
        int count = (c != null) ? c.getCount() : 0;
        if(count > 0) {
            c.moveToFirst();
            switch(value_type) {
            case TYPE_INT:
                rt = c.getInt(c.getColumnIndexOrThrow(target_column));
                break;
            case TYPE_LONG:
                rt = c.getLong(c.getColumnIndexOrThrow(target_column));
                break;
            case TYPE_STRING:
                rt = c.getString(c.getColumnIndexOrThrow(target_column));
                break;
            case TYPE_DOUBLE:
                rt = c.getDouble(c.getColumnIndexOrThrow(target_column));
                break;
            }
            if(callback != null) {
                callback.fetchData(c);
            }
        }


        if (c != null) {
            c.close();
        }

        return rt;
    }

    private static Cursor getSimpleCursor(Context context, Uri uri, String target_column,
            String[] selection_columns, String[] selection_args) {
        Cursor rt = null;
        if(selection_columns == null || selection_args == null
                || selection_columns.length == 0 || selection_args.length == 0 
                ||selection_columns.length != selection_args.length)
            return rt;
        String[] projection = {
                target_column,
            };
        String selection = "";
        for(int i  = 0; i < selection_columns.length; i ++) {
            selection += selection_columns[i] + "=?";
            if(i < (selection_columns.length - 1))
                selection += " and ";

        }

        rt = context.getContentResolver().query(uri, projection, selection, selection_args, null);
        return rt;
    }

    public static Object getItemValue(SQLiteDatabase db, String table, int value_type, 
            String target_column, String[] selection_columns, String[] selection_args, QueryValuesCallback callback) {
        Object rt = null;
        Cursor c = getSimpleCursor(db, table, target_column, selection_columns, selection_args);
        int count = (c != null) ? c.getCount() : 0;
        if(count > 0) {
            c.moveToFirst();
            switch(value_type) {
            case TYPE_INT:
                rt = c.getInt(c.getColumnIndexOrThrow(target_column));
                break;
            case TYPE_LONG:
                rt = c.getLong(c.getColumnIndexOrThrow(target_column));
                break;
            case TYPE_STRING:
                rt = c.getString(c.getColumnIndexOrThrow(target_column));
                break;
            case TYPE_DOUBLE:
                rt = c.getDouble(c.getColumnIndexOrThrow(target_column));
                break;
            }
            if(callback != null) {
                callback.fetchData(c);
            }
        }
        if (c != null) {
            c.close();
        }

        return rt;
    }

    private static Cursor getSimpleCursor(SQLiteDatabase db, String table, String target_column,
            String[] selection_columns, String[] selection_args) {
        Cursor rt = null;
        if(db == null || table == null || table.isEmpty() 
                || selection_columns == null || selection_args == null
                || selection_columns.length == 0 || selection_args.length == 0 
                ||selection_columns.length != selection_args.length)
            return rt;
        String[] projection = {
                target_column,
            };
        String selection = "";
        for(int i  = 0; i < selection_columns.length; i ++) {
            selection += selection_columns[i] + "=?";
            if(i < (selection_columns.length - 1))
                selection += " and ";

        }


        rt = db.query(table, projection, selection, selection_args, null, null, null);
        return rt;
    }

    public static String getSingleStringFromDB(SQLiteDatabase db, String table, String keyColumn, String keyword, String targetColumn) {
        String rt = null;
        Object data = getSingleItemFromDB(db, table, CommonGetValueUtils.TYPE_STRING, keyColumn, keyword, targetColumn);
        if(data != null) {
            rt = (String) data;
        }
        return rt;
    }

    public static Integer getSingleIntFromDB(SQLiteDatabase db, String table, String keyColumn, String keyword, String targetColumn) {
        Integer rt = null;
        Object data = getSingleItemFromDB(db, table, CommonGetValueUtils.TYPE_INT, keyColumn, keyword, targetColumn);
        if(data != null) {
            rt = (Integer) data;
        }
        return rt;
    }

    public static Long getSingleLongFromDB(SQLiteDatabase db, String table, String keyColumn, String keyword, String targetColumn) {
        Long rt = null;
        Object data = getSingleItemFromDB(db, table, CommonGetValueUtils.TYPE_LONG, keyColumn, keyword, targetColumn);
        if(data != null) {
            rt = (Long) data;
        }
        return rt;
    }

    public static Double getSingleDoubleFromDB(SQLiteDatabase db, String table, String keyColumn, String keyword, String targetColumn) {
        Double rt = null;
        Object data = getSingleItemFromDB(db, table, CommonGetValueUtils.TYPE_DOUBLE, keyColumn, keyword, targetColumn);
        if(data != null) {
            rt = (Double) data;
        }
        return rt;
    }

    private static Object getSingleItemFromDB(SQLiteDatabase db, String table, int type, String keyColumn, String keyword, String targetColumn) {
        String[] selection_columns = {keyColumn};
        String[] selection_args = {keyword};
//        DiscountExtendDBHelper helper = DiscountExtendDBHelper.getInstance(context);
        Object data = CommonGetValueUtils.getItemValue(db, 
                table, 
                type, //CommonGetValueUtils.TYPE_STRING, 
                targetColumn, 
                selection_columns, 
                selection_args, 
                null);
        return data;
    }

}
