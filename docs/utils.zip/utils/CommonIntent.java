package com.hujiang.hjclass.utils;

import android.app.Activity;

import com.hujiang.loginmodule.LoginUtils;


/**
 * Created by Gavin on 13-10-26.
 */
public class CommonIntent {

    /**
     * 跳转到登录界面
     * @param activity
     */
    public static void intentToLogin(Activity activity) {
        LoginUtils.startLogin(activity);
    }


    /**
     * 需要登录的界面
     * @param activity
     * @return true 需要登录；false 已经登录
     */
    public static boolean requireLogin(Activity activity) {
        String userID = LoginUtils.getUserId(activity);
        if (userID.equals("")) {
            CommonIntent.intentToLogin(activity);
            return true;
        }
        return false;
    }




}
