package com.hujiang.hjclass.utils;

import android.text.TextUtils;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;

/**
 * Created by Gavin on 13-10-15.
 */
public class CommonParser {

    public static final String RESULT_STATUS = "status";
    public static final String RESULT_MESSAGE = "message";
    public static final String RESULT_CONTENT = "content";
    public static final String RESULT_DATA = "data";


    public static Hashtable parseContent(String jsonResult) {

        if (jsonResult == null || "".equals(jsonResult))
            return null;

        Hashtable htable = new Hashtable();
        try {
            JSONObject jsonObject = new JSONObject(jsonResult);
            htable.put(RESULT_STATUS, parseStringValue(jsonObject, RESULT_STATUS));
            htable.put(RESULT_MESSAGE, parseStringValue(jsonObject, RESULT_MESSAGE));
            if (jsonObject.has(RESULT_CONTENT)) {
                String conStr = jsonObject.getString(RESULT_CONTENT);
                if (!TextUtils.isEmpty(conStr)) {
                    htable.put(RESULT_CONTENT, parserJSONObject(jsonObject.getJSONObject(RESULT_CONTENT)));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return htable;
    }

    public static Hashtable parseData(String jsonResult) {

        if (jsonResult == null || "".equals(jsonResult))
            return null;

        Hashtable htable = new Hashtable();
        try {
            JSONObject jsonObject = new JSONObject(jsonResult);
            htable.put(RESULT_STATUS, parseStringValue(jsonObject, RESULT_STATUS));
            htable.put(RESULT_MESSAGE, parseStringValue(jsonObject, RESULT_MESSAGE));
            if (jsonObject.has(RESULT_DATA)) {
                String conStr = jsonObject.getString(RESULT_DATA);
                if (!TextUtils.isEmpty(conStr)) {
                    htable.put(RESULT_DATA, parserJSONObject(jsonObject.getJSONObject(RESULT_DATA)));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return htable;
    }

//    /**
//     *
//     * @param jsonResult
//     * @return
//     */
//    public static Hashtable parseResult(JSONObject jsonObject) {
//
//        if (jsonObject == null)
//            return null;
//
//        Hashtable htable = parserJSONObject(jsonObject.getJSONObject(RESULT_CONTENT)));
//
//
//        return htable;
//    }

    /**
     * 解析内容
     *
     * @param contentObject
     * @return
     */
    private static Hashtable parserJSONObject(JSONObject contentObject) {
        Hashtable htable = new Hashtable();
        try {
            for (Iterator ee = contentObject.keys(); ee.hasNext(); ) {
                String key = (String) ee.next();
                Object valueObj = contentObject.get(key);
                if (valueObj instanceof JSONObject) {
                    //如果对象是JSONObject, 递归
                    htable.put(key, parserJSONObject((JSONObject) valueObj));
                } else if (valueObj instanceof JSONArray) {
                    htable.put(key, parserJSONArray((JSONArray) valueObj));
                } else {
                    htable.put(key, "" + valueObj);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Log.e(Constant.LOG_TAG, e.getStackTrace().toString());
        }
        return htable;
    }

    /**
     * @param jsonArray
     * @return
     */
    private static ArrayList parserJSONArray(JSONArray jsonArray) {
        ArrayList aList = new ArrayList();
        try {
            for (int i = 0; i < jsonArray.length(); i++) {
                Object obj = jsonArray.get(i);
                if (obj instanceof JSONObject) {
                    aList.add(parserJSONObject((JSONObject) obj));
                } else if (obj instanceof JSONArray) {
                    aList.add(parserJSONArray((JSONArray) obj));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Log.e(Constant.LOG_TAG, e.getStackTrace().toString());
        }

        return aList;
    }

    /**
     * 解析参数值
     *
     * @param jsonObject
     * @param key
     * @return
     */
    private static String parseStringValue(JSONObject jsonObject, String key) {
        try {
            if (jsonObject == null || key == null || "".equals(key))
                return null;
            return "" + jsonObject.get(key);
        } catch (JSONException e) {
            e.printStackTrace();
            Log.e(Constant.LOG_TAG, e.getStackTrace().toString());
        }
        return "";
    }
}
