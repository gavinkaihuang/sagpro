package com.hujiang.hjclass.utils;

/**
 * Created by Gavin on 13-10-9.
 */
public class Constant {

	public static final boolean DEBUG = false;

	public static String DB_NAME = "hjclass";
	// 别名
	public static String APP_ALIAS = "android_hjclass3x";

	// 是否体验团版本
	public static boolean IS_EXPERIENCE_CORPS = false;

	// 体验团开始日期
	public static String EXPERIENCE_START_DATE = "2017-02-21";

	// 体验团有效期
	public static int EXPERIENCE_DAY = 14;

	// 听云key
	public final static String NBS_KEY = "8150f221db324584b9158b0385d6f108";

	public static int DATABASE_VERSION = 31;

	// 同步数据类型(课程记录:lesson_record)
	public static final String ACTION_LESSON_RECORD = "lesson_record";

	// 用户个人信息
	public static final String ACTION_USER_MESSAGE = "user_message";

	// 打卡
	public static final String ACTION_PUNCH = "punch";

	// 获取班级详情
	public static final String ACTION_SINGLE_CLASS_DETAIL = "single_class_detail";

	// 获取班级大纲
	public static final String ACTION_COURSE_OUTLINE = "course_outline";

	// 获取课程咨询信息
	public static final String ACTION_CLASS_CONSULT = "classcenter/ClassConsult";

	// 我的课程列表
	public static final String ACTION_MY_CLASS_LIST = "my_class_list";

	// 选课中心
	public static final String ACTION_CLASS_CENTER_LIST = "class_center_list";

	// 课程表
	public static final String ACTION_CLASS_LESSON_LIST = "class_lesson_list";

	// 课程分类
	public static final String ACTION_CLASS_CENTER_CLASSIFICATION = "class_center_classification";

	// 体验课课程分类
	public static final String ACTION_EXPERIENCE_CLASS_CENTER_CLASSIFICATION = "experience_class_center_classification";

	// 我的加密文件
	public static final String ACTION_TRUNK_FILE = "my_trunk_file";

	// 解绑设备
	public static final String ACTION_ADD_ANSWER = "add_answer";

	// 答疑追问
	public static final String ACTION_ADD_ANSWERASK = "add_answerask";
	public static final String ACTION_ADD_ANSWERASKANSWER = "add_answeraskanswer";
	public static final String ACTION_ADD_ANSWERCOMMENT = "add_answercomment";

	// 解绑设备
	public static final String ACTION_ADD_QUESTION = "add_question";
	// 解绑设备
	public static final String ACTION_UNBIND = "unbind";

	// 提交错误信息
	public static final String ACTION_SUBMIT_ERROR = "submit_error";

	// 提交错误信息
	public static final String ACTION_CHECK_IS_CLASS_OPEN = "check_is_in_class";

	// 体验班中推荐的购班级
	public static final String ACTION_SALE_RECOMMEND = "sale_recommend";

	// 消息中心
	public static final String ACTION_MESSAGE_CENTER = "message_center_list";// "message_center";

	//新消息中心参数
	public static final String EXTRA_MESSAGE_NEW_COUNT = "message_new_count";
	public static final String EXTRA_MESSAGE_HAS_NEW = "message_has_new";
	public static final String URL_NEW_MESSAGE_CENTER = "message/list";
	public static final String PRE_NEW_MESSAGE_TIMESTAMP = "pre_new_message_timestamp";

	// 讨论区
	public static final String ACTION_DISCUSS_CATEGORY = "discuss_category";
	public static final String ACTION_DISCUSS_ANSWER = "discuss_answer";
	public static final String ACTION_POSTS = "posts";
	// 体验课中心
	public static final String ACTION_EXPERIENCE = "experience";

	// 体验课中心分类列表
	public static final String ACTION_EXPERIENCE_CATEGORY_LIST = "experience_category_list";
	// 开通课程
	public static final String ACTION_EXPERIENCE_OPEN_CLASS = "experience_open_class";

	// 班级首页
	public static final String ACTION_CLASS_HOME_PAGE = "class_home_page";

	// splash
	public static final String ACTION_SPLASH = "splash";

	// 笔记列表
	public static final String ACTION_NOTE_LIST = "note_list";

	// 推荐
	public static final String ACTION_NOTE_RECOMMEND = "note_recommend";

	// 笔记收藏
	public static final String ACTION_NOTE_ADD_COLLECTION = "add_collection";

	// 笔记取消收藏
	public static final String ACTION_NOTE_CANCEL_COLLECTION = "cancel_collection";

	// 已毕业classId
	public static final String ACTION_MY_GRADUATE_CLASS = "my_graduate_class_list";

	// 学币订单列表
	public static final String ACTION_ORDER_XBORDER_LIST = "order_xborder_list";

	// 课程订单列表
	public static final String ACTION_ORDER_CLASSORDER_LIST = "order_classorder_list";

	// 取消订单
	public static final String ACTION_ORDER_CANCELORDER = "order_cancelorder";

	// 获取用户优惠劵
	public static final String ACTION_GET_USERCOUPON = "get_usercoupon";

	// 检查优惠劵
	public static final String ACTION_COUPON_CHECK_CODE = "coupon_check_code";

	// 订单确认
	public static final String ACTION_ORDER_CHECKORDER = "order_checkorder";

	// 创建课程订单
	public static final String ACTION_ORDER_CREATEORDER = "order_createorder";
	// 创建学币订单
	public static final String ACTION_ORDER_CREATEXBORDER = "order_createxborder";

	// 获取充值优惠信息
	public static final String ACTION_ORDER_XBORDER_PAGEINFO = "order_xborder_pageinfo";

	// 获取充值优惠信息
	public static final String ACTION_USER_DETAIL = "user/detail";
	// 沪江首页
	public static final String ACTION_GET_HJ_INDEX = "anonymous/microclass";

	// 我的班级
	public static final String ACTION_MY_CLASS = "class/myclass";

	// 获取体验中心分类及课程详情 4.0
	public static final String URL_EXPERIENCE_CENTER_CATEGORY_LIST = "classcenter/experiencecentercategorylist";
	// 获取体验中心热销列表 4.0
	public static final String URL_EXPERIENCE_CENTER_CLASS_LIST = "classcenter/experiencecenterclasslist";

	// 获取选课中心课程分类 4.0
	public static final String URL_CLASS_CENTER_CATEGORY_LIST = "classcenter/categorylist";
	// 获取选课中心课程列表
	public static final String URL_CLASS_CENTER_CLASS_LIST = "classcenter/classlist";
	//新选课中心数据
	public static final String URL_NEW_CLASS_CENTER = "classcenter/ClassCenterConfig";

	// 引导页分类列表获取
	public static final String URL_ANOYMOUS_CLASS_CATEGORY_LIST = "anonymous/categorylist";
	// 引导页根据分类返回课程列表
	public static final String URL_ANOYMOUS_CLASS_LIST = "anonymous/classlist?categoryId=";
	// 获取微课堂列表
	public static final String URL_MICRO_CLASS_LIST = "anonymous/microclasslist";
	// 获取班级排行榜
	public static final String URL_USER_RANKING = "user/Ranking?classID=";
	// 获取班级周排行榜
	public static final String URL_USER_RANKING_WEEK = "user/RankingWeekly?classID=";
	// 获取班级预约信息
	public static final String URL_CLASS_RESERVE = "reserve/class?classId=";
	// 获取我的班级列表预约信息
	public static final String URL_CLASS_LIST_RESERVE = "reserve/classlist";
	// 新首页打卡
	public static final String URL_MAIN_PUNCH = "class/TaskCard";
	// 选课中心二级默认分类
	public static final String URL_CLASSCENTER_SECOND_CATEGORY_DEFAULT = "classcenter/GetSubCategoryConfig?parentCategoryid=%s";
	// 选课中心二级分类
	public static final String URL_CLASSCENTER_SECOND_CATEGORY = "classcenter/GetSubCategoryConfig?parentCategoryid=%s&subCategoryid=%s";
	// 学习任务列表
	public static final String URL_CLASSTASK = "class/TaskInfo?classid=%s&actionid=%d";
	// 提交学习任务
	public static final String URL_CLASSTASK_POST = "class/PostTask";
	// 获取已完成今日任务的学生信息
	public static final String URL_FINISHEDCLASSMATESINFO = "class/FinishedTaskUserInfo?classid=%s";
	// 获取班级成员
	public static final String URL_GET_CLASS_MEMBERS = "user/GroupUser?classid=%s&pageindex=%d&pagesize=%d";
	// 选课中心一级分类ID的key
	public static final String KEY_FIRST_CATEGORY = "key_first_category";
	// 选课中心二级分类ID的key
	public static final String KEY_SECOND_CATEGORY = "key_second_category";
	// 选课中心三级分类ID的key
	public static final String KEY_THIRD_CATEGORY = "key_third_category";

	// 获取充值优惠信息
	public static final String ACTION_ORDER_CANPAY = "order_canpay";

	// 验证卡券
	public static final String ACTION_CHECK_COUPON_BY_LIST = "coupon/list";

	// 获取卡券信息
	public static final String ACTION_COUPON_DETAIL = "coupon/detail";

	// 获取卡券
	public static final String ACTION_GET_COUPON_LIST = "coupon/couponlist";

	// 获取用户状态
	public static final String ACTION_LOAD_USER_STATUS = "user/loadstatus";

	// 获取实物订单
	public static final String ACTION_MATERIAL_ORDERLIST = "mobileorder/MaterialOrderList?index=";

	// 获取课程延期信息
	public static final String ACTION_CLASS_DELAY_INFO = "class_delay_info";

	// 请求课程延期
	public static final String ACTION_CLASS_DELAY = "class_delay";

	// 请求社团发帖
	public static final String ACTION_SET_COMMUNITY_TOPIC = "set_community_topic";

	// 请求社团回复
	public static final String ACTION_REPLY_COMMUNITY_TOPIC = "reply_community_topic";

	// 请求社团分类获取
	public static final String ACTION_GET_TOPIC_BOARD = "get_topic_board";

	//课件评分
	public static final String ACTION_GET_MOBILELESSON_LESSONSUMMARY = "mobilelesson/LessonSummary";

	//课件评分
	public static final String ACTION_GET_DOWNLOADURL = "mobilelesson/LessonMedia?lessonId=%s&line=%s";
	//获取卡券列表
	public static final String ACTION_GET_COUPON_ORDER_LIST = "mobileorder/CouponOrderList?index=%d";

	public static final String LOG_TAG = "HJCLASS";

	// 我的网校
	public static final int MY_CLASS_KIND_ORDERD = 0;
	public static final int MY_CLASS_KIND_RUNNING = 1;
	public static final int MY_CLASS_KIND_OUTOFDATE = 2;

	// 选课中心
	public static final int CLASS_CODE_HOTTING = -1;
	public static final int CLASS_CODE_ALL = 0;

	// 加载到数据
	public static final String LOAD_DATA = "LOAD_DATA";

	// 加载数据的状态
	public static final int LOADING_DATA = 0;
	public static final int LOAD_DATA_EMPTY = 1;
	public static final int LOAD_DATA_ERROR = 2;
	public static final int LOAD_DATA_SUCCESS = 3;
	public static final int LOAD_DATA_DEFAULT = 4;

	// Broadcastreceiver action string
	public static final String ACTION_LOGIN_SUCCEED = "com.hujiang.class.action.login.success";
	public static final String ACTION_CLASSCATEGORY_POPUPWINDOW_DISMISS = "com.hujiang.class.action.classcategory.popupwindow.dismiss";

	// Setting Preference
	public static final String PRE_SETTING = "settings_preference";
	public static final String PRE_SETTING_COURSE_DOWNLOAD_SUCCESS_REMIND = "setting_course_download_success_remind";
	public static final String PRE_SETTING_ONLY_WIFI_DOWNLOAD = "setting_only_wifi_download";
	public static final String PRE_SETTING_STUDY_REMIND = "setting_study_remind";
	public static final String PRE_SETTING_STUDY_REMIND_TIME = "setting_study_remind_time";
	public static final String PRE_DOWNLOAD_ROUTE = "setting_download_route";

	// Class Sort Preference
	public static final String PRE_CLASS_SORT = "class_sort_preference";
	public static final String PRE_CLASS_SORT_CURRENT_TYPE = "class_sort_current_type";
	public static final String PRE_CLASS_SORT_CURRENT_STUDY_PERCENT_TYPE = "class_sort_current_study_percent_type";

	// Clear Graduated Class Files Preference
	public static final String CLEAR_GRADUATED_CLASS_FILES = "clear_graduated_class_files";

	// Class Category Preference
	public static final String PRE_CLASS_ = "class_category_list";
	public static final String PRE_CURRENT_CLASS_CATEGORY_CODE = "current_class_category_code";
	public static final String PRE_CURRENT_SUBCLASS_CATEGORY_CODE = "current_subclass_category_code";
	public static final String PRE_CURRENT_SUBCLASS_CATEGORY_NAME = "current_subclass_category_name";
	public static final String PRE_CLASS_CATEGORY_SYNC_TIME = "class_category_sync_time";
	public static final String PRE_CLASS_CATEGORY_LIST = "class_category_list";
	// Category cache file url
	public static final String CLASS_CATEGORY_CACHE_FILE_NAME = "category.txt";
	// Fragment
	public static final String FRAGMENT_IS_DIALOG = "isDialog";
	// 答疑模块
	public static final String FRAGMENT_QA_BASE_URL = "question_answer_base_url";
	public static final String FRAGMENT_QA_WHICH_FRAGMENT = "FRAGMENT_QA_WHICH_FRAGMENT";

	// >0 下载中； -1，已下载； －2， 在下载列表； -3， 在准备下载列表；-4 可以下载；－5， 暂停中, -6 草稿，无法下载, -7
	// 未发布，无法下载, -8 下载出错, 101 解压中
	// -9 等待中

 	//未发布
	public static final int DOWNLOAD_STATUS_APPEND_ISDRAFT = -6;
	//无下载数据
	public static final int DOWNLOAD_STATUS_CAN_DOWNLOAD=0;

	public static final int DOWNLOAD_STATUS_CAN_NOT_DOWNLOAD = -7;


	// 班级类型 0:已预约 1:进⾏行中 2:过期
	public static final int CLASS_KIND_ORDERD = 0;
	public static final int CLASS_KIND_RUNNING = 1;
	public static final int CLASS_KIND_FINISHED = 2;

	// 广播
	public static final String BROAD_CAST_UPDATE_USERINFO = "BROAD_CAST_UPDATE_USERINFO";

	public static final String BROAD_UPDATE_MY_CLASS_LESSON = "BROAD_UPDATE_MY_CLASS_LESSON";

	public static final String BROADCAST_PUSH_MSG_NOTICE = "android.intent.HJ_PUSHSERVICE_MSG"; // "android.intent.HJPUSH_NOTIFICATION"

	public static final String BROADCAST_NEW_MESSAGE = "com.hujiang.action.message";

	public static final String BROADCAST_NEW_MESSAGE_NOTICE = "com.hujiang.action.new_message_notice";

	public static final String BROADCAST_CLASS_TASK_CHANGE = "com.hujiang.action.class_task_change";

	public static final String BROADCAST_CLASS_TASK_STATUS_CHANGE = "com.hujiang.action.class_task_status_change";

	// 学习提醒时间更新
	public static final String BROADCAST_UPDATE_LEARNING_REMINDER = "com.hujiang.action.update_learning_reminder";

	// public static final String BROAD_LOAD_USER_TRUNK_FIILE =
	// "BROAD_LOAD_USER_TRUNK_FIILE";

	// 更新我的课程表信息
	public static final String BROAD_UPDATE_MY_LESSON_LIST = "BROAD_UPDATE_MY_LESSON_LIST";

	public static final String BROADCAST_CLASS_STATUS_ERROR = "com.hujiang.class.action.class_status_error";
	public static final int CLASS_STATUS_NO_TOKEN_CODE = 10;
	public static final int CLASS_STATUS_TOKEN_DISABLE = 1; // token失效
	public static final int CLASS_STATUS_TOKEN_EXPIRED = 2; // token过期
	public static final int CLASS_STATUS_OVER_FIVE_DEVICES_CODE = 11; // 该用户已经超过最大设备数量
	public static final int CLASS_STATUS_OVER_FIVE_ACCOUTS_CODE = 12; // 该设备已经超过最大用户数量
	// 返回我的班级数目，摇一摇打卡使用
	public static final String BROAD_CAST_MY_CLASS_NO = "BROAD_CAST_MY_CLASS_NO";

	// user logout广播，主界面更新
	public static final String BROAD_CAST_USER_LOGOUT = "BROAD_CAST_USER_LOGOUT";

	public static final String THREE_GENERATIONS_OF_COURSEWARE = "4";

	// 当系统时间被修改成大于服务器时间＋－三天，则给予错误码88020020提示
	public static final String TUNKFILE_PERMISSION_ERROR_1 = "88020020";
	public static final String UMENG_APP_RECOMMENDATION_ID = "56022";

	// 班级答疑Intent
	public static final String INTENT_QUESTION_ANSWER_CLASS_ID = "question_answer_class_id";
	public static final String BROADCAST_NEED_REFRESH_QUESTION = "BROADCAST_NEED_REFRESH_QUESTION";

	//班级成员列表请求返回值保存的KEY
	public static final String CLASSMEMBER_RESULT = "CLASSMEMBER_RESULT";

	// 班级列表无法下载播放 PING_CODE

	// the error code need ping
	public static final String ERROR_FAIL_HOSTNAME_CODE = "88020008";

	public static final String PACKAGE_NAME_CODE = "5905C4D82F906E3EBAAE194D536E0FDD";

	public static final String HJCLASS_PLAYER_TRACE = "hjclass_player_trace";// 播放器每日启动标志
																				// ==
																				// 每日听课学员数（打开播放器播放过课程的用户）
	public static final String HJCLASS_TRIAL_CLASS_TRACE = "hjclass_trial_class_trace";// 体验班每日启动标志
	public static final String HJCLASS_MARKETING_ACTIVITY_TRACE = "hjclass_marketing_activity_trace";// 销售活动每日启动标志
	public static final String HJCLASS_MESSAGE_CENTER_TRACE = "hjclass_message_center_trace";// 消息中心每日启动标志
	public static final String HJCLASS_LOGON_COUNT_PER_DAY_TRACE = "hjclass_logon_count_per_day_trace";// 每日登录用户数
	public static final String HJCLASS_VALID_LOGON_COUNT_PER_DAY_TRACE = "hjclass_valid_logon_count_per_day_trace";// 每日登录学员数（有开过课程的用户（包含免费和收费））

	// 消息参数
	public static final String EXTRA_MESSAGE_ID = "message_id";
	public static final String EXTRA_MESSAGE_URL = "message_url";
	public static final String EXTRA_MESSAGE_TITLE = "message_title";
	public static final String EXTRA_MESSAGE_SCHEME = "message_scheme";
	public static final String EXTRA_MESSAGE_COUNT = "message_count";
	public static final String EXTRA_MESSAGE_IS_ACTIVITY = "message_is_activity";
	public static final String EXTRA_MESSAGE_JUMP_FROM_LIST = "message_jump_from_list";
	public static final String PREF_MESSAGE_CENTER = "message_center";
	public static final String PREF_MESSAGE_KEY_MAX_TIME_STAMP = "max_message_stamp";
	public static final String PREF_MESSAGE_KEY_ACTIVITY_URL = "activity_url";

	// 播放器配置
	public static final int DEFAULT_PLAYER = 0x000; // 默认
	public static final int COMPATIBLE_PLAYER = 0x00001; // 兼容

	public static final String CLASS_GRADUATE_CLASS = "my_graduate_class";

	// 社团请求用于区分android/ios
	public static final int ST_ANDROID_SOURCE_CODE = 34;

	public static final String MESSAGE_TITLE = "message_title";

	public static final String CLASS_EXPERIENCE_ACTION = "Class/GetUserClassDetail";

	public static final String EXPERIENCE_LESSON_LIST = "class/GetExperienceLesson";

	public static final String UNREAD_ASK_NUM = "unread_question_ask_num";
	public static final String UNREAD_ANSWER_NUM = "unread_question_answer_num";
	// 获取模块图片
	public static final String ACTION_LOAD_CLASS_INDEX_BACKGROUD = "mobilecommon/ModuleImage";

	//请求用户点赞
	public static final String PRAISE_URL = "user/PraiseUser";

	//完成任务的同学
	public static  final String COMPLETED_TASK_USER = "class/FinishedTaskUserInfo";

	//学习报告
	public static  final String CLASS_REPORT = "class/ClassReport";

	//点赞
	public static  final String USER_PRAISE = "user/Praise";

	//导流
	public static  final String INIT_GUIDEPOPUP = "init/GuidePopup";
	//班级任务提醒广播
	public static  final String ACTION_CLASS_TASK_REMIND = "com.hujiang.hjclass.class_task_remind";

	//获取班级任务提醒接口
	public static  final String URL_CLASS_TASK_REMIND = "message/Taskremind";

	//全局搜索
	public static final String URL_GLOBAL_SEARCH = "search/all";

	//新手引导-推荐分类
	public static final String URL_GUIDE_RECOMMEND_CATEGORY = "novice/categorylist";

	//新手引导-推荐分类下的课程
	public static final String URL_GUIDE_RECOMMEND_COURSE = "novice/classlist";

	//是否跳转到推荐分类
	public static final String SWITCH_TO_RECOMMEND_CATEGORY = "switch_to_recommend_category";

	//获取群聊入口是否显示
	public static final String URL_GET_GROUP_CHAT_ENTRY = "MobileGroup/JoinGroup";

	// 课程收藏
	public static final String ACTION_LESSON_ADD_COLLECTION = "add_collect";

	// 课程取消收藏
	public static final String ACTION_LESSON_CANCEL_COLLECTION = "cancle_collect";

	// 活动单个banner接口
	public static final String URL_MOBILEMARKETING_BANNERINFO = "MobileMarketing/BannerInfo";

	//新增群公告
	public static final String URL_MOBILE_GROUP_ADD_GROUP_BULLETIN = "MobileGroup/AddGroupBulletin";

	//删除公告
	public static final String URL_MOBILE_GROUP_DELETED_GROUP_BULLETIN = "MobileGroup/DeleteGroupBulletin";

	//群聊天公告列表
	public static final String ACTION_GET_GROUP_BULLETIN_LIST = "MobileGroup/GetGroupBulletinList";

	//上传用户群聊发言时间
	public static final String ACTION_ADD_GROUP_SPEAK_TIME = "MobileGroup/AddGroupSpeakTime";

	// 获取匿名用户班级首页信息接口
	public static final String URL_EXPERIENCE_CLASSINDEX_INFO = "class/GetAnonymousClassDetail?classId=%d";

	// 新用户学霸榜页
	public static final String RANK_URL = "app/rank/RankingApp.aspx";

	// 新人作业区地址
	public static final String NEW_USER_HOMEWORK_URL = "job/job_list_app.aspx?classId=%s";

	// 新人公告栏地址
	public static final String NEW_USER_NOTICE_URL = "http://m.hujiang.com/ot/zt_starter_6/";

	// 试听列表
	public static final String ACTION_GET_ANONYMOUS_CLASSINFO_LIST = "class/GetAnonymousClassInfoList";

	//新用户随便看看引导跳转的类型
	public static final String USER_GUIDE_TYPE = "user_guide_type";

	// 获取待做任务信息 http://api2.class.hujiang.com/mobile/4.0/class/TaskDetail?classid=xxx
	public static final String GET_TO_DO_TASK_INFO = "class/TaskDetail?classid=%s";

	//班级报告
	public static final String GET_CLASS_REPORT = "class/ClassReport";

	//学习报告
	public static final String GET_STUDY_REPORT_LIST = "study/reportlist";

	//营销定时推送
	public static final String MARKET_REMIND_NOTICE = "com.hujiang.hjclass.market_remind_notice";

	//判断是否开启营销时钟提醒
	public static final String IS_MARKET_SETUP= "is_market_setup";

	//判断是否执行过营销时钟提醒
	public static final String IS_MARKET_DONE= "is_market_done";

	//上报学习时间
	public static final String POST_STUDY_DAY_RECORD= "user/StudyDayRecord";

	//上报学习课件时长
	public static final String POST_STUDY_TIME_RECORD= "user/StudyTimeRecord";

	//学习提醒数据获取
	public static final String GET_MOBILECOMMON_STUDYREMIND= "mobilecommon/StudyRemind";

	//获取同学动态列表
	public static final String GET_CLASSMATES_DYNAMIC= "user/ClassmateDynamic";

	//同学动态点赞
	public static final String CLASSMATES_DYNAMIC_PRAISE= "user/DynamicPraise";

	//获取同学动态入口数据
	public static final String GET_CLASSMATE_DYNAMIC_BAR ="user/ClassmateDynamicBar";

}
