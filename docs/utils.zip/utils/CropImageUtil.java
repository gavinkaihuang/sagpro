package com.hujiang.hjclass.utils;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import com.hujiang.hjclass.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CropImageUtil {

    private static final String PHOTO_DATE_FORMAT = "'IMG'_yyyyMMdd_HHmmss";
    private static final String PHOTO_CACHE_PATH = "HJApp" + File.separator + "hjclass" + File.separator + ".hjcache";
    public static final String SHARE_PIC_FILE = Environment.getExternalStorageDirectory().getPath() + File.separator +"HJApp" + File.separator + "hjclass" + File.separator + "share_hjclass_pic";
    public static final int TYPE_HOMEWORK = 110;
    public static final int TYPE_OTHERS = 111;

    public static Intent getCropImageIntent(Uri imageUri, Uri outUri, int photoSize) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(imageUri, "image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("outputX", photoSize);
        intent.putExtra("outputY", photoSize);
        intent.putExtra("scale", true);
        intent.putExtra("scaleUpIfNeeded", true);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, outUri);
        intent.putExtra("return-data", false);
        intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
        intent.putExtra("noFaceDetection", true); // no face detection
        return intent;
    }

    public static Intent getTakePhotoIntent(Uri imageUri) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        return intent;
    }

    public static Intent getChooseFromGalleryIntent(int photoSize) {
        final Intent intent = new Intent();
        if (Build.VERSION.SDK_INT < 19) {
            intent.setAction(Intent.ACTION_GET_CONTENT);
        } else {
            intent.setAction(Intent.ACTION_PICK);
        }
        intent.setType("image/*");
        // intent.putExtra("crop", "true");
        // intent.putExtra("aspectX", 1);
        // intent.putExtra("aspectY", 1);
        // intent.putExtra("outputX", photoSize);
        // intent.putExtra("outputY", photoSize);
        // intent.putExtra("scale", true);
        // intent.putExtra("return-data", false);
        // intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
        // intent.putExtra("noFaceDetection", false); // no face detection
        return intent;
    }

    public static Bitmap decodeUriToBitmap(Context context, Uri uri) {
        Bitmap bitmap = null;
        try {
            bitmap = BitmapFactory.decodeStream(context.getContentResolver().openInputStream(uri));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
        return bitmap;
    }

    public static String generateTempPhotoFileName() {
        final Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat dateFormat = new SimpleDateFormat(PHOTO_DATE_FORMAT, Locale.US);
        return "HJPhoto-" + dateFormat.format(date) + ".jpg";
    }

    public static String pathForTempPhoto(Context context, String fileName) {
        final File dir = context.getCacheDir();
        dir.mkdirs();
        final File f = new File(dir, fileName);
        return f.getAbsolutePath();
    }

    private Intent getCropIntent(Uri uri, int photoSize) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("scale", true);
        intent.putExtra("scaleUpIfNeeded", true);
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("outputX", photoSize);
        intent.putExtra("outputY", photoSize);
        return intent;
    }

    public static File getCacheFile(int type) {
        return new File(Environment.getExternalStorageDirectory().getPath() + File.separator + PHOTO_CACHE_PATH +"_"+ (type == TYPE_HOMEWORK ?"homework" : "other"));
    }

    public static final class ClearCacheThread extends Thread {
        @Override
        public void run() {
            LogUtil.error("", "clear cache thread start !");
            CropImageUtil.clearCacheFile(TYPE_OTHERS);
        }
    }

    public static void clearCacheFile(int type) {
        try {
            File cacheFile = getCacheFile(type);
            if (cacheFile.exists()) {
                File[] files = cacheFile.listFiles();
                for (File f : files) {
                    if (f.isFile()) {
                        f.delete();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Uri createImageFile() {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getCacheFile(TYPE_OTHERS);
        File image = null;
        try {
            if (!storageDir.exists()) {
                storageDir.mkdirs();
            }
            image = File.createTempFile(imageFileName, /* prefix */
                    ".jpg", /* suffix */
                    storageDir /* directory */
            );
            return Uri.fromFile(image);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Uri createImageFile(String postId, String userId) {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = postId+"_"+userId+"_JPEG_" + timeStamp + "_";
        File storageDir = getCacheFile(TYPE_HOMEWORK);
        File image = null;
        try {
            if (!storageDir.exists()) {
                storageDir.mkdirs();
            }
            image = File.createTempFile(imageFileName, /* prefix */
                    ".jpg", /* suffix */
                    storageDir /* directory */
            );
            return Uri.fromFile(image);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean deleteImageFile(String postId, String userId){
        File cacheDir = getCacheFile(TYPE_HOMEWORK);
        if(!cacheDir.exists()){
            return false;
        }
        File[] files = cacheDir.listFiles();
        int deleteNum = 0;
        if(files == null || files.length == 0){
            return false;
        }
        for (int i = 0; i < files.length; i++) {
            if(!files[i].isFile()){
                continue;
            }
            String absolutePath = files[i].getAbsolutePath();
            if(absolutePath.contains(postId+"_"+userId)){
                if(files[i].delete()){
                    deleteNum++;
                }
            }
        }
        LogUtil.error("","delete cache pic num : "+deleteNum);
        return deleteNum>0;
    }

    public static void checkSharePicExists(final Context context) throws Exception {
        final File file = new File(SHARE_PIC_FILE);
		if (file.exists()) {
			file.delete();
		}
        if (!file.exists()) {
            File path = file.getParentFile();
            if (!path.exists()) {
                path.mkdirs();
            }
            new Thread() {
                public void run() {
                    InputStream inputStream = null;
                    FileOutputStream outputStream = null;
                    try {
                        file.createNewFile();
                        int byteread = 0;
                        inputStream = context.getResources().openRawResource(R.raw.share_image_ico);
                        outputStream = new FileOutputStream(file);
                        byte[] buffer = new byte[1024];
                        while ((byteread = inputStream.read(buffer)) != -1) {
                            outputStream.write(buffer, 0, byteread);
                        }
                        outputStream.flush();
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (inputStream != null) {
                                inputStream.close();
                            }
                            if (outputStream != null) {
                                outputStream.close();
                            }
                        } catch (Exception e2) {
                        }
                    }
                };
            }.start();
        }

    }
}
