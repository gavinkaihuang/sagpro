package com.hujiang.hjclass.utils;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import android.content.ContentValues;

import com.google.gson.Gson;

/**
 * Created by Gavin on 13-10-10.
 */
public class DBContentValuesConvert {
	public interface IAppendValueCallback {
		void appendValueCallback(ContentValues cv);
	}

	/**
	 * 转换List to Content Values
	 * 
	 * @param aList
	 * @return
	 */
	public static ContentValues[] toContentValuesWithAppendValues(ArrayList aList, String key, String value) {
		ContentValues[] values = new ContentValues[aList.size()];
		for (int i = 0; i < aList.size(); i++) {
			Object obj = aList.get(i);
			if (obj instanceof Hashtable) {
				Hashtable oneTable = (Hashtable) obj;
				values[i] = toContentValues(oneTable, key, value, null);

			}
		}

		return values;
	}

	/**
	 * 转换List to Content Values appKey, appendValue 是临时增加的插入差数对
	 * 
	 * @param aList
	 * @return
	 */
	public static ContentValues[] toContentValues(ArrayList aList, String appendKey, String appendValue) {
		return toContentValues(aList, appendKey, appendValue, null);
	}

	/**
	 * 给现有的 ContentValues 数组每项增加一个键值对
	 * 
	 * @param cvs
	 * @param appendKey
	 *            key
	 * @param appendValue
	 *            value
	 * @return
	 */
	public static ContentValues[] addContentValues(ContentValues[] cvs, String key, String value) {
		for (int i = 0; i < cvs.length; i++) {
			cvs[i].put(key, value);
		}
		return cvs;
	}

	public static ContentValues[] toContentValues(ArrayList aList, String appendKey, String appendValue, IAppendValueCallback callback) {
		ContentValues[] values = new ContentValues[aList.size()];
		for (int i = 0; i < aList.size(); i++) {
			Object obj = aList.get(i);
			if (obj instanceof Hashtable) {
				Hashtable oneTable = (Hashtable) obj;
				values[i] = toContentValues(oneTable, appendKey, appendValue, null);

				if (callback != null) {
					callback.appendValueCallback(values[i]);
				}
			}
		}

		return values;
	}

	public static ContentValues[] toContentValues(ArrayList aList, Hashtable<String, String> filerKeys) {
		ContentValues[] values = new ContentValues[aList.size()];
		for (int i = 0; i < aList.size(); i++) {
			Object obj = aList.get(i);
			if (obj instanceof Hashtable) {
				Hashtable oneTable = (Hashtable) obj;
				values[i] = toContentValues(oneTable, null, null, filerKeys);
			}
		}
		return values;
	}

	public static ContentValues toContentValues(Hashtable htable, String appendKey, String appendValue, Hashtable<String, String> filerKeys) {
		// ContentValues values[] = new ContentValues(htable);
		ContentValues values = new ContentValues();
		Enumeration ee = htable.keys();
		int i = 0;
		while (ee.hasMoreElements()) {
			String key = "" + ee.nextElement();
			// 过滤不需要的key
			if (filerKeys != null && filerKeys.contains(key))
				continue;

			String value = "" + htable.get(key);
			values.put(key, value);
		}
		if (appendKey != null)
			values.put(appendKey, appendValue);
		return values;
	}

	public static ContentValues[] toContentValuesOneLevel(ArrayList aList, Hashtable<String, String> filerKeys) {
		ContentValues[] values = new ContentValues[aList.size()];
		for (int i = 0; i < aList.size(); i++) {
			Object obj = aList.get(i);
			if (obj instanceof Hashtable) {
				Hashtable oneTable = (Hashtable) obj;
				values[i] = toContentValuesOneLevel(oneTable, null, null, filerKeys);
			}
		}
		return values;
	}

	public static ContentValues toContentValuesOneLevel(Hashtable htable, String appendKey, String appendValue, Hashtable<String, String> filerKeys) {
		ContentValues values = new ContentValues();
		Enumeration ee = htable.keys();
		Gson gson = new Gson();
		while (ee.hasMoreElements()) {
			String key = "" + ee.nextElement();
			// 过滤不需要的key
			if (filerKeys != null && filerKeys.contains(key))
				continue;
			Object obj = htable.get(key);
			StringBuilder value = new StringBuilder();
			if(obj instanceof Hashtable){
				value.append(gson.toJson(obj));
			}else if (obj instanceof ArrayList){
				ArrayList al = ((ArrayList) obj);
				int size = al.size();
				for (int j = 0; j < size; j++) {
					if(size == 1){
						value.append("["+gson.toJson(al.get(j))+"]");
						break;
					}
					if (j == 0) {
						value.append("["+gson.toJson(al.get(j))+",");
					} else if (j == size - 1) {
						value.append(gson.toJson(al.get(j)) + "]");
					} else {
						value.append(gson.toJson(al.get(j)) + ",");
					}
				}
			} else {
				value.append(obj + "");
			}
			values.put(key, value.toString());
		}
		if (appendKey != null)
			values.put(appendKey, appendValue);
		return values;
	}

	
	public static ContentValues toContentValues2(Hashtable htable) {
		// ContentValues values[] = new ContentValues(htable);
		ContentValues values = new ContentValues();
		Enumeration ee = htable.keys();
		int i = 0;
		while (ee.hasMoreElements()) {
			String key = "" + ee.nextElement();

			String value = "" + htable.get(key);
			values.put(key, value);
		}
		return values;
	}

}
