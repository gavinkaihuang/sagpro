package com.hujiang.hjclass.utils;

import java.util.Date;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.hujiang.hjclass.db.ClassPorvider;
import com.hujiang.BaseTableColumns;
import com.hujiang.hjclass.db.tables.TPuncherLogColumns;
import com.hujiang.hjclass.db.tables.URIList;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.util.DateUtil;
import com.hujiang.util.StringUtils;


/**
 * Created by Gavin on 13-11-13.
 */
public class DBPunchUtils {

//    private static final String PREFERNECE_PUNCH_FILE = "PREFERNECE_PUNCH_FILE";
//
//    //可以打卡的班级文件
//    private static final String PREFERNECE_PUNCH_CLASS_IDS_FILE = "PREFERNECE_PUNCH_CLASS_IDS_FILE";
//
//    private static final String APP_PUNCH = "APP_PUNCH";

    private static final int MAX_IN_CLASS_PUNCHED_TIMES = 5;//班内最多打卡次数
    
    private static final String TIME_START = " 00:00:00";
    
    private static final String TIME_END = " 23:59:59";
    
    public static final String DEFAULT_PUNCH_ABLE = "1";
    
    public static final String DEFAULT_PUNCH_DISABLE = "0";

//    /**
//     * 用户打卡key
//     *
//     * @param context
//     * @return
//     */
//    public static String getUserAppPunchKey(Context context) {
//        String userID = LoginUtils.getUserId(context);
//        return APP_PUNCH + "_" + userID;
//    }

    public static boolean punch(Context context, String classID) {
    	String punchTime = DateUtil.getNowDateTimeStringEn2();
    	return punch(context, classID, punchTime);
    }

    /**
     * 打卡动作
     *
     * @param context
     * @param classID
     * @return
     */
    public static boolean punch(Context context, String classID, String punchTime) {
    	checkPunchClassRecord(context, classID, DEFAULT_PUNCH_ABLE);
    	
    	String userID = LoginUtils.getUserId(context);
    	String dateValue = DateUtil.getDateStringFromDate(new Date());
        String startDateValue = dateValue + TIME_START;
        String endDateValue = dateValue + TIME_END;
    	ClassPorvider classPorvider = new ClassPorvider();
    	
    	 ContentValues contentValues = new ContentValues();
         contentValues.put(TPuncherLogColumns.PUNCHER_TIME, punchTime);
         classPorvider.update(URIList.PUNCHER_LOG_URL, contentValues,
        		 TPuncherLogColumns.CLASS_ID + "=? and " + TPuncherLogColumns.USER_ID + "=? and (" + TPuncherLogColumns.RECORD_DATE + ">=? and " 
        				 + TPuncherLogColumns.RECORD_DATE + "<?)",
        				 new String[]{"" + classID, userID, startDateValue, endDateValue});
    	
         return true;
    }
    
    public static int checkPunchClassRecord(Context context, String classID) {
    	return checkPunchClassRecord(context, classID, DEFAULT_PUNCH_ABLE);
    }
    
    /**
     * 检查打卡记录，如果有的话，返回1
     * 如果没有记录，插入一条
     * @param context
     * @param classID
     * @return
     */
    public static int checkPunchClassRecord(Context context, String classID, String puncherAble) {
    	String userID = LoginUtils.getUserId(context);
    	 ClassPorvider classPorvider = new ClassPorvider();
         String dateValue = DateUtil.getDateStringFromDate(new Date());
         String startDateValue = dateValue + TIME_START;
         String endDateValue = dateValue + TIME_END;
         Cursor cursor = null;
         try {
             cursor = classPorvider.query(URIList.PUNCHER_LOG_URL, BaseTableColumns.listColumns(TPuncherLogColumns.class),
            		 TPuncherLogColumns.CLASS_ID + "=? and " + TPuncherLogColumns.USER_ID + "=? and (" + TPuncherLogColumns.RECORD_DATE + ">=? and " 
            				 + TPuncherLogColumns.RECORD_DATE + "<?)", new String[]{"" + classID, userID, startDateValue, endDateValue}, "1");
             if (cursor.moveToFirst()) {
            	 String dbPuncherAble = cursor.getString(cursor.getColumnIndex(TPuncherLogColumns.PUNCHER_ABLE));
            	 if (dbPuncherAble.equals(puncherAble)) {
            		 return 1;
            	 } else {
            		 //服务器返回无法打卡，而本地可以打卡，更新打卡标记
            		 String id = cursor.getString(cursor.getColumnIndex(TPuncherLogColumns.ID));
            		 ContentValues contentValues = new ContentValues();
                     contentValues.put(TPuncherLogColumns.PUNCHER_ABLE, puncherAble);
                     classPorvider.update(URIList.PUNCHER_LOG_URL, contentValues,
                    		 TPuncherLogColumns.ID + "=?",
                    				 new String[]{id});
                     return 1;
            	 }
             } else {
            	 //没有记录，插入一条记录
            	 ContentValues contentValues = new ContentValues();
                 contentValues.put(TPuncherLogColumns.USER_ID, userID);
                 contentValues.put(TPuncherLogColumns.CLASS_ID, classID);
                 contentValues.put(TPuncherLogColumns.RECORD_DATE, startDateValue);
                 contentValues.put(TPuncherLogColumns.PUNCHER_ABLE, puncherAble);
                 classPorvider.insert(URIList.PUNCHER_LOG_URL, contentValues);
                 return 1;
             }
         } catch (Exception e) {
             e.printStackTrace();
         }  finally {
        	 if (cursor != null)
        		 cursor.close();
         }
         return 0;
    }
    
    /**
     * 初始化我的班级打卡信息
     * @param context
     */
    public static void initMainPunchInfo(Context context) {
    	checkPunchClassRecord(context, "0", "1");
    }
    
    /**
     * 清除打卡记录
     * @param context
     */
    public static void cleanPunchRecord(Context context) {
    	ClassPorvider classPorvider = new ClassPorvider();
    	classPorvider.delete(URIList.PUNCHER_LOG_URL, null, null);
    }
    

//    /**
//     * 记录打卡数据
//     *
//     * @param context
//     * @param classID
//     * @return
//     */
//    private static boolean punchRecord(Context context, String classID) {
//
//        StringBuffer sb = new StringBuffer();
//        String record = getPunchRecord(context);
//        String[] punchClassIDS = record.split("\\|");
//        if (punchClassIDS[0].equals("")) {
//            sb.append(DateUtil.getNowDateString() + "|" + classID);
//        } else {
//            sb.append(record + "|" + classID);
//        }
//
//        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERNECE_PUNCH_FILE,
//                Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//        String punchKey = getUserAppPunchKey(context);
//        editor.putString(punchKey, sb.toString());
//        editor.commit();
//        
//        LogFileUtils.writeToFile(">>>>PunchUtils punchRecord=" + DBPunchUtils.getPunchRecord(context));
//
//        return true;
//    }

//    /**
//     * 清除昨天打卡记录
//     *
//     * @param context
//     */
//    public static void cleanPunchInfo(Context context) {
//        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERNECE_PUNCH_FILE,
//                Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//        String punchKey = getUserAppPunchKey(context);
//        editor.putString(punchKey, "");
//        editor.commit();
//    }

//    /**
//     * 取得今天打卡的次数
//     *
//     * @param context
//     * @param isAppPunch 是否应用级别打卡，false为班级内打卡
//     * @return
//     */
//    public static int getPunchedTimes(Context context, boolean isAppPunch) {
//        String record = getPunchRecord(context);
//
//        String[] punchClassIDS = record.split("\\|");
//        if (punchClassIDS.length < 1 || punchClassIDS[0].equals("")) {
//            return 0;//都未打卡
//        }
//
//        String date = punchClassIDS[0];
////        DebugUtils.println("punch date " + date);
////        DebugUtils.println("now date " + DateUtil.getNowDateString());
//        long diff = Math.abs(DateUtil.differenceDays(DateUtil.getNowDateString(), date));
//        if (diff >= 1) {
//            //今天没有打过卡, 清除原来记录
//            cleanPunchInfo(context);
//            return 0;
//        }
//
//        int punchedNo = 0;
//        for (int i = 1; i < punchClassIDS.length; i++) {
//            String oneID = punchClassIDS[i];
//            if (isAppPunch) {
//                if (oneID.equals("0")) {
//                    punchedNo = 1;//应用已经打卡
//                    break;
//                }
//            } else {
//                if (!oneID.equals("0")) {
//                    punchedNo += 1;//班内打卡+1
//                }
//
//            }
//        }
//        return punchedNo;
//    }

//    /**
//     * 用户是否打过卡
//     *
//     * @param context
//     * @param classID
//     * @return
//     */
//    public static boolean isUserPunched(Context context, String classID) {
//    	boolean isPunchered = false;
//    	Cursor cursor = getPuncherCursor(context, classID);
//    	try {
//			if (cursor != null && cursor.moveToFirst()) {
//				isPunchered = true;
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			if (cursor != null)
//				cursor.close();
//		}
////    	 String userID = LoginUtils.getUserId(context);
////         ClassPorvider classPorvider = new ClassPorvider();
////         String dateValue = DateUtil.getDateStringFromDate(new Date());
////         String startDateValue = dateValue + TIME_START;
////         String endDateValue = dateValue + TIME_END;
////         Cursor cursor = null;
////         try {
////             cursor = classPorvider.query(URIList.PUNCHER_LOG_URL, BaseTableColumns.listColumns(TPuncherLogColumns.class),
////            		 TPuncherLogColumns.CLASS_ID + "=? and " + TPuncherLogColumns.USER_ID + "=? and (" + TPuncherLogColumns.PUNCHER_TIME + ">=? and " 
////            				 + TPuncherLogColumns.PUNCHER_TIME + "<?", new String[]{"" + classID, userID, startDateValue, endDateValue}, "1");
////             if (cursor.moveToFirst()) {
////            	 isPunchered = true;
////             }
////         } catch (Exception e) {
////             e.printStackTrace();
////         } finally {
////             if (cursor != null)
////                 cursor.close();
////         }
//         return isPunchered;
//    }
    
    /**
     * 取得打卡记录
     * @param context
     * @param classID
     * @return
     */
    private static Cursor getPuncherCursor(Context context, String classID) {
    	String userID = LoginUtils.getUserId(context);
        ClassPorvider classPorvider = new ClassPorvider();
        String dateValue = DateUtil.getDateStringFromDate(new Date());
        String startDateValue = dateValue + TIME_START;
        String endDateValue = dateValue + TIME_END;
        Cursor cursor = null;
        try {
            cursor = classPorvider.query(URIList.PUNCHER_LOG_URL, BaseTableColumns.listColumns(TPuncherLogColumns.class),
           		 TPuncherLogColumns.CLASS_ID + "=? and " + TPuncherLogColumns.USER_ID + "=? and (" + TPuncherLogColumns.RECORD_DATE + ">=? and " 
           				 + TPuncherLogColumns.RECORD_DATE + "<?)", new String[]{"" + classID, userID, startDateValue, endDateValue}, "1");
            if (cursor.moveToFirst())
            	return cursor;
            else {
            	cursor.close();
            	return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } 
        return null;
    }
    
    /**
     * 取得班级的打卡数目
     * @param context
     * @return
     */
    public static int getLessonPuncherNumber(Context context) {
    	String userID = LoginUtils.getUserId(context);
        ClassPorvider classPorvider = new ClassPorvider();
        String dateValue = DateUtil.getDateStringFromDate(new Date());
        String startDateValue = dateValue + TIME_START;
        String endDateValue = dateValue + TIME_END;
        Cursor cursor = null;
        try {
            cursor = classPorvider.query(URIList.PUNCHER_LOG_URL, BaseTableColumns.listColumns(TPuncherLogColumns.class),
           		 TPuncherLogColumns.CLASS_ID + "<>? and " + TPuncherLogColumns.USER_ID + "=? and (" + TPuncherLogColumns.PUNCHER_TIME + ">=? and " 
           				 + TPuncherLogColumns.PUNCHER_TIME + "<?)", new String[]{"" + 0, userID, startDateValue, endDateValue}, "20");
            return cursor.getCount();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return 0;
    }

//    /**
//     * 取得用户的打卡记录
//     *
//     * @param context
//     * @return
//     */
//    public static String getPunchRecord(Context context) {
//        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERNECE_PUNCH_FILE,
//                Context.MODE_PRIVATE);
//        String punchKey = getUserAppPunchKey(context);
//        String value = sharedPreferences.getString(punchKey, "");
////        DebugUtils.println("Punch record " + value);
//        return value;
//    }

    /**
     * 是否有打卡记录
     * @param context
     * @param classID
     * @return
     */
    public static boolean hasPuncherRecord(Context context, String classID) {
    	Cursor cursor = null;
    	try {
			cursor = getPuncherCursor(context, classID);
			//没有可以打卡的标记，无法打卡
			if (cursor == null)
				return false;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (cursor != null)
				cursor.close();
		}
    	
    	return true;
    }
    
    /**
     * 是否可以打卡
     * @param context
     * @param classID
     * @return
     */
    public static boolean canPuncher(Context context, String classID) {
    	Cursor cursor = null;
    	try {
			cursor = getPuncherCursor(context, classID);
//			DebugUtils.println("1---------canPuncher classID=" + classID);
			//没有可以打卡的标记，无法打卡
			if (cursor == null)
				return false;
			
//			DebugUtils.println("2---------canPuncher classID=" + classID);

			String puncherAble = StringUtils.notNull(cursor.getString(cursor.getColumnIndex(TPuncherLogColumns.PUNCHER_ABLE)));
			
//			DebugUtils.println("3---------canPuncher puncherAble=" + puncherAble);
			//课程无法打卡
			if (puncherAble.equals("0"))
				return false;
			
			//没有打卡时间，可以打卡
			String puncherTime = StringUtils.notNull(cursor.getString(cursor.getColumnIndex(TPuncherLogColumns.PUNCHER_TIME)));
//			DebugUtils.println("4---------canPuncher puncherTime=" + puncherTime);
			if (!puncherTime.equals(""))
				return false;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (cursor != null)
				cursor.close();
		}
    	
    	
    	if (classID.equals("0")) {
    		//班级的话，返回可以打卡
    		return true;
    	} else {
    		int punchedNumber = getLessonPuncherNumber(context);
    		if (punchedNumber >= MAX_IN_CLASS_PUNCHED_TIMES)
    			return false;
    		else 
    			return true;
    	}
    	
    	
    	
    	
//        String record = getPunchRecord(context);
//
//        String[] punchClassIDS = record.split("\\|");
//        if (punchClassIDS.length < 1 || punchClassIDS[0].equals("")) {
//            return true;//未打过卡
//        }
//
//        String date = punchClassIDS[0];
//        long diff = Math.abs(DateUtil.differenceDays(DateUtil.getNowDateString(), date));
//        if (diff > 1) {
//            //超过一天，全部重新打卡
//            return true;
//        }
//
////        boolean punched = false;
//        int inClassPunchedTimes = 0;
//        for (int i = 1; i < punchClassIDS.length; i++) {
//            String oneID = punchClassIDS[i];
//            //已经打过卡
//            if (oneID.equals(classID)) {
//                return false;
//            }
//            if (!oneID.equals("0"))
//                inClassPunchedTimes += 1;
//
//        }
//        if (inClassPunchedTimes >= MAX_IN_CLASS_PUNCHED_TIMES)
//            return false;
//
//        return true;
    }
//
//    /**
//     * ----------可以打卡班级
//     */
//
//    /**
//     * 保存可以打卡的班级
//     *
//     * @param context
//     * @param classID
//     * @return
//     */
//    public static boolean saveServerCanPunchClass(Context context, String classID) {
//        String userID = LoginUtils.getUserId(context);
//        String key = "PREFERNECE_PUNCH_CLASS_IDS_FILE_" + userID + "_" + classID;
//        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERNECE_PUNCH_CLASS_IDS_FILE,
//                Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//        String punchKey = getUserAppPunchKey(context);
//        editor.putString(key, "true");
//        editor.commit();
//
//        return true;
//    }
//
//    /**
//     * 班级是否可以打卡
//     * @param context
//     * @param classID
//     * @return
//     */
//    public static String isClassServerCanPunch(Context context, String classID) {
//        String userID = LoginUtils.getUserId(context);
//        String key = "PREFERNECE_PUNCH_CLASS_IDS_FILE_" + userID + "_" + classID;
//        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERNECE_PUNCH_CLASS_IDS_FILE,
//                Context.MODE_PRIVATE);
//        String value = sharedPreferences.getString(key, "false");
//        return value;
//    }


}
