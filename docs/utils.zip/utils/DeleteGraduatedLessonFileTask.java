package com.hujiang.hjclass.utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Hashtable;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.hujiang.hjclass.AppConfig;
import com.hujiang.hjclass.adapter.model.SDcardInfo;
import com.hujiang.loginmodule.LoginUtils;

public class DeleteGraduatedLessonFileTask extends Thread {

	private String FileDir = File.separator + "HJApp" + File.separator + "hjclass" + File.separator;
	private Context context;
	private ArrayList<SDcardInfo> mSDcardInfoList = new ArrayList<SDcardInfo>();

	public DeleteGraduatedLessonFileTask(Context context) {
		super();
		this.context = context;
	}

	@Override
	public void run() {
		try {
			//Log.d("z1", "deleting started");
			Hashtable htable = PostDataGenerater.generateGraduatedClassIds(context);
			String data = ServerConnecter.generateClassJSonParams(htable);
			//Log.d("z1", "data:" + data);
			String result = ServerConnecter.postContentBody(AppConfig.HOST_URL, data);
			//Log.d("z1", "result:" + result);
			Hashtable resultTable = CommonParser.parseContent(result);
			Hashtable content = (Hashtable) resultTable.get("content");
			String classIds = (String) content.get("class_list");
			if (TextUtils.isEmpty(classIds)) {
				Log.e("z1", "error: classIds = null or ''");
			}else{
				ArrayList<SDcardInfo> list = loadSdcardList();
				for (SDcardInfo sDcardInfo : list) {
					//Log.d("z1", sDcardInfo.path);
					String[] split = classIds.split(",");
					Log.i("z1", split.length+"");
					for (int i = 0; i < split.length; i++) {
						Log.i("z1", i + ":" + split[i]);
						deleteFile(sDcardInfo.path + FileDir + split[i]);
					}
				}
			}
			context.getSharedPreferences(Constant.CLEAR_GRADUATED_CLASS_FILES, Context.MODE_PRIVATE).edit().putBoolean(new SimpleDateFormat("yyyyMMdd").format(System.currentTimeMillis())+ LoginUtils.getUserId(context), true).commit();
			//Log.d("z1", "delete graduated class files finished successful");
		} catch (Exception e) {
			e.printStackTrace();
			//Log.e("z1", "delete graduated class files error:" + e.toString());
		}
	}

	/**
	 * 加载本机context.getString(R.string.setting_sdcard_sd)列表
	 */
	@SuppressLint("NewApi")
	private ArrayList<SDcardInfo> loadSdcardList() {
		mSDcardInfoList = SDCardUtils.loadSdcardList(context);
		return mSDcardInfoList;
	}

	/**
	 * 删除文件、文件夹
	 */
	public static void deleteFile(String path) {
		File file = new File(path);
		if (file.isDirectory()) {
			File[] ff = file.listFiles();
			for (int i = 0; i < ff.length; i++) {
				deleteFile(ff[i].getPath());
			}
		}
		file.delete();
	}

}
