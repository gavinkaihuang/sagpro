package com.hujiang.hjclass.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;

import com.hujiang.hjclass.MainApplication;
import com.hujiang.util.NetWorkConfig;

import java.util.Hashtable;

public class DeviceInfo {


	private static String  APP_INFO;

	public static String getDeviceID(Context context)
	{
		String deviceID=null;
		final TelephonyManager tm = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
//        if(tm!=null)
//        {
//            deviceID=tm.getDeviceId();
//        }
		if(deviceID==null||deviceID.startsWith("0"))
		{
			deviceID= Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
		}
		return deviceID.toLowerCase();
	}


	public static String getVersionName(Context context) {
		PackageManager manager = context.getPackageManager();
		try {
			PackageInfo info = manager.getPackageInfo(context.getPackageName(), 0);
			return info.versionName;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	public static Hashtable getProjectBaseInfo(Context context) {
		Hashtable htable = new Hashtable();
		PackageManager manager = context.getPackageManager();
		try {
			PackageInfo info = manager.getPackageInfo(context.getPackageName(), 0);
			String packageName = info.packageName;
			int versionCode = info.versionCode;
			String versionName = info.versionName;
			htable.put("package_name", packageName);
			htable.put("version_code", versionCode);
			htable.put("version_name", versionName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return htable;
	}

	/**
	 * Get Phone's IMEI
	 *
	 * @param context
	 *            (Activity is a content)
	 * @return
	 */
	public static String getIMEI(Context context) {
		if (context == null)
			return null;
		TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		return telephonyManager.getDeviceId();
	}

	/**
	 * Get Phone's type
	 *
	 * @param
	 * @return
	 */
	public static String getPhoneType() {
		return android.os.Build.MODEL;
	}

	/**
	 * Get Phone's SDK
	 *
	 * @return
	 */
	public static String getSDK() {
		return android.os.Build.VERSION.SDK;
	}

	/**
	 * Get Phone's Release
	 *
	 * @return
	 */
	public static String getRelease() {
		return android.os.Build.VERSION.RELEASE;
	}


	public static boolean isGreateEqualVersinTwo() {
		String value = android.os.Build.VERSION.RELEASE;
		if (!value.startsWith("1"))
			return true;
		return false;
	}

	public static boolean hasImageCaptureBug() {

		if (DeviceInfo.isGreateEqualVersinTwo()) {
			return false;
		}
		return true;

	}


	/**
	 * Get Phone's OS version
	 *
	 * @return
	 */
	public static String getOSVersion() {
		String version = getRelease() + "," + getSDK();
		return version;
	}


	public static String getUserAgent(Context context) {
		String deviceID = NetWorkConfig.getDrviceID(MainApplication.getContext());
		String agent =  android.os.Build.MODEL + "/android/" + getOSVersion() + "/" + deviceID;
//        DebugUtils.println("---agent is " + agent);
		return agent;
	}

	private static final String AGENT = "HJApp/Android/" + android.os.Build.VERSION.RELEASE + "/hjclass/";
	public static String getHeadUserAgent() {
		if (APP_INFO != null) {
			return APP_INFO;
		}

		StringBuilder builder = new StringBuilder(AGENT);
		Context context = MainApplication.getContext();
		if (context != null) {
			builder.append(Utils.getVersionName(context)).append(".").append(Utils.getVersionCode(context)).append(" [").append(DeviceInfo.getUserAgent(context)).append("]");
		}
		APP_INFO = builder.toString();
		return APP_INFO;
	}
}
