package com.hujiang.hjclass.utils;

import android.text.TextUtils;

import java.math.BigDecimal;

/**
 * Created by lvhuacheng on 2015/10/26.
 * 数字相关操作工具类
 */
public class DigitalUtil {

    public static final int STR_TO_INT_ERROR_RESULT = -9999999;

    public static final long STR_TO_LONG_ERROR_RESULT = -9999999;

    public static final double STR_TO_DOUBLE_ERROR_RESULT = -9999999;

    public static final float STR_TO_FLOAT_ERROR_RESULT = -9999999;

    private static final String TAG = "DigitalUtil";

    /**
     * 四舍五入保留N位小数
     * @param x
     * @param n
     */
    public static double round(double x, int n) {
        try{
            BigDecimal b = new BigDecimal(x);
            double num = b.setScale(n, BigDecimal.ROUND_HALF_UP).doubleValue();
            return num;
        }catch(Exception e){
            LogUtil.error(TAG,e);
        }
        return 0;
    }

    /**
     * 四舍五入保留N位小数
     * @param x
     * @param n
     */
    public static float round(float x, int n) {
        try{
            BigDecimal b = new BigDecimal(x);
            float num = b.setScale(n, BigDecimal.ROUND_HALF_UP).floatValue();
            return num;
        }catch(Exception e){
            LogUtil.error(TAG,e);
        }
        return 0;
    }

    /**
     * 得到最靠近num并且是2的n次方的 数字
     * @param num
     * @return
     */
    public static int get2NthNearNumber(int num){
        if(num <= 0){
            return num;
        }
        if(isNthOf2(num)){
            return num;
        }
        //查找大于最靠近num并且是2的n次方的 数字
        int max = num;
        while(!isNthOf2(max)){
            max++;
        }
        //查找小于最靠近num并且是2的n次方的 数字
        int min = num;
        while(!isNthOf2(min)){
            min--;
        }
        int ret = (max-num)-(num-min);
        return ret > 0 ? min : max;
    }

    /**
     * 判断数字是否是2的n次方
     * @param num
     * @return
     */
    public static boolean isNthOf2(int num){
        if(num <= 0){
            return  false;
        }
        int ret = num & (num - 1);
        return ret == 0;
    }

    public static int parseStringToInt(String str){
        if(TextUtils.isEmpty(str)){
            return STR_TO_INT_ERROR_RESULT;
        }
        try{
            return Integer.parseInt(str);
        }catch (Exception e){

        }
        return STR_TO_INT_ERROR_RESULT;
    }

    public static long parseStringToLong(String str){
        if(TextUtils.isEmpty(str)){
            return STR_TO_LONG_ERROR_RESULT;
        }
        try{
            return Long.parseLong(str);
        }catch (Exception e){

        }
        return STR_TO_LONG_ERROR_RESULT;
    }

    public static double parseStringToDouble(String str){
        if(TextUtils.isEmpty(str)){
            return STR_TO_DOUBLE_ERROR_RESULT;
        }
        try{
            return Double.parseDouble(str);
        }catch (Exception e){

        }
        return STR_TO_DOUBLE_ERROR_RESULT;
    }

    public static float parseStringToFloat(String str){
        if(TextUtils.isEmpty(str)){
            return STR_TO_FLOAT_ERROR_RESULT;
        }
        try{
            return Float.parseFloat(str);
        }catch (Exception e){

        }
        return STR_TO_FLOAT_ERROR_RESULT;
    }
}
