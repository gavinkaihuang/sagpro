/**
 * 
 */
package com.hujiang.hjclass.utils;

import com.hujiang.hjclass.db.DiscountExtendDBHelper;

/**
 * @author lidongkai
 * 
 */
public class DiscountConstants {
	public final static int CARD_TYPE_CARD = DiscountExtendDBHelper.CARD_TYPE_CARD;// 学习卡0、优惠券1、课程码2
	public final static int CARD_TYPE_COUPON = DiscountExtendDBHelper.CARD_TYPE_COUPON;
	public final static int CARD_TYPE_CODE = DiscountExtendDBHelper.CARD_TYPE_CODE;
	public static final String DISCOUNT_ENTRY_CARD_CODE = "discount_entry_card_code";
	public static final String DISCOUNT_SHOW_CARD_TYPE = "discount_show_type";
	public static final String DISCOUNT_SHOW_CARD_CODE = "discount_show_card_code";
	public static final String DISCOUNT_SHOW_CARD_FEE = "discount_show_card_fee";
}
