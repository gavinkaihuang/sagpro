package com.hujiang.hjclass.utils;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hujiang.hjclass.AppConfig;
import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.adapter.model.CouponModel;
import com.hujiang.hjclass.db.ClassPorvider;
import com.hujiang.hjclass.db.DiscountExtendDBHelper;
import com.hujiang.hjclass.db.tables.TCouponColumns;
import com.hujiang.hjclass.db.tables.URIList;
import com.hujiang.hjclass.loader.DiscountLoader;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.util.CommonConstants;
import com.hujiang.util.DebugUtils;

public class DiscountDBUtil {

    private static DiscountDBUtil instance = null;

    private DiscountDBUtil() {

    }

    public static synchronized DiscountDBUtil getInstance()
    {
        if (instance == null) {
            instance = new DiscountDBUtil();
        }
        return instance;
    }
    public void migrationDiscountDB() {
        if (!LoginUtils.checkNet(MainApplication.getContext())) {
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                DiscountExtendDBHelper helper = DiscountExtendDBHelper.getInstance(MainApplication.getContext());
                SQLiteDatabase db = helper.getWritableDatabase();
                Cursor cursor = null;
                try {
                    cursor = db.rawQuery("select * from table_discount", null);
                    if (cursor == null || cursor.getCount() == 0) {
                        return;
                    }

                    while (cursor.moveToNext()) {
                        String code = cursor.getString(cursor.getColumnIndex(DiscountExtendDBHelper.COLUMN_CARD_CODE));
                        CouponModel coupon = verify(code);
                        if (coupon == null) {
                            continue;
                        }
                        saveCoupon(coupon.content.coupon_list.get(0), db);
                    }
                    sendBroadcast();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (cursor != null) {
                        cursor.close();
                    }
                    if (db != null) {
                        db.close();
                    }
                }

            }
        }).start();
    }

    /**
     * 发送广播，取消订单成功
     */
    private void sendBroadcast(){
        Intent intent = new Intent(CommonConstants.MIGRATION_DISCOUNT_BROADCAST);
        MainApplication.getContext().sendBroadcast(intent);
    }

    private CouponModel verify(String mCode) {
        if (mCode == null || mCode.trim().length() == 0) {
            return null;
        }
        try {
            String data = PostDataGenerater.generateCheckCoupon(AppConfig.HOST_URL_FOR_4, mCode);
            String result = ServerConnecter.requestByGet(data);
            Gson gson = new Gson();
            java.lang.reflect.Type type = new TypeToken<CouponModel>() {
            }.getType();
            CouponModel mCouponModel = gson.fromJson(result, type);
            if (mCouponModel.content == null || mCouponModel.content.coupon_list == null) {
                return null;
            }
            return mCouponModel;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void saveCoupon(CouponModel.Coupon coupon, SQLiteDatabase db) {
        ClassPorvider cp = new ClassPorvider();
        ContentValues cv = new ContentValues();
        cv.put(TCouponColumns.CODE, coupon.code);
        cv.put(TCouponColumns.ENCRYPT_CODE, coupon.encrypt_code);
        cv.put(TCouponColumns.TITLE, coupon.title);
        cv.put(TCouponColumns.DISCOUNT_TYPE, coupon.discount_type);
        cv.put(TCouponColumns.DISCOUNT_FEE, coupon.discount_fee);
        cv.put(TCouponColumns.DISCOUNT, coupon.discount);
        cv.put(TCouponColumns.ISBINDUSER, coupon.isbinduser);
        cv.put(TCouponColumns.BEGINDATE, coupon.begindate);
        cv.put(TCouponColumns.EXPIREDDATE, coupon.expireddate);
        cv.put(TCouponColumns.ISUSED, coupon.isused);
        cv.put(TCouponColumns.ISCLASSALL, coupon.isclassall);
        if (coupon.class_coverurl != null && coupon.class_coverurl.length() > 0) {
            cv.put(TCouponColumns.CLASS_COVERURL, coupon.class_coverurl);
        }
        cv.put(TCouponColumns.STATUS, coupon.status);
        cv.put(TCouponColumns.COUPON_TYPE, coupon.coupon_type);
        if (DiscountLoader.isExistData(coupon.code)) {
            int update = cp.update(URIList.TCOUPON, cv, TCouponColumns.CODE + "=?", new String[]{coupon.code});
            DebugUtils.d("update new discount : " + update);
        } else {
            cp.insert(URIList.TCOUPON, cv);
            DebugUtils.d("insert new discount done");
        }
        int delete = db.delete("table_discount", "card_code = ?", new String[]{coupon.code});
        DebugUtils.d("delete old discount row done : " + delete);
    }

    public void saveCoupon(CouponModel.Coupon coupon){
        ClassPorvider cp = new ClassPorvider();
        ContentValues cv = new ContentValues();
        cv.put(TCouponColumns.CODE, coupon.code);
        cv.put(TCouponColumns.ENCRYPT_CODE, coupon.encrypt_code);
        cv.put(TCouponColumns.TITLE, coupon.title);
        cv.put(TCouponColumns.DISCOUNT_TYPE, coupon.discount_type);
        cv.put(TCouponColumns.DISCOUNT_FEE, coupon.discount_fee);
        cv.put(TCouponColumns.DISCOUNT, coupon.discount);
        cv.put(TCouponColumns.ISBINDUSER, coupon.isbinduser);
        cv.put(TCouponColumns.BEGINDATE, coupon.begindate);
        cv.put(TCouponColumns.EXPIREDDATE, coupon.expireddate);
        cv.put(TCouponColumns.ISUSED, coupon.isused);
        cv.put(TCouponColumns.ISCLASSALL, coupon.isclassall);
        if (coupon.class_coverurl != null && coupon.class_coverurl.length() > 0) {
            cv.put(TCouponColumns.CLASS_COVERURL, coupon.class_coverurl);
        }
        cv.put(TCouponColumns.STATUS, coupon.status);
        cv.put(TCouponColumns.COUPON_TYPE, coupon.coupon_type);
        cp.insert(URIList.TCOUPON, cv);
        DebugUtils.d("insert discount4firstOrder  done");
    }
}
