package com.hujiang.hjclass.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map.Entry;

import com.hujiang.loginmodule.LoginUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.ContentValues;

import com.hujiang.hjclass.AppConfig;
import com.hujiang.hjclass.MainApplication;

public class DiscountWebAPI {
    final public static int WEB_API_HOST_URL = 0;
    final public static int WEB_API_GET_VERIFY_CODE = 1;
    final public static int WEB_API_CHECK_DISCOUNT_CODE = 2;
    final public static int WEB_API_GET_USER_CARDS_INFO = 3;
//    final static String HOST_URL = Constant.HOST_URL;//"http://yz.api.class.hujiang.com/mobile/";
//    final static String HOST_URL = "http://api2.class.hujiang.com/mobile/";
    final static String API_URL = AppConfig.HOST_URL;//HOST_URL + "3.0/";
    final static String CMD_VERIFYCODE = AppConfig.CMD_VERIFYCODE;

    public static String getWebApi(int index, String... params) {
        String rt = null;
        switch(index) {
        case WEB_API_HOST_URL: {
            rt = getHostUrl();
            break;
        }
        case WEB_API_GET_VERIFY_CODE: {
            rt = getVerifyCodeApi();
            break;
        }
        case WEB_API_CHECK_DISCOUNT_CODE: {
            rt = getCheckDiscountCodeApi(params[0], params[1]);
            break;
        }
        case WEB_API_GET_USER_CARDS_INFO: {
            rt = getUserCardsINfoApi();
            break;
        }
        }
        return rt;
    }
    
    private static String getUserCardsINfoApi() {
        ContentValues datas = new ContentValues();
        datas.put(DiscountKeyWords.USER_AGENT, DeviceInfo.getUserAgent(MainApplication.getContext()));
        datas.put(DiscountKeyWords.TIME_STAMP, formatDateLongToString(System.currentTimeMillis()));
        String token = LoginUtils.getUserToken(MainApplication.getContext());
        datas.put(DiscountKeyWords.TOKEN, token);

        return getJsonStr_action_data(DiscountKeyWords.GET_COUPON_BYUSER, datas);
    }

    private static String getHostUrl() {
        return API_URL;
    }

    /*
    {
        "action": "check_code",
        "data": {
            "token": "houleixx",
            "code": "T3088D0B7302229",
            "verify_code": "1234",
            "user_agent": "ios/4.3/abcdef",
            "time_stamp": "2013.10.13.10.10.12"
        }
    }
*/
    private static String getCheckDiscountCodeApi(String code, String verifyCode) {
        return getJsonStr_CheckDiscountCodeApi(code, verifyCode);
    }

    private static String getVerifyCodeApi() {
        return CMD_VERIFYCODE;
    }

    private static String formatDateLongToString(Long timeLong){
        DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
        String timeString ;
        timeString = dateFormat.format(new Date(timeLong));
        return timeString;
    }

    private static String getJsonStr_CheckDiscountCodeApi(String code, String verifyCode) {
        ContentValues datas = new ContentValues();
        String token = LoginUtils.getUserToken(MainApplication.getContext());
        datas.put(DiscountKeyWords.TOKEN, token);
        datas.put(DiscountKeyWords.CODE, code);
        datas.put(DiscountKeyWords.VERIFY_CODE, verifyCode);
        datas.put(DiscountKeyWords.USER_AGENT, DeviceInfo.getUserAgent(MainApplication.getContext()));
        datas.put(DiscountKeyWords.TIME_STAMP, formatDateLongToString(System.currentTimeMillis()));
        return getJsonStr_action_data(DiscountKeyWords.CHECK_CODE, datas);
    }
    
    /*
    {
        "action": "action_xxxx",
        "data": {
            "d1": "xx",
            "d2": "yy",
            ...
            ...
            "dn": "nn",
        }
    }
*/
    private static String getJsonStr_action_data(String actionContent, ContentValues datas) {
        if(datas == null) {
            return null;
        }
        JSONObject rt = new JSONObject();
        try {
            JSONObject data = new JSONObject(); 
            for(Entry<String, Object> entry : datas.valueSet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                data.put(key, value);
            }
            rt.put(DiscountKeyWords.DATA, data);
            rt.put(DiscountKeyWords.ACTION, actionContent);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return rt.toString();
    }

    public class DiscountKeyWords {
        public final static String ACTION = "action";
        public final static String DATA = "data";

        public final static String CHECK_CODE = "check_code";
        public final static String TOKEN = "token";
        public final static String CODE = "code";
        public final static String VERIFY_CODE = "verify_code";
        public final static String USER_AGENT = "user_agent";
        public final static String TIME_STAMP = "time_stamp";

        public final static String STATUS = "status";
        public final static String MESSAGE = "message";
        public final static String CONTENT = "content";
        public final static String CODE_TYPE = "code_type";
        public final static String CODE_IS_DISCOUNT = "code_is_discount";
        public final static String CODE_FEE = "code_fee";
        public final static String CODE_DISCUNT = "code_discunt";
        public final static String IS_CLASSALL = "is_classall";
        public final static String CODE_EXPIREDDATE = "code_expireddate";
        public final static String CODE_NAME = "code_name";
        public final static String CODE_PWD = "code_pwd";
        public final static String CLASS_COVERURL = "class_coverurl";
        public final static String IS_EXPIRED = "is_expired";
        public final static String IS_USED = "is_used";

        public final static String GET_COURSE_BYCODE = "get_course_bycode";
        public final static String GET_COUPON_BYUSER = "get_coupon_byuser";
        public final static String COUPON_LIST = "coupon_list";
        public final static String ISCLASSALL = "IsClassAll";
        public final static String CLASSID = "ClassID";
        public final static String COUPONTYPE = "CouponType";
        public final static String COUPONFEE = "CouponFee";
        public final static String DISCOUNT = "Discount";
        public final static String COUPONCODE = "CouponCode";
        public final static String EXPIREDDATE = "ExpiredDate";
        public final static String TITLE = "Title";

//        "IsClassAll": false,
//        "ClassID": "10022",
//        "CouponType": 2,
//        "CouponFee": 5,
//        "CouponCode": "abcd",
//        "ExpiredDate": "2014-12-31T00:00:00"
//        final static String CODE_FEE = "code_fee";
//        final static String CODE_FEE = "code_fee";
//        final static String CODE_FEE = "code_fee";
//        final static String CODE_FEE = "code_fee";
//        final static String CODE_FEE = "code_fee";
//        final static String CODE_FEE = "code_fee";
//        final static String CODE_FEE = "code_fee";
//        final static String CODE_FEE = "code_fee";
//        final static String CODE_FEE = "code_fee";
//        final static String CODE_FEE = "code_fee";
    }
    
    
}
