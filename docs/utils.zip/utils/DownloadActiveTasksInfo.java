/**
 * 
 */
package com.hujiang.hjclass.utils;

import com.hujiang.ocs.download.OCSDownloadStatus;

import java.util.HashMap;

/**
 * @author lidongkai
 *
 */
public class DownloadActiveTasksInfo {
    HashMap<String, String> mActiveTasks = new HashMap<String, String> ();
    HashMap<String, String> mDoneTasks = new HashMap<String, String> ();
    int mErrorCode = OCSDownloadStatus.STATUS_DECODE_ERROR;
    static DownloadActiveTasksInfo mInstance = null;

    public static DownloadActiveTasksInfo getInstance() {
        if(mInstance == null) {
            mInstance = new DownloadActiveTasksInfo();
        }
        return mInstance;
    }

    /**
     * 
     */
    private DownloadActiveTasksInfo() {
    }

    public void clear() {
        mActiveTasks.clear();
        mDoneTasks.clear();
        mErrorCode = OCSDownloadStatus.STATUS_DECODE_ERROR;
    }

    public int getActiveTasksCount() {
        return mActiveTasks.size();
    }

    public void putActiveTask(String uid) {
        this.mActiveTasks.put(uid, uid);
    }

    public int getDoneTasksCount() {
        return mDoneTasks.size();
    }

    public void putDoneTask(String uid) {
        this.mDoneTasks.put(uid, uid);
    }

    /**
     * @return the mErrorCode
     */
    public int getErrorCode() {
        return mErrorCode;
    }

    /**
     * @param errorCode the mErrorCode to set
     */
    public void setErrorCode(int errorCode) {
        this.mErrorCode = errorCode;
    }

}
