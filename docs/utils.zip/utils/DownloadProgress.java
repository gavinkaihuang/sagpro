package com.hujiang.hjclass.utils;

public class DownloadProgress {
	public static final int		DOWNLOADING	= 0;
	public static final int		PAUSED		= 1;
	public static final int		COMPLETE	= 2;
	public static final int		CANCELLED	= 3;
	public static final int		ERROR		= 4;
	public static final String	STATUSES[]	= { "Downloading", "Paused", "Complete", "Cancelled", "Error" };
	
	public int					status		= PAUSED;
	public float				progress	= 0;
	public String				fileName;
	public String				url;	
}
