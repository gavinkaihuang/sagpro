package com.hujiang.hjclass.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.hujiang.hjclass.AppConfig;
import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.adapter.model.DownloadUrlEntity;

import java.util.HashMap;

/**
 * Created by zhuyi on 2015/8/12.
 */
public class DownloadUrlUtil {

    public interface UrlDownloadListener{
        void urlDownloaded(String url);
    }

    private HashMap<String,String> downLoadUrlmap = new HashMap<String,String>();

    private static DownloadUrlUtil util = new DownloadUrlUtil();

    private DownloadUrlUtil() {}

    public static DownloadUrlUtil getInstance(){
        return util;
    }

    /**
     * 单个下载地址获取
     * @param lessonId
     * @param listener
     */
    public void getDownLoadUrlAsync(final String lessonId, final UrlDownloadListener listener){
        if(TextUtils.isEmpty(lessonId) || listener == null){
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    getDownloadUrlsFromNet(lessonId);
                    if(listener != null){
                        String url = getLocalDownLoadUrl(lessonId);
                        listener.urlDownloaded(url);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /**
     * 获取本地的单个课程下载地址
     * @param   lessonId    lessonId
     * @return  local downloadUrl
     */
    public String getLocalDownLoadUrl(String lessonId){
        return downLoadUrlmap.get(lessonId) == null?"" : downLoadUrlmap.get(lessonId);
    }

    /**
     * 批量或单个请求下载地址并保存到本地
     * @param lessonId  lessonId1|lessonId2|lessonId3 or lessonId
     */
    public void getDownloadUrlsFromNet(String lessonId) {
        try {
            SharedPreferences sp = MainApplication.getContext().getSharedPreferences(Constant.PRE_SETTING, Context.MODE_PRIVATE);
            int line = sp.getInt(Constant.PRE_DOWNLOAD_ROUTE, 0);
            String url = String.format(AppConfig.HOST_URL_FOR_4 + Constant.ACTION_GET_DOWNLOADURL, lessonId, line);
            String result = ServerConnecter.requestByGet(url);
            LogUtil.error("DownloadUrlUtil","url："+url);
            LogUtil.error("DownloadUrlUtil","result："+result);
            DownloadUrlEntity entity = new Gson().fromJson(result, DownloadUrlEntity.class);
            if(entity != null && entity.status == 0){
                for (int i = 0; i < entity.content.size(); i++) {
                    DownloadUrlEntity.DownloadUrlBean bean = entity.content.get(i);
                    downLoadUrlmap.put(bean.lesson_id,bean.lesson_mediaurl);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
