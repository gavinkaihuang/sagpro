package com.hujiang.hjclass.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;

import com.hujiang.hjclass.db.business.DownloadBusiness;
import com.hujiang.hjclass.model.ClassDownloadModel;
import com.hujiang.loginmodule.LoginUtils;

import java.io.File;

/**
 * DownloadUtils
 */
public class DownloadUtils {
	public static final String PRE_FOR_NOTIFICATION = "nitification_preference";
	public static final String PRE_NOTIFICATION_CLEARED = "notification_cleared";
	public static final String PRE_NOTIFICATION_ALLDONE = "notification_alldone";
	public static final String PRE_NOTIFICATION_TASKS_RUNING = "notification_tasks_runing";

	public final static String TARGET_FILE_NAME = "index.hjmp3";
	private static final String uidTemplate = "%s_%s";

	public static String generateUid(String classId, String lessonId) {
		return String.format(uidTemplate, classId, lessonId);
	}

	public static String parseClassID(String uid) {
		if (uid == null || uid.equals("") || uid.indexOf("_") <= 0)
			return "";

		String[] values = uid.split("_");
		return values[0];
	}

	public static String parseLessonID(String uid) {
		if (uid == null || uid.equals("") || uid.indexOf("_") <= 0)
			return "";

		String[] values = uid.split("_");
		return values[1];
	}

	/**
	 * 文件下载目录
	 * 
	 * @param classId
	 * @param lessonId
	 * @return
	 */
	public static String getDownloadPath(String classId, String lessonId) {
		return getSavePath(classId, lessonId);
	}

	/**
	 * 课件下载的目录
	 * @return
     */
	public static String getDownloadDir() {
		//默认下载目录
		String defaultDir = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separatorChar + "HJApp/hjclass/";
		LogUtil.error("DownloadUtils","defaultDir = "+defaultDir);
		//用户设置的存储卡地址
		String nowPath = MyPreference.getInstance().getSDCardPath();
		LogUtil.error("DownloadUtils","nowPath = "+nowPath);
		if (nowPath != null && nowPath.length() > 0) { //用户设置过存储卡地址
			if(!nowPath.endsWith("HJApp/hjclass/")){//设置的下载路径是存储根目录
				nowPath += File.separatorChar + "HJApp/hjclass/";
			}
			if(!SDCardUtils.checkSDCardAvailable(nowPath)){//设置的下载路径没有读写权限
				nowPath = defaultDir;
				MyPreference.getInstance().storeSDCardPath("");
				MyPreference.getInstance().storeSavePathName("");
				LogUtil.error("DownloadUtils","设置的下载路径没有读写权限");
			}
			return nowPath;
		}
		return defaultDir;
	}

	/**
	 * 返回下载路径
	 * 
	 * @param classId
	 * @param lessonId
	 */
	private static String getSavePath(String classId, String lessonId) {
		/**
		 * 步骤 
		 * 1.首先到所有的SD卡下搜索是否包含此文件夹，并且此文件夹是否存在文件
		 * 2.如果条件1成立则直接返回该路径 
		 * 3.如果条件1不成立则从配置中读取文件夹路径 
		 * 4.如果配置中不存在此数据则返回默认目录
		 */
		String defaultDir = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separatorChar + "HJApp/hjclass/";
		defaultDir = defaultDir + classId + File.separatorChar + lessonId; // 详细目录
		String oldDir = checkSDCardFile(classId, lessonId); // 检查所以SD卡下是否包含此文件
		if (oldDir != null && oldDir.length() > 0) { // 以前老的目录如果存在则返回
			return oldDir;
		}
		String tempPath = MyPreference.getInstance().getSDCardPath();
		if (tempPath == null || tempPath.length() == 0) {
			return defaultDir; // 没有配置过下载目录
		}
		if(!tempPath.endsWith("HJApp/hjclass/")){
			tempPath = tempPath + File.separatorChar + "HJApp/hjclass/";
		}
		tempPath = tempPath + classId + File.separatorChar + lessonId;
		return tempPath;
	}

	/**
	 * 检查所有SD卡中是否存在该文件夹，并返回路径
	 * 
	 * @return
	 */
	private static String checkSDCardFile(String classId, String lessonId) {
		// 如果是3.0以下的版本 则直接返回空
		if (Integer.valueOf(android.os.Build.VERSION.SDK_INT) < 11) {
			return "";
		}
		try {
			/** 4.4以及以上的算法 ***/
			if (Integer.valueOf(android.os.Build.VERSION.SDK_INT) > 18) {
				File[] files = SDCardUtils.getSDCardFiles();
				if (files != null) {
					String path = "";
					for (int i = 0; i < files.length; i++) {
						File tempFile = new File(files[i].getPath() + File.separatorChar + "HJApp/hjclass/" + classId + File.separatorChar + lessonId);
							if (tempFile.exists() && tempFile.listFiles() != null && tempFile.listFiles().length > 0) {
								path = tempFile.toString();
								return path;
						}
					}
				}
			}

			String[] paths = SDCardUtils.getSDCardPaths();
			for (int i = 0; i < paths.length; i++) {
				String path = paths[i] + File.separatorChar + "HJApp/hjclass/" + classId + File.separatorChar + lessonId;
				File defaultFile = new File(path);
				if (defaultFile.exists() && defaultFile.listFiles() != null && defaultFile.listFiles().length > 0) {
					return path;
				}
			}
		} catch (Exception e) {
		}
		return "";
	}

	public static boolean isDownloadedLesson(String classId, String lessonId) {
		boolean rt = false;
		ClassDownloadModel model = DownloadBusiness.getDownloadInfo(LoginUtils.getUserId(), classId, lessonId);
		try {
			if (model != null && model.filePath.length() > 0) {
				if (model.filePath != null) {
					File f = new File(model.filePath);
					File file = new File(f.getParentFile(), TARGET_FILE_NAME);
					if (file.exists()) {
						rt = true;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rt;
	}

	public static String getSDPath() {
		File sdDir = null;
		boolean sdCardExist = Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED); // 判断sd卡是否存在
		if (sdCardExist) {
			sdDir = Environment.getExternalStorageDirectory();// 获取跟目录
		}
		return sdDir.toString();

	}

	public static boolean getRuningFlag(Context context) {
		boolean rt = false;
		SharedPreferences preferences = context.getSharedPreferences(PRE_FOR_NOTIFICATION, Context.MODE_PRIVATE);
		if (preferences != null) {
			rt = preferences.getBoolean(PRE_NOTIFICATION_TASKS_RUNING, false);
		}
		return rt;
	}

	public static void setRuningFlag(Context context, boolean runing) {
		SharedPreferences preferences = context.getSharedPreferences(PRE_FOR_NOTIFICATION, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putBoolean(PRE_NOTIFICATION_TASKS_RUNING, runing);
		editor.commit();
	}

	public static boolean getAllDoneFlag(Context context) {
		boolean rt = false;
		SharedPreferences preferences = context.getSharedPreferences(PRE_FOR_NOTIFICATION, Context.MODE_PRIVATE);
		if (preferences != null) {
			rt = preferences.getBoolean(PRE_NOTIFICATION_ALLDONE, false);
		}
		return rt;
	}

	public static void setAllDoneFlag(Context context, boolean done) {
		SharedPreferences preferences = context.getSharedPreferences(PRE_FOR_NOTIFICATION, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putBoolean(PRE_NOTIFICATION_ALLDONE, done);
		editor.commit();
	}

	public static boolean getClearedFlag(Context context) {
		boolean rt = false;
		SharedPreferences preferences = context.getSharedPreferences(PRE_FOR_NOTIFICATION, Context.MODE_PRIVATE);
		if (preferences != null) {
			rt = preferences.getBoolean(PRE_NOTIFICATION_CLEARED, false);
		}
		return rt;
	}

	public static void setClearedFlag(Context context, boolean cleared) {
		SharedPreferences preferences = context.getSharedPreferences(PRE_FOR_NOTIFICATION, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putBoolean(PRE_NOTIFICATION_CLEARED, cleared);
		editor.commit();
	}

	// // public static final int STATUS_UNZIP_FAILED = 201;
	// // public static final int STATUS_DECODED_FAILED = 202;
	// public static final int STATUS_DOWNLOADING = 203;
	//
	// // 队列中
	// public static final int STATUS_PENDING = 190;
	//
	// // 正在下载
	// public static final int STATUS_RUNNING = 192;
	//
	// // 暂停下载
	// public static final int STATUS_PAUSED = 193;
	//
	// // 出错状态
	// public static final int STATUS_ERROR = 196;
	//
	// // 下载完成
	// public static final int STATUS_COMPLETED = 197;
	//
	// // 取消下载
	// public static final int STATUS_CANCELED = 198;
	//
	// // 已解压
	// public static final int STATUS_UNZIPED = 199;
	//
	// // 已解密
	// public static final int STATUS_DECODED = 200;
	//
	// // 非法状态
	// public static final int STATUS_INVALID = -1;
	//
	// public static final int UNDOWNLOAD = 0;
	// public static final int DOWNLOADING = 1;
	// public static final int DOWNLOADED = 2;
	// public static final int DOWNLOAD_UNZIPED = 3;
	// public static final int DOWNLOAD_DECODED = 4;
	// public static final int DOWNLOAD_PAUSE = 5;
	// public static final int DOWNLOAD_ERROR = 6;
}
