package com.hujiang.hjclass.utils;

import com.hujiang.hjclass.db.ClassPorvider;
import com.hujiang.hjclass.db.tables.URIList;

public class DownloadedChangeUserIdUtil {

	public static void clearLessonAndUnit(){
		ClassPorvider cp = new ClassPorvider();
		cp.delete(URIList.CLASS_UNIT_URI,null,null);
		cp.delete(URIList.LESSON_INFO_URI,null,null);
	}
}
