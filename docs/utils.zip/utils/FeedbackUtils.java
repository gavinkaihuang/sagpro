package com.hujiang.hjclass.utils;

import com.hujiang.feedback.Feedback;
import com.hujiang.loginmodule.LoginUtils;

/**
 * Created by zhunafeng on 02/12/2016.
 */

public class FeedbackUtils {

    public static void startFeedBack() {
        Feedback.showActivity(Feedback.ExtInfo.create().add("userName", LoginUtils.getUsername()).add("userId",LoginUtils.getUserId()));
    }
}
