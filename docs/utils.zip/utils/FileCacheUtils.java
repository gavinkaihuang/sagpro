package com.hujiang.hjclass.utils;

import android.content.Context;
import android.os.Environment;
import android.os.StatFs;
import android.text.TextUtils;

import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.widgets.SoundRecordView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;

/**
 * 文件缓存
 * Created by lvhuacheng on 2016/1/25.
 */
public class FileCacheUtils {

    private static boolean USE_SDCARD = true;

    private static final String TAG = "FileCacheUtils";

    public static final String ROOT_DIR = "HJApp/hjclass/";

    public static final String AUDIO_DIR = "audio/";

    public static final String PIC_DIR = "pic/";

    /**
     * 获取sd卡的根目录
     *
     * @return {@link java.lang.String}
     * 			返回值 null 或 "/sdcard/"
     */
    private  static String getExternalStoragePath() {
        //判断SdCard是否存在并且是可用的
        String state = Environment.getExternalStorageState();
        if(!Environment.MEDIA_MOUNTED.equals(state)){
            return null;
        }
        //得到sd卡根目录
        File file = Environment.getExternalStorageDirectory();
        if(file == null){
            return null;
        }
        if(file.canWrite() && file.canRead()){
            String path = file.getAbsolutePath();
            file = null;
            return path + File.separator;
        }
        return null;
    }

    /**
     * 获取软件安装目录下的files目录
     *
     * @return {@link java.lang.String}
     * 			返回值 null 或 "/data/data/包名/files/"
     */
    private static String getInnerStoragePath(){
        Context sContext = MainApplication.getContext();
        if(sContext == null){
            return null;
        }
        File file = sContext.getFilesDir();
        if(file == null){
            return null;
        }
        String path = file.getAbsolutePath();
        if(TextUtils.isEmpty(path)){
            return null;
        }
        path += File.separator;
        return path;
    }

    /**
     * 获取文件缓存根路径
     * @return
     *      返回值 null 或 "/sdcard/HJApp/hjclass/"
     */
    private static String getCacheRoot(){
        String storagePath = null;
        if(USE_SDCARD){
            storagePath = getExternalStoragePath();
        }else{
            storagePath = getInnerStoragePath();
        }
        if(TextUtils.isEmpty(storagePath)){
            return null;
        }
        return storagePath + ROOT_DIR;
    }

    /**
     * 获取sd卡可用空间
     *
     * @return 剩余字节数
     */
    public  static long getSdCardAvailableStore(){
        long availableSpare = 0;
        String sdCradPath = getExternalStoragePath();
        if(sdCradPath != null){
            StatFs statFs = new StatFs(sdCradPath);
            long blocSize = statFs.getBlockSize();
            long availaBlock = statFs.getAvailableBlocks();
            availableSpare = availaBlock * blocSize;
            statFs = null;
        }
        if(availableSpare < 0){
            availableSpare = 0;
        }
        return availableSpare;
    }

    /**
     * 获取内部存储可用空间
     *
     * @return 剩余字节数
     */
    public static long getInnerAvailableStore(){
        long availableSpare = 0;
        File root = Environment.getDataDirectory();
        if(root == null){
            return availableSpare;
        }

        StatFs sf = new  StatFs(root.getPath());
        long  blockSize = sf.getBlockSize();
        long  availCount = sf.getAvailableBlocks();
        availableSpare = availCount*blockSize;
        sf = null;

        if(availableSpare < 0){
            availableSpare = 0;
        }
        return availableSpare;
    }

    /**
     * 获取存储空间可用的大小
     *
     * @return 剩余字节数
     */
    public static long getAvailableStore(){
        if(USE_SDCARD){
            return getSdCardAvailableStore();
        }
        return getInnerAvailableStore();
    }

    /**
     * 创建文件夹
     * @param filePath
     * @return
     */
    public static boolean makeDir(String filePath){
        File file = new File(filePath);
        if(file.exists() && file.isDirectory()){
            return true;
        }
        return file.mkdirs();
    }

    /**
     * 判断文件是否存在
     * @param filePath
     * @return
     */
    public static boolean isFileExist(String filePath){
        if(TextUtils.isEmpty(filePath)){
            return false;
        }
        File file = new File(filePath);
        return file.exists();
    }

    /**
     * 删除文件
     *
     * @param filePath
     */
    public static void deleteFile(String filePath) {
        if(TextUtils.isEmpty(filePath)){
            return;
        }
        File f = new File(filePath);
        if (f.exists()) {
            f.delete();
        }
    }

    /**
     * 删除文件夹
     * @param filePath 文件夹路径
     * @return true-删除成功,false-删除失败
     */
    public static boolean deleteDir(String filePath){
        if(TextUtils.isEmpty(filePath)){
            return false;
        }
        File file = new File(filePath);
        if(!file.exists()){
            return false;
        }
        try{
            if(file.isFile()){
                file.delete();
                return true;
            }else if(file.isDirectory()){
                File files[] = file.listFiles();
                for (int i = 0; i < files.length; i++) {
                    deleteDir(files[i].getAbsolutePath());
                }
                file.delete();
                return true;
            }
        }catch(Exception e){
            LogUtil.error(TAG, e);
        }
        return false;
    }

    /**
     * 清空文件夹
     * @param filePath 文件夹路径
     * @return true-删除成功,false-删除失败
     */
    public static boolean clearDir(String filePath){
        if(TextUtils.isEmpty(filePath)){
            return false;
        }
        File file = new File(filePath);
        if(file == null){
            return false;
        }
        if(!file.exists()){
            return false;
        }
        if(!file.isDirectory()){
            return false;
        }
        try{
            File files[] = file.listFiles();
            if(files == null || files.length == 0){
                return true;
            }
            for (int i = 0; i < files.length; i++) {
                deleteDir(files[i].getAbsolutePath());
            }
            return true;
        }catch(Exception e){
            LogUtil.error(TAG, e);
        }
        return false;
    }


    public static String readRawFile(int fileId){
        ByteArrayOutputStream outputStream = null;
        InputStream inputStream = null;
        try {
            byte buf[] = new byte[1024];
            int len;
            outputStream = new ByteArrayOutputStream();
            inputStream = MainApplication.getContext().getResources().openRawResource(fileId);
            while ((len = inputStream.read(buf)) != -1) {
                outputStream.write(buf, 0, len);
            }
            String result = outputStream.toString();
            return result;
        } catch (Exception e) {
            LogUtil.error(TAG, e);
        } finally {
            if (outputStream != null){
                try{
                    outputStream.close();
                }catch (Exception e){

                }
            }
            if (inputStream != null){
                try{
                    inputStream.close();
                }catch (Exception e){

                }
            }
        }
        return null;
    }

    /**
     * 得到音频文件缓存地址
     * @return
     */
    public static String getAudioCachePath(){
        return getCachePath(AUDIO_DIR);
    }

    public static String getPicCachePath(){
        return getCachePath(PIC_DIR);
    }

    private static String getCachePath(String dir){
        String cacheRoot = getCacheRoot();
        if(TextUtils.isEmpty(cacheRoot)){
            return null;
        }
        String cachePath = cacheRoot + dir;
        File file = new File(cachePath);
        if(file.exists() && file.isDirectory()){
            return cachePath;
        }
        if(makeDir(cachePath)){
            return cachePath;
        }
        return null;
    }

    /**
     * 得到音频存放地址
     * @param url
     * @return
     */
    public static String getAudioDownLoadPath(String url){
        return FileCacheUtils.getAudioCachePath() + MD5Utils.md5(url);
    }

    /**
     * 根据url得到图片存放地址
     * @param url
     * @return 图片保存地址
     */
    public static String getPicsDownLoadPath(String url){
        return FileCacheUtils.getPicCachePath() + MD5Utils.md5(url);
    }

    /**
     * 删除作业讨论区相关的音频缓存文件
     * @param postsId   作业帖子ID
     * @param userId    用户ID
     */
    public static void deleteSoundCacheFile(String postsId, String userId) {
        try {
            String dirPath = SoundRecordView.PATH;
            File dir = new File(dirPath);
            if(!dir.exists() || !dir.isDirectory()){
                return;
            }
            File[] files = dir.listFiles();
            if(files == null || files.length == 0){
                return;
            }
            for (int i = 0; i < files.length; i++) {
                String absolutePath = files[i].getAbsolutePath();
                if(absolutePath.contains(postsId+"_"+userId)){
                    files[i].delete();
                    break;
                }
            }
            LogUtil.error("","delete cache sound");
        } catch (Exception e) {
            LogUtil.error("",e.toString());
        }
    }
}
