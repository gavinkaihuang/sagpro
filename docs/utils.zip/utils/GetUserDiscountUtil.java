package com.hujiang.hjclass.utils;

import android.os.AsyncTask;
import com.google.gson.Gson;
import com.hujiang.hjclass.AppConfig;
import com.hujiang.hjclass.adapter.model.CouponModel;
import com.hujiang.util.DebugUtils;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by zhuyi on 2015/4/30.
 */
public class GetUserDiscountUtil extends AsyncTask<Void, Void, CouponModel.Coupon> {

	@Override
	protected CouponModel.Coupon doInBackground(Void... params) {
		String url = AppConfig.HOST_URL_FOR_4 + "user/GetUserDiscount";
		DebugUtils.d(url);
		String result = ServerConnecter.requestByGet(url);
		DebugUtils.d("result:" + result);
		try {
			CouponModel cm = new Gson().fromJson(result, CouponModel.class);
			if (0 == cm.status && cm.content != null && cm.content.coupon_info != null) {
				return cm.content.coupon_info;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	protected void onPostExecute(CouponModel.Coupon coupon) {
		if (coupon != null) {
			DiscountDBUtil.getInstance().saveCoupon(coupon);
		}
	}
}
