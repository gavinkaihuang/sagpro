package com.hujiang.hjclass.utils;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;

import com.hujiang.bi.BIConstants;
import com.hujiang.bi.utils.BIUtils;
import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.R;
import com.hujiang.hjclass.activity.lesson.ClassGroupChatInfoActivity;
import com.hujiang.hjclass.activity.lesson.HistoryBulletinActivity;
import com.hujiang.hjclass.activity.ordercenter.CommonWebActivity;
import com.hujiang.im.ConversationActivity;
import com.hujiang.im.HJIMSDK;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.note.utils.NoteNetworkUtils;
import com.hujiang.preferences.ClassPerferenceChangKey;
import com.hujiang.preferences.ClassPerferenceSmall;
import com.hujiang.util.NetStatusUtils;

import io.rong.imkit.RongIM;
import io.rong.imlib.model.Message;

/**
 * Created by lvhuacheng on 2016/3/10.
 */
public class GroupChatUtil {

    private static final String TAG = "GroupChatUtil";

    /**
     * 刷新聊天界面公告
     */
    public static void refreshGroupChatBulletin(){
        try{
            HJIMSDK hjimsdk = HJIMSDK.getInstance();
            if(hjimsdk == null){
                return;
            }
            hjimsdk.requestClassAnnouncement();
        }catch (Exception e){
            LogUtil.error(TAG,e);
        }
    }

    /**
     * 启动融云聊天
     * @param context
     * @param classId
     */
    public static void startRongyun(Context context, int classId){
        if(context == null || classId == 0){
            return;
        }
        try{
            HJIMSDK instance = HJIMSDK.getInstance();
            if(instance == null){
                return;
            }
            instance.startGroupChatActivity(context, classId, context.getString(R.string.class_index_chat_group));
        }catch (Exception e){
            LogUtil.error(TAG,e);
        }
    }

    public static void setUpRongyun(){
        // 点击聊天界面左上角
        HJIMSDK hjimsdk = HJIMSDK.getInstance();
        if(hjimsdk != null){
            //点击融云聊天界面公告取消事件
            hjimsdk.setOnAnnouncementCloseListener(new HJIMSDK.OnAnnouncementCloseListener() {

                @Override
                public void onAnnouncementClose(Context context,String groupId) {
                    LogUtil.error(TAG,"onAnnouncementClose");
                    BIUtils.statisticsEvent(MainApplication.getContext(), BIConstants.ONCLICK_RONGCLOUD_NOTIFICATION_CLOSE, new String[]{"classid"}, new String[]{groupId});
                }
            });

            //点击融云聊天界面右上角"班级信息"按钮事件
            hjimsdk.setOnActionBarMenuClickListener(new HJIMSDK.OnActionBarMenuClickListener() {
                @Override
                public void onActionBarMenuClicked(Context context, String groupId) {
                    LogUtil.error(TAG,"onActionBarMenuClicked");
                    ClassGroupChatInfoActivity.startClassGroupChatInfoActivity((Activity) context, groupId);
                    BIUtils.statisticsEvent(MainApplication.getContext(), BIConstants.ONCLICK_RONGCLOUD_CLASSINFO, new String[]{"classid"}, new String[]{groupId});
                }
            });

            //点击融云聊天界面成员头像事件
            hjimsdk.setOnUserAvatarClickListener(new HJIMSDK.OnUserAvatarClickListener() {
                @Override
                public void onUserAvatarClicked(Context context,String url) {
                    LogUtil.error(TAG,"onUserAvatarClicked");
                    if (!NetStatusUtils.getNetConnected(MainApplication.getContext()) || !NoteNetworkUtils.isUrl(url)) {
                        HJToast.show(R.string.networkIsUnavailable);
                        return;
                    }
                    CommonWebActivity.startCommonWebActivity((Activity) context, url, MainApplication.getContext().getResources().getString(R.string.classmates_title));
                }
            });

            //融云聊天界面发送消息事件
            hjimsdk.setOnSendMessageListener(new HJIMSDK.OnSendMessageListener() {
                @Override
                public void onSendMessageStart(Message message, String classId) {
                    LogUtil.error(TAG,"onSendMessageStart");
                    String userId = LoginUtils.getUserId(MainApplication.getContext());
                    if (TimeUtil.isToday(ClassPerferenceSmall.getInstance(MainApplication.getContext()).getSharedString(ClassPerferenceChangKey.getNeedClassGroupChatUploadBIInfokey(classId, userId)))) {
                        return;
                    }
                    BIUtils.statisticsEvent(MainApplication.getContext(), BIConstants.ONCLICK_RONGCLOUD_SUBMIT, new String[]{"classId", "userId"}, new String[]{classId, userId});
                    ClassPerferenceSmall.getInstance(MainApplication.getContext()).saveSharedString(ClassPerferenceChangKey.getNeedClassGroupChatUploadBIInfokey(classId, userId), TimeUtil.getCurrentDate());
                }

                @Override
                public void onSendMessageCompleted(Message message, String classId, RongIM.SentMessageErrorCode sentMessageErrorCode) {
                    LogUtil.error(TAG,"onSendMessageCompleted");
                    //记录用户发言事件
                    GroupChatUtteranceUtils.getInstance(MainApplication.getContext()).recordUtterance(classId, LoginUtils.getUserId(MainApplication.getContext()));
                }
            });

            //点击融云聊天界面公告事件
            hjimsdk.setOnAnnouncementViewClickListener(new HJIMSDK.onAnnouncementViewClickListener(){
                @Override
                public void onAnnouncementViewClick(Context context, String groupId) {
                    LogUtil.error(TAG,"onAnnouncementViewClick");
                    HistoryBulletinActivity.startHistoryBulletinActivity((Activity) context, groupId);
                    BIUtils.statisticsEvent(MainApplication.getContext(), BIConstants.ONCLICK_RONGCLOUD_NOTIFICATION, new String[]{"classid"}, new String[]{groupId});
                }
            });

            //群聊有人退群回调
            hjimsdk.setOnInformationReceivedListener(new HJIMSDK.onInformationReceivedListener() {
                @Override
                public void onInformationReceived(String userID) {
                    LogUtil.error(TAG,"onInformationReceived");
                    if(TextUtils.isEmpty(userID)){
                        return;
                    }
                    //如果退群的用户是当前登录的用户关闭聊天界面
                    if (userID.equals(LoginUtils.getUserId(MainApplication.getContext()))) {
                        if(ConversationActivity.mInstance != null){
                            ConversationActivity.mInstance.finish();
                        }
                    }
                }
            });
        }
    }

}
