package com.hujiang.hjclass.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.text.TextUtils;

import com.hujiang.hjclass.AppConfig;
import com.hujiang.hjclass.MainApplication;
import com.hujiang.preferences.ClassPerferenceConstantKey;
import com.hujiang.preferences.ClassPerferenceSmall;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 融云用户发言时间日志统计及上传工具
 * Created by lvhuacheng on 2016/3/10.
 */
public class GroupChatUtteranceUtils {

    private static final String TAG = "GroupChatUtteranceUtils";

    private final static long PERIOD = 30 * 1000;

    private static final String GROUP_CHAT_UTTERANCE = "group_chat_utterance";

    private static final String LOCK_STR = new String("GroupChatUtteranceLock");

    private static GroupChatUtteranceUtils instance = null;

    private SharedPreferences preference = null;

    private Timer timer = null;

    public static synchronized GroupChatUtteranceUtils getInstance(Context context) {
        if (instance == null) {
            instance = new GroupChatUtteranceUtils(context);
        }
        return instance;
    }

    private GroupChatUtteranceUtils(Context context){
        if(context == null){
            return;
        }
        preference = context.getSharedPreferences(GROUP_CHAT_UTTERANCE, Context.MODE_PRIVATE);
    }

    private void clearSpeakData(){
        try{
            SharedPreferences.Editor editor = preference.edit();
            editor.clear();
            editor.commit();
            editor = null;
        }catch(Exception e){
            LogUtil.error(TAG, e);
        }
    }

    /**
     * 得到用户发言时间(精确到秒)
     * @return
     */
    private long getSpeakTime(){
       long serverTime = ClassPerferenceSmall.getInstance(MainApplication.getContext()).getSharedLong(ClassPerferenceConstantKey.SERVER_TIME);
        if(serverTime <= 0){
            return System.currentTimeMillis()/1000;
        }
        return serverTime + SystemClock.elapsedRealtime()/1000;
    }

    /**
     * 创建上传的单点Object
     * @param key
     * @param value
     * @return
     */
    private JSONObject createSpeakObject(String key,String value){
        if(TextUtils.isEmpty(key) || TextUtils.isEmpty(value)){
            return null;
        }
        int index = key.indexOf("-");
        if( index <= 0){
            return null;
        }
        try{
            String classId = key.substring(0,index);
            String userId  = key.substring(index+1);
            JSONObject object = new JSONObject();
            object.put("group_id",classId);
            object.put("user_id",userId);
            object.put("speak_time",value);
            return object;
        }catch(Exception e){
            LogUtil.error(TAG, e);
        }
        return null;
    }

    /**
     * 获取上传的发言数据
     * @return
     */
    private String getSpeakData(){
        try{
            if(preference == null){
                return null;
            }
            Map<String,?> dataMap = preference.getAll();
            if(dataMap == null || dataMap.size() == 0){
                return null;
            }
            JSONArray array = new JSONArray();
            String key = null;
            JSONObject object = null;
            Set<String> keySet = dataMap.keySet();
            Iterator<String> iterator = keySet.iterator();
            while(iterator.hasNext()){
                key = iterator.next();
                object = createSpeakObject(key,(String)dataMap.get(key));
                if(object != null){
                    array.put(object);
                }
            }
            if(JsonParserUtil.isNotEmpty(array)){
                JSONObject parentObject = new JSONObject();
                parentObject.put("record_infos",array);
                return parentObject.toString();
            }
        }catch(Exception e){
            LogUtil.error(TAG, e);
        }
        return null;
    }

    /**
     * 上传用户发言数据
     */
    private void upSpeakData(){
        LogUtil.error(TAG,"上传用户发言数据");
        String speakData = getSpeakData();
        if(TextUtils.isEmpty(speakData)){
            LogUtil.error(TAG,"暂无发言数据");
            return;
        }
        String url = AppConfig.HOST_URL_FOR_4 + Constant.ACTION_ADD_GROUP_SPEAK_TIME;
        LogUtil.error(TAG,"url ="+url);
        LogUtil.error(TAG,"speakData ="+speakData);
        //请求服务器
        String result = ServerConnecter.postContentBody(url,speakData);
        LogUtil.error(TAG,"result="+result);
        JSONObject object = JsonParserUtil.getJSONObject(result);
        if(object != null && JsonParserUtil.getJSONObjectValue_Int(object,"status") == 0){
            clearSpeakData();
        }
    }

    /**
     * 记录用户在某个群里发言时间
     * @param classId
     * @param userId
     */
    public void recordUtterance(String classId, String userId){
        LogUtil.error(TAG,"保存用户发言数据: classId="+classId+", userId="+userId);
        if(TextUtils.isEmpty(classId) || TextUtils.isEmpty(userId)){
            return;
        }
        String key = classId + "-" + userId;
        long speakTime = getSpeakTime();
        try{
            SharedPreferences.Editor editor = preference.edit();
            editor.putString(key,String.valueOf(speakTime));
            editor.commit();
            editor = null;
        }catch(Exception e){
            LogUtil.error(TAG, e);
        }
    }

    /**
     * 开启上传发言数据定时器
     */
    public void startTimer(){
        cancelTimer();
        timer = new Timer(true);
        timer.schedule(new TimerTask(){

            @Override
            public void run() {
                synchronized (LOCK_STR){
                    upSpeakData();
                }
            }
        },300, PERIOD);
    }

    /**
     * 销毁定时器
     */
    public void cancelTimer(){
        if(timer == null){
            return;
        }
        try{
            timer.cancel();
            timer = null;
        }catch(Exception e){
            LogUtil.error(TAG, e);
        }
    }
}
