package com.hujiang.hjclass.utils;

import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hujiang.hjclass.model.MessageCenterModel;

import java.lang.reflect.Type;

/**
 * Created by lvhuacheng on 2015/11/30.
 */
public class GsonUtil {

    private static final String TAG = "GsonUtil";

    public static <T> T jsonToObject(String json, Class<T> classOfT){
        if(TextUtils.isEmpty(json)){
            return null;
        }
        try{
            Gson gson = new Gson();
            return gson.fromJson(json,classOfT);
        }catch(Exception e){
            LogUtil.error(TAG,e);
        }
        return null;
    }

    public static <T> T jsonToObject(String json, Type typeOfT){
        if(TextUtils.isEmpty(json)){
            return null;
        }
        try{
            Gson gson = new Gson();
            return gson.fromJson(json,typeOfT);
        }catch(Exception e){
            LogUtil.error(TAG,e);
        }
        return null;
    }

    public static String objectToJson(Object obj){
        if(obj == null){
            return null;
        }
        try{
            Gson gson = new Gson();
            return gson.toJson(obj);
        }catch(Exception e){
            LogUtil.error(TAG,e);
        }
        return null;
    }
}
