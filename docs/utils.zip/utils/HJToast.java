package com.hujiang.hjclass.utils;

import android.content.Context;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.R;

public class HJToast extends Toast {

	public HJToast(Context context) {
		super(context);
	}

	public static Toast makeText(Context context, CharSequence text, int duration) {
		if (context == null)
			context = MainApplication.getContext();

		Toast result = new Toast(context);

		LayoutInflater inflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View v = inflate.inflate(com.hujiang.hjclass.R.layout.layout_customtoast, null);
		TextView tv = (TextView) v.findViewById(R.id.tv_custom_toast);
		tv.setText(text);

		result.setView(v);
		result.setDuration(duration);

		return result;
	}

	public static Toast makeText(CharSequence text, int duration) {
		Context context = MainApplication.getContext();
		Toast result = new Toast(context);

		LayoutInflater inflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View v = inflate.inflate(com.hujiang.hjclass.R.layout.layout_customtoast, null);
		TextView tv = (TextView) v.findViewById(R.id.tv_custom_toast);
		tv.setText(text);

		result.setView(v);
		result.setDuration(duration);

		return result;
	}

	public static void show(String str) {
		if (isInMainThread()) {
			makeText(str, HJToast.LENGTH_SHORT).show();
		} else {
			Looper.prepare();
			makeText(str, HJToast.LENGTH_SHORT).show();
			Looper.loop();
		}
	}

	public static boolean isInMainThread() {
		return Looper.myLooper() == Looper.getMainLooper();
	}

	public static void show(int strid) {
		if (isInMainThread()) {
			makeText(MainApplication.getContext().getResources().getString(strid), HJToast.LENGTH_SHORT).show();
		} else {
			Looper.prepare();
			makeText(MainApplication.getContext().getResources().getString(strid), HJToast.LENGTH_SHORT).show();
			Looper.loop();
		}
	}

	public static void show(String str,int duration) {
		if (isInMainThread()) {
			makeText(str, duration).show();
		} else {
			Looper.prepare();
			makeText(str, duration).show();
			Looper.loop();
		}
	}

	public static Toast makeText(Context context, int id, int duration) {
		Toast result = new Toast(context);

		LayoutInflater inflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View v = inflate.inflate(com.hujiang.hjclass.R.layout.layout_customtoast, null);
		TextView tv = (TextView) v.findViewById(R.id.tv_custom_toast);
		tv.setText(id);

		result.setView(v);
		result.setDuration(duration);

		return result;
	}

	/**
	 * 4.2.0 Toast(榜单未公布／保存成功／提交成功／删除成功)
	 * @param context
	 * @param id
	 * @param text
	 * @param duration
     * @return
     */
	public static Toast makeText(Context context, int id, String text, int duration) {
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View layout = inflater.inflate(R.layout.layout_common_toast, null);
		ImageView image = (ImageView) layout.findViewById(R.id.iv_toast_img);
		image.setImageResource(id);
		TextView tv_text = (TextView) layout.findViewById(R.id.tv_toast_content);
		tv_text.setText(text);
		Toast toast = new Toast(context);
		toast.setGravity(Gravity.CENTER, 0, 0);
		toast.setDuration(duration);
		toast.setView(layout);
		toast.show();

		return toast;
	}
}
