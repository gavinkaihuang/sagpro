package com.hujiang.hjclass.utils;

import android.app.Activity;
import android.text.TextUtils;

import com.hujiang.browser.HJWebBrowserSDK;
import com.hujiang.browser.WebBrowserOptions;

/**
 * Created by lvhuacheng on 2016/9/29.
 */
public class HJWebBrowserUtil {

    public static void start(Activity act,String url){
        start(act,url,"");
    }

    public static void start(Activity act, String url, String title){
        start(act,url,title,true,false,false);
    }

    public static void start(Activity act, String url, String title, boolean isShowActionBar,boolean isPassBack, boolean isShareMenu){
        if(act == null || TextUtils.isEmpty(url)){
            return;
        }
        WebBrowserOptions webBrowserOptions = (new WebBrowserOptions.WebBrowserOptionsBuilder())
                .setWebBrowserTitle(title)
                .setIsPassBack(isPassBack)
                .setIsShareDefaultMenu(isShareMenu)
                .setIsShowActionBar(isShowActionBar)
                .build();
        HJWebBrowserSDK.getInstance().start(act,url,webBrowserOptions);
    }
}
