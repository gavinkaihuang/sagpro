package com.hujiang.hjclass.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.TextUtils;
import android.util.Log;

/**
 * 手机Home键监听
 * Created by lvhuacheng on 2015/9/16.
 */
public class HomeKeyWatcher {

    private static final String TAG = "HomeWatcher";

    private Context mContext;
    private IntentFilter mFilter;
    private OnHomePressedListener mListener;
    private InnerRecevier mRecevier;

    // 回调接口
    public interface OnHomePressedListener {
        public void onHomePressed();
        public void onHomeLongPressed();
    }

    public HomeKeyWatcher(Context context){
        mContext = context;
        mFilter = new IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
        mRecevier = new InnerRecevier();
    }

    /**
     * 设置监听
     *
     * @param listener
     */
    public void setOnHomePressedListener(OnHomePressedListener listener) {
        mListener = listener;
    }

    /**
     * 开始监听，注册广播
     */
    public void startWatch(){
        if (mRecevier != null) {
            mContext.registerReceiver(mRecevier, mFilter);
        }
    }

    /**
     * 停止监听，注销广播
     */
    public void stopWatch(){
        if (mRecevier != null){
            mContext.unregisterReceiver(mRecevier);
        }
    }

    /**
     * 广播接收者
     */
    class InnerRecevier extends BroadcastReceiver {

        public static final String SYSTEM_DIALOG_REASON_KEY = "reason";
        public static final String SYSTEM_DIALOG_REASON_GLOBAL_ACTIONS = "globalactions";
        public static final String SYSTEM_DIALOG_REASON_RECENT_APPS = "recentapps";
        public static final String SYSTEM_DIALOG_REASON_HOME_KEY = "homekey";

        @Override
        public void onReceive(Context context, Intent intent){
            String action = intent.getAction();
            if(!Intent.ACTION_CLOSE_SYSTEM_DIALOGS.equals(action)){
                return;
            }
            String reason = intent.getStringExtra(SYSTEM_DIALOG_REASON_KEY);
            if(TextUtils.isEmpty(reason)){
                return;
            }
            if (mListener == null){
                return;
            }
            if (reason.equals(SYSTEM_DIALOG_REASON_HOME_KEY)){
                // 短按home键
                mListener.onHomePressed();
            } else if (reason.equals(SYSTEM_DIALOG_REASON_RECENT_APPS)){
                // 长按home键
                mListener.onHomeLongPressed();
            }
        }
    }
}
