package com.hujiang.hjclass.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/**
 * Created by lvhuacheng on 2016/6/14.
 */
public class IntentUtil {

    public static boolean callWebBrowser(Context context,String url){
        try{
            Uri uri = Uri.parse(url);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            context.startActivity(intent);
            return true;
        }catch(Exception e){
            LogUtil.error("IntentUtil", e);
        }catch (Error e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void openAppByScheme(Context context,String url){
        try {
            Uri uri = Uri.parse(url);
            Intent viewIntent = new Intent(Intent.ACTION_VIEW, uri);
            context.startActivity(viewIntent);
        } catch (Exception e) {
            LogUtil.error("IntentUtil", e);
        }
    }

}
