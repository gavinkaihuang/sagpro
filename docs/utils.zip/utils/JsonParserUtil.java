package com.hujiang.hjclass.utils;

import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lvhuacheng on 2015/11/16.
 */
public class JsonParserUtil {
    private static final String TAG = "JsonParserUtil";

    public static final int DEFAULT_ERROR_INT = -9999999;

    public static final int DEFAULT_ERROR_LONG = -9999999;

    public static final double DEFAULT_ERROR_DOUBLE = -9999999d;

    public static final float DEFAULT_ERROR_FLOAT= -9999999f;

    /**
     * 根据key从parent节点中得到JSONObject
     * @param parent 父节点
     * @param key	关键字
     * @return {@link org.json.JSONObject} key不存在 或 key对应值为空 或 发生异常,返回null
     *
     */
    public static JSONObject getJSONObject(JSONObject parent,String key){
        JSONObject object = null;
        try{
            if(parent.has(key) && !parent.isNull(key)){
                object = parent.getJSONObject(key);
            }
        }catch(Exception e){
            LogUtil.error(TAG, e);
            object = null;
        }
        return object;
    }

    /**
     * 得到JSONArray中index位置的JSONObject对象
     * @param array
     * @param index
     * @return
     */
    public static JSONObject getJSONObject(JSONArray array,int index){
        JSONObject object = null;
        try{
            object = array.getJSONObject(index);
        }catch(Exception e){
            LogUtil.error(TAG, e);
            object = null;
        }
        return object;
    }

    /**
     * 根据字符串创建JSONObject
     * @param jsonString
     * @return {@link org.json.JSONObject}
     */
    public static JSONObject getJSONObject(String jsonString){
        if(TextUtils.isEmpty(jsonString)){
            return null;
        }
        try {
            return new JSONObject(jsonString);
        } catch (JSONException e) {
            LogUtil.error(TAG, e);
        }
        return null;
    }

    /**
     * 根据字符串创建JSONArray
     * @param jsonString
     * @return {@link org.json.JSONArray}
     */
    public static JSONArray getJSONArray(String jsonString){
        if(TextUtils.isEmpty(jsonString)){
            return null;
        }
        try {
            return new JSONArray(jsonString);
        } catch (JSONException e) {
            LogUtil.error(TAG, e);
        }
        return null;
    }


    /**
     * 根据key从parent节点中得到JSONArray,默认返回null
     * @param parent 父节点
     * @param key	关键字
     * @return {@link org.json.JSONArray}  key不存在 或 key对应值为空 或 发生异常,返回null
     */
    public static JSONArray getJSONArray(JSONObject parent,String key){
        JSONArray value = null;
        try{
            if(parent.has(key) && !parent.isNull(key)){
                value = parent.getJSONArray(key);
            }
        }catch(Exception e){
            value = null;
        }
        return value;
    }

    /**
     * 得到parent节点下关键字key对应节点的String值
     * @param parent 父节点
     * @param key	关键字
     * @return {@link java.lang.String}  key不存在 或 key对应值为空 或 发生异常,返回""
     */
    public static String getJSONObjectValue(JSONObject parent,String key){
        String value = "";
        try{
            if(parent.has(key) && !parent.isNull(key)){
                value = parent.getString(key);
                if(value == null){
                    value = "";
                }
            }
        }catch(Exception e){
            value = "";
        }
        return value;
    }

    /**
     * 得到parent节点下关键字key对应节点的int值
     * @param parent 父节点
     * @param key	关键字
     * @return key不存在 或 key对应值为空 或 发生异常,返回 { DEFAULT_ERROR_INT }
     */
    public static int getJSONObjectValue_Int(JSONObject parent,String key){
        int value = DEFAULT_ERROR_INT;
        try{
            if(parent.has(key) && !parent.isNull(key)){
                value = parent.getInt(key);
            }
        }catch(Exception e){
            value = DEFAULT_ERROR_INT;
        }
        return value;
    }

    /**
     * 得到parent节点下关键字key对应节点的Long值
     * @param parent 父节点
     * @param key	关键字
     * @return key不存在 或 key对应值为空 或 发生异常,返回 { DEFAULT_ERROR_LONG }
     */
    public static long getJSONObjectValue_Long(JSONObject parent,String key){
        long value = DEFAULT_ERROR_LONG;
        try{
            if(parent.has(key) && !parent.isNull(key)){
                value = parent.getLong(key);
            }
        }catch(Exception e){
            value = DEFAULT_ERROR_LONG;
        }
        return value;
    }

    /**
     * 得到parent节点下关键字key对应节点的double值
     * @param parent 父节点
     * @param key	关键字
     * @return key不存在 或 key对应值为空 或 发生异常,返回 { DEFAULT_ERROR_DOUBLE }
     */
    public static double getJSONObjectValue_Double(JSONObject parent,String key){
        double value = DEFAULT_ERROR_DOUBLE;
        try{
            if(parent.has(key) && !parent.isNull(key)){
                value = parent.getDouble(key);
            }
        }catch(Exception e){
            value = DEFAULT_ERROR_DOUBLE;
        }
        return value;
    }

    /**
     * 得到parent节点下关键字key对应节点的boolean值
     * @param parent 父节点
     * @param key	关键字
     * @return
     */
    public static boolean getJSONObjectValue_Boolean(JSONObject parent,String key){
        boolean value = false;
        try{
            if(parent.has(key) && !parent.isNull(key)){
                value = parent.getBoolean(key);
            }
        }catch(Exception e){
            value = false;
        }
        return value;
    }

    /**
     * 判断JSONArray是否为空
     * @param array
     * @return true-不为空,false-为空
     */
    public static boolean isNotEmpty(JSONArray  array){
        return array != null && array.length() > 0;
    }

    /**
     * 判断JSONArray的index项是否是JSONArray对象
     * @param array
     * @param index
     * @return
     */
    public static boolean isJSONArray(JSONArray array,int index){
        try{
            array.getJSONArray(index);
            return true;
        }catch(JSONException e){
        }
        return false;
    }

    /**
     * 得到有序的key集合
     * @param jsonObject
     * @return
     */
    public static JSONArray getJSONObjectNames(JSONObject jsonObject){
        if(jsonObject == null){
            return null;
        }
        JSONArray names = jsonObject.names();
        if(names == null || names.length() <= 0){
            return  null;
        }

        JSONArray array = new JSONArray();
        try{
            int temp;
            int a, b;
            int length = names.length();
            for(int i=0;i<length;i++){
                array.put(names.get(i));
            }
            for (int i = 0; i < length; i++) {
                for (int j = length - 1; j > i; j--) {
                    a = array.getInt(j);
                    b = array.getInt(j - 1);
                    if (a < b) {
                        temp = a;
                        array.put(j, b);
                        array.put(j - 1, temp);
                    }
                }
            }
        }catch(Exception e){
            LogUtil.error(TAG, e);
            array = null;
        }
        if(array == null || array.length() <= 0){
            return names;
        }
        return array;
    }

    /**
     * 解析字符串类型Array
     * @param jsonArray
     * @return
     */
    public static List<String> getListResult(JSONArray jsonArray){
        if(!JsonParserUtil.isNotEmpty(jsonArray)){
            return null;
        }
        List<String> list = null;
        try{
            String result = "";
            for(int i=0;i<jsonArray.length();i++){
                result = jsonArray.getString(i);
                if(!TextUtils.isEmpty(result)){
                    if(list == null){
                        list = new ArrayList<String>();
                    }
                    list.add(result );
                }
                result = "";
            }
        }catch(Exception e){
            LogUtil.error(TAG, e);
            list = null;
        }
        return list;
    }
}
