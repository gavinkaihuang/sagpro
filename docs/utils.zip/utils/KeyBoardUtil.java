package com.hujiang.hjclass.utils;

import android.app.Activity;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;

public class KeyBoardUtil {

	private View mChildOfContent;
	
	private int usableHeightPrevious;
	
	private FrameLayout.LayoutParams frameLayoutParams;

	private boolean resize;

	private KeyBoardChangeListener listener;
	
	public interface KeyBoardChangeListener{
		
		void KeyBoardChange(boolean visible);
		
	}
	
	/**
	 * 监听键盘显示隐藏事件
	 * @param activity
	 * @param listener
	 * @param resize
	 */
	public static void assistActivity(Activity activity, KeyBoardChangeListener listener, boolean resize) {
		if (activity == null) {
			return;
		}
		new KeyBoardUtil(activity, listener, resize);
	}

	public static void assistRootView(View rootView) {
		new KeyBoardUtil(rootView);
	}

	private KeyBoardUtil(View rootView) {
		try {
			FrameLayout content = (FrameLayout) rootView.getParent();
			mChildOfContent = content.getChildAt(0);
			mChildOfContent.getViewTreeObserver()
					.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
						public void onGlobalLayout() {
							try {
								possiblyResizeChildOfContent();
							} catch (Exception e) {
								LogUtil.error("KeyBoardUtil", e);
							}
						}
					});
			frameLayoutParams = (FrameLayout.LayoutParams) mChildOfContent.getLayoutParams();
		} catch (Exception e) {
			LogUtil.error("KeyBoardUtil", e);
		}
	}

	public KeyBoardUtil(Activity activity, KeyBoardChangeListener listener, boolean resize) {
		this.resize = resize;
		this.listener = listener;
		try {
			FrameLayout content = (FrameLayout) activity.findViewById(android.R.id.content);
			if (content == null) {
				return;
			}
			mChildOfContent = content.getChildAt(0);
			if (mChildOfContent == null) {
				return;
			}
			frameLayoutParams = (FrameLayout.LayoutParams) mChildOfContent.getLayoutParams();
			mChildOfContent.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
						public void onGlobalLayout() {
							possiblyResizeChildOfContent();
						}
					});
		} catch (Exception e) {
			LogUtil.error("KeyBoardUtil", e);
		}
	}

	private void possiblyResizeChildOfContent() {
		try {
			int usableHeightNow = computeUsableHeight();
			if (usableHeightNow == usableHeightPrevious) {
				return;
			}
			int usableHeightSansKeyboard = mChildOfContent.getRootView().getHeight();
			int heightDifference = usableHeightSansKeyboard - usableHeightNow;
			int height = 0;
			if (heightDifference > (usableHeightSansKeyboard / 4)) {
				// keyboard probably just became visible
				LogUtil.error("KeepAccountActivity", "keyboard visible");
				height = usableHeightSansKeyboard - heightDifference;
				if(listener != null){
					listener.KeyBoardChange(true);
				}
			} else {
				// keyboard probably just became hidden
				LogUtil.error("KeepAccountActivity", "keyboard hidden");
				height = usableHeightSansKeyboard;
				if(listener != null){
					listener.KeyBoardChange(false);
				}
			}
			if (resize) {
				frameLayoutParams.height = height;
				mChildOfContent.requestLayout();
			}
			usableHeightPrevious = usableHeightNow;
		} catch (Exception e) {
			LogUtil.error("KeyBoardUtil", e);
		}
	}

	private int computeUsableHeight() throws Exception {
		Rect r = new Rect();
		mChildOfContent.getWindowVisibleDisplayFrame(r);
		return (r.bottom - r.top);
	}
}
