package com.hujiang.hjclass.utils;

import android.text.TextUtils;

import com.hujiang.hjclass.Constant.StatusConstant;
import com.hujiang.hjclass.adapter.model.FinishedTaskClassMatesEntity;
import com.hujiang.hjclass.db.business.LearningSystemBusiness;
import com.hujiang.hjclass.model.LearningSystemBaseNodeBean;
import com.hujiang.hjclass.model.LearningSystemClassTaskCompleteModel;
import com.hujiang.hjclass.model.LearningSystemIntensivePackageBean;
import com.hujiang.hjclass.model.LearningSystemItemBean;
import com.hujiang.hjclass.model.LearningSystemLessonBean;
import com.hujiang.hjclass.model.LearningSystemSectionBean;
import com.hujiang.hjclass.model.LearningSystemTaskBean;
import com.hujiang.hjclass.model.LearningSystemUnitBean;
import com.hujiang.hjclass.sync.DataSyncManager;
import com.hujiang.loginmodule.LoginUtils;

import java.util.HashMap;
import java.util.List;

/**
 * Created by lvhuacheng on 2017/1/4.
 */

public class LearningSystemDataManager {

    private static String getLearningSystemStudySolutionLinkKey(String userId, String classId){
        return userId + "_" + classId;
    }

    private static String getLearningSystemBreTestLinkKey(String userId, String classId){
        return userId + "_" + classId;
    }

    private static String getLearningSystemBreTestStatusKey(String userId, String classId){
        return userId + "_" + classId;
    }

    private static String getLearningSystemLessonUnitExpandStatusKey(String userId, String classId, String unitId){
        return userId + "_" + classId + "_" + unitId;
    }

    public static String getLearningSystemBreTestStatus(String userId, String classId){
        String status = StatusConstant.LEARNING_SYSTEM_BRETEST_UNFINISHED;
        if(TextUtils.isEmpty(classId) || TextUtils.isEmpty(userId)){
            return status;
        }
        Object object = ACacheHelper.getObject(ACacheKeyUtil.getLearningSystemBreTestStatusCacheKey());
        if(object == null || !(object instanceof HashMap)){
            return status;
        }
        HashMap<String,String> map = (HashMap)object;
        status = map.get(getLearningSystemBreTestStatusKey(userId, classId));
        if(TextUtils.isEmpty(status)){
            status = StatusConstant.LEARNING_SYSTEM_BRETEST_UNFINISHED;
        }
        return status;
    }

    public static void updateLearningSystemBreTestStatus(String userId, String classId, String status){
        if(TextUtils.isEmpty(classId) || TextUtils.isEmpty(userId) || TextUtils.isEmpty(status)){
            return;
        }
        HashMap<String,String> map = null;
        Object object = ACacheHelper.getObject(ACacheKeyUtil.getLearningSystemBreTestStatusCacheKey());
        if(object != null && object instanceof HashMap){
            map = (HashMap)object;
        }
        if(map == null){
            map = new HashMap<String,String>();
        }
        map.put(getLearningSystemBreTestStatusKey(userId, classId), status);
        ACacheHelper.saveObject(ACacheKeyUtil.getLearningSystemBreTestStatusCacheKey(),map);
    }

    public static String getLearningSystemBreTestLink(String userId, String classId){
        if(TextUtils.isEmpty(classId) || TextUtils.isEmpty(userId)){
            return null;
        }
        Object object = ACacheHelper.getObject(ACacheKeyUtil.getLearningSystemBreTestLinkCacheKey());
        if(object == null || !(object instanceof HashMap)){
            return null;
        }
        HashMap<String,String> map = (HashMap)object;
        return map.get(getLearningSystemBreTestLinkKey(userId, classId));
    }

    public static void updateLearningSystemBreTestLink(String userId, String classId, String link){
        if(TextUtils.isEmpty(classId) || TextUtils.isEmpty(userId) || TextUtils.isEmpty(link)){
            return;
        }
        HashMap<String,String> map = null;
        Object object = ACacheHelper.getObject(ACacheKeyUtil.getLearningSystemBreTestLinkCacheKey());
        if(object != null && object instanceof HashMap){
            map = (HashMap)object;
        }
        if(map == null){
            map = new HashMap<String,String>();
        }
        map.put(getLearningSystemBreTestLinkKey(userId, classId), link);
        ACacheHelper.saveObject(ACacheKeyUtil.getLearningSystemBreTestLinkCacheKey(),map);
    }

    public static void updateLearningSystemStudySolutionLink(String userId, String classId, String link){
        if(TextUtils.isEmpty(classId) || TextUtils.isEmpty(userId) || TextUtils.isEmpty(link)){
            return;
        }
        HashMap<String,String> map = null;
        Object object = ACacheHelper.getObject(ACacheKeyUtil.getLearningSystemStudySolutionLinkCacheKey());
        if(object != null && object instanceof HashMap){
            map = (HashMap)object;
        }
        if(map == null){
            map = new HashMap<String,String>();
        }
        map.put(getLearningSystemStudySolutionLinkKey(userId, classId), link);
        ACacheHelper.saveObject(ACacheKeyUtil.getLearningSystemStudySolutionLinkCacheKey(),map);
    }

    public static String getLearningSystemStudySolutionLink(String userId, String classId){
        if(TextUtils.isEmpty(classId) || TextUtils.isEmpty(userId)){
            return null;
        }
        Object object = ACacheHelper.getObject(ACacheKeyUtil.getLearningSystemStudySolutionLinkCacheKey());
        if(object == null || !(object instanceof HashMap)){
            return null;
        }
        HashMap<String,String> map = (HashMap)object;
        return map.get(getLearningSystemStudySolutionLinkKey(userId, classId));
    }

    public static boolean isLearningSystemLessonUnitExpand(String userId, String classId, String unitId){
        if(TextUtils.isEmpty(classId) || TextUtils.isEmpty(userId) || TextUtils.isEmpty(unitId)){
            return false;
        }
        //没有保存状态的返回展开状态
        HashMap<String,Boolean> map = null;
        Object object = ACacheHelper.getObject(ACacheKeyUtil.getLearningSystemLessonUnitExpandStatusCacheKey());
        if(object == null || !(object instanceof HashMap)){
            return true;
        }
        map = (HashMap)object;
        Boolean boolValues =  map.get(getLearningSystemLessonUnitExpandStatusKey(userId, classId, unitId));
        if(boolValues == null){
            return true;
        }
        return boolValues;
    }

    public static void updateLearningSystemLessonUnitExpandStatus(String userId, String classId, String unitId, boolean expand){
        if(TextUtils.isEmpty(classId) || TextUtils.isEmpty(userId) || TextUtils.isEmpty(unitId)){
            return;
        }
        HashMap<String,Boolean> map = null;
        Object object = ACacheHelper.getObject(ACacheKeyUtil.getLearningSystemLessonUnitExpandStatusCacheKey());
        if(object != null && object instanceof HashMap){
            map = (HashMap)object;
        }
        if(map == null){
            map = new HashMap<String,Boolean>();
        }
        map.put(getLearningSystemLessonUnitExpandStatusKey(userId, classId, unitId), expand);
        ACacheHelper.saveObject(ACacheKeyUtil.getLearningSystemLessonUnitExpandStatusCacheKey(),map);
    }

    public static LearningSystemTaskBean getClassTaskFromCache(String userId, String classId){
        return getClassTaskFromCache(userId, classId, true);
    }

    /**
     * 从缓存中获取任务
     * @param userId
     * @param classId
     * @param needResetIntensivePackageNewFlag  是否需要重置强化包的new标记
     * @return
     */
    public static LearningSystemTaskBean getClassTaskFromCache(String userId, String classId, boolean needResetIntensivePackageNewFlag){
        LearningSystemTaskBean taskBean = LearningSystemBusiness.getLearningSystemClassTask(userId, classId);
        if (taskBean == null || taskBean.getTasks() == null) {
            return taskBean;
        }
        //设置任务中的强化包为打开状态
        //计算课表当前需要定位的强化包位置
        int gotoPosition = -1;
        LearningSystemBaseNodeBean nodeBean;
        for (int i = 0; i < taskBean.getTasks().size(); i++) {
            nodeBean = taskBean.getTasks().get(i);
            if (nodeBean instanceof LearningSystemIntensivePackageBean) {//强化包
                LearningSystemIntensivePackageBean packageBean = (LearningSystemIntensivePackageBean) nodeBean;
                packageBean.setOpen(true);
                if (packageBean.isNew() && gotoPosition == -1) {
                    gotoPosition = i;
                    taskBean.setGotoPosition(gotoPosition);
                }
            }
        }
        //重置强化包isNew标志
        if(needResetIntensivePackageNewFlag){
            LearningSystemBusiness.updateLearningSystemIntensivePackageNewFlag(userId, classId);
        }
        return taskBean;
    }

    public static LearningSystemLessonBean getLearningSystemLessonFromCache(String userId, String classId){
        List<LearningSystemUnitBean> unitBeanList = LearningSystemBusiness.getLearningSystemLesson(userId, classId);
        if(unitBeanList == null || unitBeanList.size() == 0){
            return null;
        }
        //设置课节或强化包是否属于当前班级任务标志
        //设置强化包是否需要展开标志
        //计算课表当前需要定位的强化包位置
        int groupPosition = -1;
        int childPosition = -1;
        String curTaskContainSectionIds = LearningSystemBusiness.getCurrentTaskContainSectionIds(userId,classId);
        if(!TextUtils.isEmpty(curTaskContainSectionIds)){
            for(int i=0; i<unitBeanList.size();i++){
                for(int j=0; j<unitBeanList.get(i).getChildList().size();j++){
                    LearningSystemBaseNodeBean nodeBean = unitBeanList.get(i).getChildList().get(j);
                    if(nodeBean instanceof LearningSystemSectionBean){//课节
                        LearningSystemSectionBean sectionBean = (LearningSystemSectionBean)nodeBean;
                        sectionBean.setCurrentTask(curTaskContainSectionIds.contains(sectionBean.getSectionId()));
                    }else if(nodeBean instanceof LearningSystemIntensivePackageBean){//强化包
                        LearningSystemIntensivePackageBean packageBean = (LearningSystemIntensivePackageBean)nodeBean;
                        packageBean.setCurrentTask(curTaskContainSectionIds.contains(packageBean.getSectionId()));
                        packageBean.setOpen(packageBean.isNew() || curTaskContainSectionIds.contains(packageBean.getSectionId()));
                        if(packageBean.isNew()){
                            groupPosition = i;
                            childPosition = j;
                        }
                    }
                    if(groupPosition != -1){
                        break;
                    }
                }
                if(groupPosition != -1){
                    //跳转到的强化包所在单元设置为展开
                    unitBeanList.get(i).setExpand(true);
                    break;
                }
            }
        }
        //重置强化包isNew标志
        LearningSystemBusiness.updateLearningSystemIntensivePackageNewFlag(userId,classId);
        LearningSystemLessonBean bean = new LearningSystemLessonBean();
        bean.groupPosition = groupPosition;
        bean.childPosition = childPosition;
        bean.unitBeanList = unitBeanList;
        return bean;
    }

    public static void updateLearningSystemIntensivePackageNewFlag(String userId, String classId, List<String> intensivePackageIds){
        LearningSystemBusiness.updateLearningSystemIntensivePackageNewFlag(userId, classId, intensivePackageIds);
    }

    public static FinishedTaskClassMatesEntity getLearningSystemCompleteTaskStudentCache(String userId, String classId){
        String data = LearningSystemBusiness.getLearningSystemCompleteTaskStudent(userId, classId);
        if(TextUtils.isEmpty(data)){
            return null;
        }
        FinishedTaskClassMatesEntity classMatesEntity = GsonUtil.jsonToObject(data, FinishedTaskClassMatesEntity.class);
        if(classMatesEntity == null || classMatesEntity.content == null){
            return null;
        }
        return classMatesEntity;
    }

    public static LearningSystemClassTaskCompleteModel getLearningSystemCompleteTaskInfoCache(String userId, String classId){
        String data = LearningSystemBusiness.getLearningSystemCompleteTaskInfo(userId, classId);
        if(TextUtils.isEmpty(data)){
            return null;
        }
        LearningSystemClassTaskCompleteModel taskCompleteModel = GsonUtil.jsonToObject(data, LearningSystemClassTaskCompleteModel.class);
        if(taskCompleteModel == null || taskCompleteModel.getData() == null){
            return null;
        }
        return taskCompleteModel;
    }

    /**
     * 更新课节条目状态为已完成
     * @param itemBean
     */
    public static void updateLessonSectionItemStatusToComplete(LearningSystemItemBean itemBean){
        if(itemBean == null){
            return;
        }
        if(itemBean.isTaskFinished()){
            return;
        }
        String userId = LoginUtils.getUserId();
        String classId = itemBean.getClassId();
        String contentId = itemBean.getContentId();
        String packageType = itemBean.getPackageType();
        String sectionItemId = itemBean.getTaskItemId();
        String taskId = itemBean.getTaskId();
        String taskKey = itemBean.getTaskKey();
        String taskType = itemBean.getTaskType();
        if(TextUtils.isEmpty(userId) || TextUtils.isEmpty(classId) || TextUtils.isEmpty(contentId) || TextUtils.isEmpty(packageType) || TextUtils.isEmpty(sectionItemId) || TextUtils.isEmpty(taskType)){
            return;
        }
        LearningSystemBusiness.updateLessonSectionItemCompleteStatus(userId, classId, sectionItemId, true);
        String postData = PostDataGenerater.generateSyncClassTaskData(classId, contentId, packageType, taskId, taskKey, taskType);
        DataSyncManager.getInstance().syncData(userId,RequestUrlUtil.createLearningSystemSyncTaskURL(),postData);
    }
}
