package com.hujiang.hjclass.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;

import com.hujiang.hjclass.MainApplication;

/**
 * Created by lvhuacheng on 2016/8/22.
 */
public class LocalBroadcastCenter {

    private LocalBroadcastManager mLocalBroadcast;

    private static LocalBroadcastCenter singleBroadcast = new LocalBroadcastCenter();


    private void init(Context context){
        if(context == null){
            return;
        }
        if(mLocalBroadcast != null){
            return;
        }
        mLocalBroadcast = LocalBroadcastManager.getInstance(context);
    }

    public static LocalBroadcastCenter getInstance() {
        singleBroadcast.init(MainApplication.getContext());
        return singleBroadcast;
    }

    public void broadCast(Intent intent) {
        if (null == mLocalBroadcast) {
            return;
        }
        mLocalBroadcast.sendBroadcast(intent);
    }

    public void registerReceiver(BroadcastReceiver br, IntentFilter iFilter) {
        if(null == br || null == iFilter || null == mLocalBroadcast) {
            return;
        }
        mLocalBroadcast.registerReceiver(br, iFilter);
    }

    public void unregisterReceiver(BroadcastReceiver br) {
        if(null == br || null == mLocalBroadcast) {
            return;
        }
        mLocalBroadcast.unregisterReceiver(br);
    }
}
