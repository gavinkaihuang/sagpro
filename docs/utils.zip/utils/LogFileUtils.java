package com.hujiang.hjclass.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import android.os.Environment;

import com.hujiang.util.DateUtil;

public class LogFileUtils {
	
	public static boolean isDebug = false;
	
	private static final String puncher_logfile = Environment.getExternalStorageDirectory()
            .getAbsolutePath() + "/puncher.log";
	

//	static LogFileUtils logFileUtils = null;
//	private LogFileUtils() {
//		
//	}
//	
//	public static LogFileUtils getInstance() {
//		logFileUtils = new LogFileUtils();
//		FileOutputStream out = new FileOutputStream("the-file-name");
//		 out.w
//		return null;
//		
//	}
	
	public static void writeToFile(String text) {
		if (isDebug == false)
			return;
		
		try {
			DateUtil dateUtil = new DateUtil();
			String dateValue = dateUtil.getNowDateTimeStringEn2();
			
			BufferedWriter bw = new BufferedWriter(new FileWriter(new File(puncher_logfile), true));
			bw.write(dateValue + "|" + text);
			bw.newLine();
			bw.close();
		} catch (Exception e) {
		}
	}

	
	

}
