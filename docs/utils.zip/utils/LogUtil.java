package com.hujiang.hjclass.utils;

import android.util.Log;

import com.hujiang.hjclass.BuildConfig;


/**
 * Created by lvhuacheng on 2015/9/28.
 */
public class LogUtil {

    public static void error(String tag, Exception e){
        if(!BuildConfig.PRINT_LOG){
            return;
        }
        Log.e(tag, "", e);
    }

    public static void error(String tag, String msg){
        if(!BuildConfig.PRINT_LOG){
            return;
        }
        Log.e(tag , msg);
    }

    public static void warn(String tag, String msg){
        if(!BuildConfig.PRINT_LOG){
            return;
        }
        Log.w(tag, msg);
    }

    public static void info(String tag, String msg){
        if(!BuildConfig.PRINT_LOG){
            return;
        }
        Log.i(tag , msg);
    }
}
