package com.hujiang.hjclass.utils;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.media.ThumbnailUtils;
import android.text.TextUtils;

import com.hujiang.hjclass.Constant.CommonConstant;
import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.R;
import com.hujiang.hjclass.model.MainBottomTabResEntity;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by zhuyi on 16/10/27.
 * 首页底部TAB图片更换工具类
 */
public class MainTabChangeUtil {

    private static final String TAG = "MainTabChangeUtil";

    /**
     * 数据没问题的话,更换底部tab图片
     */
    public static void changeBottomTabResIfNeed(Resources res, OnTabChangeResLoadListener listener) {
        try {
            Object obj = ACacheHelper.getObject(CommonConstant.KEY_MAIN_BOTTOM_TAB_RES);
            if(!(obj instanceof MainBottomTabResEntity.MainBottomTabResModel)){
                LogUtil.error(TAG,"tab 未更换 : 缓存数据有问题 obj: "+obj);
                return;
            }
            long nowTime = System.currentTimeMillis();
            long beginTime = TimeUtil.convertDateStringToLong(((MainBottomTabResEntity.MainBottomTabResModel) obj).getBegin_time());
            long endTime = TimeUtil.convertDateStringToLong(((MainBottomTabResEntity.MainBottomTabResModel) obj).getEnd_time());
            if(nowTime < beginTime){
                LogUtil.error(TAG,"tab 未更换 : 还未到更换时间 : "+new Date(beginTime)+", 当前时间是:"+new Date(nowTime));
                return;
            }
            if(nowTime > endTime){
                LogUtil.error(TAG,"tab 更换为默认图片 : 已过有效期 : "+new Date(endTime)+", 当前时间是:"+new Date(nowTime));
                if(listener != null){
                    listener.onTimeExpired();
                }
                return;
            }
            List<MainBottomTabResEntity.MainBottomTabResBean> beans = ((MainBottomTabResEntity.MainBottomTabResModel) obj).getResult();
            HashMap<String, String> map = new HashMap<>();
            for (int i = 0; i < beans.size(); i++) {
                MainBottomTabResEntity.MainBottomTabResBean bean = beans.get(i);
                if(bean == null){
                    continue;
                }
                map.put(bean.getBanner_id(), bean.getBanner_img());
            }
            if(!isPicDataValid(map)){
                LogUtil.error(TAG,"tab 不更换, 图片不合法");
                return;
            }
            LogUtil.error(TAG,"tab 需更换, 在有效期内");
            changeBottomTab(res ,map, listener);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void changeBottomTab(Resources res, HashMap<String,String> urlMap, OnTabChangeResLoadListener listener) {
        if(res == null || urlMap == null){
            LogUtil.error(TAG,"tab res = null or urlMap = null");
            return;
        }
        HashMap<String, Drawable> map = new HashMap<>();
        Set<Map.Entry<String, String>> entries = urlMap.entrySet();
        for (Map.Entry<String, String> entry : entries) {
            String url = entry.getValue();
            String key = entry.getKey();
            String picsDownLoadPath = FileCacheUtils.getPicsDownLoadPath(url);
            LogUtil.error(TAG,"tab bean.getBanner_img(): "+url+", picsDownLoadPath"+picsDownLoadPath);
            Bitmap bitmap = BitmapFactory.decodeFile(picsDownLoadPath);
            if(bitmap == null){
                LogUtil.error(TAG,"tab bitmap图片加载失败: url = "+url+", picsDownLoadPath = "+picsDownLoadPath);
                FileCacheUtils.deleteFile(picsDownLoadPath);
                continue;
            }
            Bitmap target = get2ShowBitmap(bitmap, res, key);
            LogUtil.error(TAG,"tab target width : "+target.getWidth()+", bitmap height : "+target.getHeight());
            Drawable drawable = new BitmapDrawable(res, target);
            LogUtil.error(TAG,"tab drawable getIntrinsicWidth : "+drawable.getIntrinsicWidth()+", drawable getIntrinsicHeight : "+drawable.getIntrinsicHeight());
            if(drawable == null){
                LogUtil.error(TAG,"tab drawable 图片加载失败: url = "+url+", picsDownLoadPath = "+picsDownLoadPath);
                FileCacheUtils.deleteFile(picsDownLoadPath);
                continue;
            }
            map.put(key,drawable);
        }
        if(map.size() != urlMap.size()){
            LogUtil.error(TAG,"tab 有图片加载失败,不更换。 加载成功数: "+map.size()+", 需要更换的数 : "+urlMap.size());
            return;
        }
        LogUtil.error(TAG,"tab 图片加载成功: 加载成功数: "+map.size()+", 需要更换的数 : "+urlMap.size());
        Drawable banner = map.get("0");
        Drawable firstTabNormal = map.get("1");
        Drawable firstTabPressed = map.get("2");
        Drawable secondTabNormal = map.get("3");
        Drawable secondTabPressed = map.get("4");
        Drawable thirdTabNormal = map.get("5");
        Drawable thirdTabPressed = map.get("6");
        StateListDrawable firstDrawable = null;
        StateListDrawable secondDrawable = null;
        StateListDrawable thirdDrawable = null;
        if(firstTabNormal != null && firstTabPressed != null){
            firstDrawable = new StateListDrawable();
            firstDrawable.addState(new int[]{android.R.attr.state_selected}, firstTabPressed);
            firstDrawable.addState(new int[]{}, firstTabNormal);
        }
        if(secondTabNormal != null && secondTabPressed != null){
            secondDrawable = new StateListDrawable();
            secondDrawable.addState(new int[]{android.R.attr.state_selected}, secondTabPressed);
            secondDrawable.addState(new int[]{}, secondTabNormal);
        }
        if(thirdTabNormal != null && thirdTabPressed != null){
            thirdDrawable = new StateListDrawable();
            thirdDrawable.addState(new int[]{android.R.attr.state_selected}, thirdTabPressed);
            thirdDrawable.addState(new int[]{}, thirdTabNormal);
        }
        if(listener != null){
            listener.needChangeTab(banner, firstDrawable, secondDrawable, thirdDrawable);
        }
    }

    /**
     * 修裁源图片,得到要显示的图片
     * @param bitmap 源图片
     * @param res    res
     * @param key    "0"为banner背景图的key,其余为三个tab的背景图的key
     * @return  要显示的图片
     */
    private static Bitmap get2ShowBitmap(Bitmap bitmap, Resources res, String key){
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        LogUtil.error(TAG,"tab bitmap width : "+ width +", bitmap height : "+ height);
        int screenWidth = res.getDisplayMetrics().widthPixels;
        int screenHeight = res.getDisplayMetrics().heightPixels;
        Bitmap target;
        int targetWidth = (int) (screenWidth/3.6);
        int targetHeight = res.getDimensionPixelSize(R.dimen.padding_48_normal);
        if("0".equals(key) && (width > screenWidth || height > targetHeight)){
            //key为0的图片是banner背景图
            LogUtil.error(TAG,"tab 背景 bitmap 大小不符合标准: w--"+screenWidth+",h--"+targetHeight+", 压缩");
            target = ThumbnailUtils.extractThumbnail(bitmap, screenWidth, targetHeight);
        }else if(width > (screenWidth/3.6) || height > targetHeight){
            LogUtil.error(TAG,"tab bitmap 大小不符合标准: w--"+targetWidth+",h--"+targetHeight+", 压缩");
            target = ThumbnailUtils.extractThumbnail(bitmap, targetWidth, targetHeight);
        }else{
            target = bitmap;
        }
        return target;
    }

    /**
     * "1",代表左起第一张图片的普通状态
     * "2",代表左起第一张图片的选中状态
     * "3",代表左起第二张图片的普通状态
     * "4",代表左起第二张图片的选中状态
     * "5",代表左起第三张图片的普通状态
     * "6",代表左起第三张图片的选中状态
     * TAB图片没有成对出现则说明图片数据非法
     * @param map   key为0-7,value为对应的图片存放地址
     * @return  除了banner图,其他三个tab的图片成对出现,则返回true;反之返回false
     */
    private static boolean isPicDataValid(HashMap<String, String> map) {
        String picPath1 = map.get("1");
        String picPath2 = map.get("2");
        String picPath3 = map.get("3");
        String picPath4 = map.get("4");
        String picPath5 = map.get("5");
        String picPath6 = map.get("6");
        return !(TextUtils.isEmpty(picPath1) ^ TextUtils.isEmpty(picPath2)) && !(TextUtils.isEmpty(picPath3) ^ TextUtils.isEmpty(picPath4)) && !(TextUtils.isEmpty(picPath5) ^ TextUtils.isEmpty(picPath6));
    }

    public interface OnTabChangeResLoadListener{
        void onTimeExpired();
        void needChangeTab(Drawable banner, StateListDrawable firstDrawable, StateListDrawable secondDrawable, StateListDrawable thirdDrawable);
    }
}
