package com.hujiang.hjclass.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.model.ClassCategoryModel;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.util.DebugUtils;

import java.util.ArrayList;
import java.util.LinkedList;

public class MyPreference {

	private static MyPreference prefer = null;
	private String packName = "com.hujiang.hjclass";
	private Context app;
	private SharedPreferences settings;

	private MyPreference(Context ctx) {
		app = ctx;
		packName = ctx.getPackageName();
		settings = app.getSharedPreferences(packName, Context.MODE_PRIVATE);
	}

	public static MyPreference getInstance() {
		if (prefer == null) {
			prefer = new MyPreference(MainApplication.getContext());
		}
		return prefer;
	}

	/**
	 * save experience banner url
	 * 
	 * @param info
	 */
	public void storeExperienceBanner(String url) {
		if (url != null && url.length() > 0) {
			SharedPreferences.Editor editor = settings.edit();
			editor.putString("ExperienceBannerUrl", url);
			editor.commit();
		}
	}

	/**
	 * get experience banner url
	 * 
	 * @param info
	 */
	public String getExperienceBanner() {
		return settings.getString("ExperienceBannerUrl", "");
	}

	/**
	 * splash Save the picture information
	 * 
	 * @param info
	 */
	public void storeSplashData(String data) {
		if (data != null && data.length() > 0) {
			SharedPreferences.Editor editor = settings.edit();
			editor.putString("SplashData", data);
			editor.commit();
		}
	}

	/**
	 * get Save the picture information
	 * 
	 * @param info
	 */
	public String getSplashData() {
		return settings.getString("SplashData", "");
	}

	/**
	 * sava player config
	 * 
	 * @param config
	 */
	public void storePlayerConfig(int config) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putInt("PlayerConfig", config);
		editor.commit();
	}

	/**
	 * save sd card path
	 * 
	 * @param path
	 */
	public void storeSDCardPath(String path) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putString("SDCardPath", path);
		editor.commit();
	}

	/**
	 * get sd card path
	 * 
	 * @return
	 */
	public String getSDCardPath() {
		return settings.getString("SDCardPath", "");
	}

	/**
	 * save path name
	 * 
	 * @param path
	 */
	public void storeSavePathName(String path) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putString("SavePath", path);
		editor.commit();
	}

	/**
	 * get sd card path
	 * 
	 * @return
	 */
	public String getSavePathName() {
		return settings.getString("SavePath", "");
	}

	/*
	 * Return to use what kind of player
	 */
	public int getPlayerConfig() {
		return settings.getInt("PlayerConfig", 0);
	}

	/**
	 * 保存是否隐藏消息中心指导
	 * 
	 * @param ishow
	 */
	public void storeMessageGuideHide(boolean hide) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putBoolean("messageGuide", hide);
		editor.commit();
	}

	/**
	 * get sd card path
	 * 
	 * @return
	 */
	public boolean getMessageGuideHide() {
		return settings.getBoolean("messageGuide", false);
	}

	/**
	 * get pay notification phone
	 * 
	 * @return
	 */
	public String getPayNotificationPhone() {
		return settings.getString("PayNotificationPhone", "");
	}

	/**
	 * save pay notification phone
	 * 
	 * @param hide
	 */
	public void storePayNotificationPhone(String tel) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putString("PayNotificationPhone", tel);
		editor.commit();
	}

	/**
	 * 保存是否隐藏intro指导
	 * 
	 * @param ishow
	 */
	public void storeConsultGuideHide(boolean hide) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putBoolean("consultGuide", hide);
		editor.commit();
	}

	/**
	 * get consult guide
	 * 
	 * @return
	 */
	public boolean getConsultGuideHide() {
		return settings.getBoolean("consultGuide", false);
	}

	/**
	 * save selectSDCardDialog isShow state
	 */
	public void storeIsShowSelectSDardDialog(boolean ishow) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putBoolean("selectDCardDialog", ishow);
		editor.commit();
	}

	/**
	 * get selectSDCardDialog isShow state
	 */
	public boolean getIsShowSelectSDardDialog() {
		return settings.getBoolean("selectDCardDialog", true);
	}

	public void storeClassCategoryList(ArrayList<ClassCategoryModel> data) {
		if (data != null && data.size() > 0) {
			SharedPreferences.Editor editor = settings.edit();
			editor.putString("ClassCategoryList", new Gson().toJson(data));
			editor.commit();
		}
	}

	public ArrayList<ClassCategoryModel> getClassCategoryList() {
		String listStr = settings.getString("ClassCategoryList", null);
		if (listStr == null) {
			return null;
		}

		return new Gson().fromJson(listStr, new TypeToken<ArrayList<ClassCategoryModel>>() {
		}.getType());
	}

	public void storeExperienceClassCategoryList(ArrayList<ClassCategoryModel> data) {
		if (data != null && data.size() > 0) {
			SharedPreferences.Editor editor = settings.edit();
			editor.putString("ExperienceClassCategoryList", new Gson().toJson(data));
			editor.commit();
		}
	}

	public ArrayList<ClassCategoryModel> getExperienceClassCategoryList() {
		String listStr = settings.getString("ExperienceClassCategoryList", null);
		if (listStr == null) {
			return null;
		}

		return new Gson().fromJson(listStr, new TypeToken<ArrayList<ClassCategoryModel>>() {
		}.getType());
	}

	/**
	 * 保存首页数据
	 * 
	 * @param result
	 */
	public void storeHJIndexData(String result) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putString("HJIndexData", result);
		editor.commit();
	}

	/**
	 * 返回首页数据
	 * 
	 * @param result
	 */
	public String getHJIndexData() {
		return settings.getString("HJIndexData", "");
	}

	/**
	 * 保存搜索记录
	 * 
	 * @param keyword
	 *            要储存的关键词
	 * @param whichPage
	 *            体验中心or选课中心
	 */
	public void storeSearchHistory(String keyword, String whichPage, Context ctx) {
		String key = "";
		if (LoginUtils.isLogin(ctx)) {
			key = "SearchHistory_" + whichPage + "_" + LoginUtils.getUserId(ctx);
		} else {
			key = "SearchHistory_" + whichPage;
		}
		String value = settings.getString(key, "");
		LinkedList<String> list = Utils.string2LinkedList(value);
		if (list == null) {
			return;
		}
		if (list.size() == 10) {
			list.removeLast();
		}
		list.addFirst(keyword);
		String str = Utils.linkedlist2String(list);
		SharedPreferences.Editor editor = settings.edit();
		editor.putString(key, str);
		DebugUtils.d("storeSearchHistory key:" + key);
		editor.commit();
	}

	/**
	 * 清空搜索记录
	 * 
	 * @param whichPage
	 *            体验中心or选课中心
	 */
	public void clearSearchHistory(String whichPage, Context ctx) {
		String key = "";
		if (LoginUtils.isLogin(ctx)) {
			key = "SearchHistory_" + whichPage + "_" + LoginUtils.getUserId(ctx);
		} else {
			key = "SearchHistory_" + whichPage;
		}
		DebugUtils.d("clearSearchHistory key:" + key);
		SharedPreferences.Editor editor = settings.edit();
		editor.putString(key, "");
		editor.commit();
	}

	/**
	 * 获取搜索记录
	 * 
	 * @param whichPage
	 *            体验中心or选课中心
	 */
	public LinkedList<String> getSearchHistory(String whichPage, Context ctx) {
		String key = "";
		if (LoginUtils.isLogin(ctx)) {
			key = "SearchHistory_" + whichPage + "_" + LoginUtils.getUserId(ctx);
		} else {
			key = "SearchHistory_" + whichPage;
		}
		DebugUtils.d("getSearchHistory key:" + key);
		String value = settings.getString(key, "");
		return Utils.string2LinkedList(value);
	}

	/**
	 * 保存上课提醒数据
	 * 
	 * @param result
	 */
	public void storeAttendClassRemindData(String result) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putString("AttendClassRemind", result);
		editor.commit();
	}

	/**
	 * 获取上课提醒数据
	 * 
	 * @return
	 */
	public String getAttendClassRemindData() {
		return settings.getString("AttendClassRemind", "");
	}

	/***
	 * 存储首页打卡信息
	 * 
	 * @param data
	 *            jsonData
	 * @param userId
	 *            userId
	 */
	public void storeMainPunchData(String data, String userId) {
		if (data != null && data.length() > 0) {
			SharedPreferences.Editor editor = settings.edit();
			editor.putString("MainPunchData" + userId, data);
			editor.commit();
		}
	}

	/***
	 *
	 * 获取首页打卡信息
	 * 
	 * @param userId
	 *            userId
	 * @return jsonData
	 */
	public String getMainPunchData(String userId) {
		return settings.getString("MainPunchData" + userId, "");
	}

	/***
	 * 保存我的班级、班级首页的背景图片的地址
	 * 
	 * @param myclassheaderbackgroudPic
	 * @param classindexbackgroudbefore
	 * @param classindexbackgroudafter
	 */
	public void saveBackgroudPicUrl(String myclassheaderbackgroudPic, String classindexbackgroudbefore, String classindexbackgroudafter) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putString("myclassheaderfragment_backgroud_pic_url", myclassheaderbackgroudPic);
		editor.putString("classindex_backgroud_pic_url_before", classindexbackgroudbefore);
		editor.putString("classindex_backgroud_pic_url_after", classindexbackgroudafter);
		editor.commit();
	}

	/***
	 *
	 * @return
	 */
	public String getClassIndexBackgroudPicBeforeUrl() {
		return settings.getString("classindex_backgroud_pic_url_before", "");
	}

	/***
	 *
	 * @return
	 */
	public String getClassIndexBackgroudPicAfterUrl() {
		return settings.getString("classindex_backgroud_pic_url_after", "");
	}

	/***
	 *
	 * @return
	 */
	public String getMyClassHeaderBackgroudPicUrl() {
		return settings.getString("myclassheaderfragment_backgroud_pic_url", "");
	}

	/**
	 * 获取新消息中心时间戳
	 * 
	 * @return
	 */
	public String getNewMessageTimestamp(String userId) {
		return settings.getString(Constant.PRE_NEW_MESSAGE_TIMESTAMP + userId, "");
	}

	/**
	 * 保存新消息中心时间戳
	 * 
	 * @param userId
	 * @param timestamp
	 */
	public void saveNewMessageTimestamp(String userId, String timestamp) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putString(Constant.PRE_NEW_MESSAGE_TIMESTAMP + userId, timestamp);
		editor.commit();
	}

	/**
	 * save last study class id
	 * 
	 * @param path
	 */
	public void storeLastStudyClassId(String classId) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putString("lastStudyClassId", classId);
		editor.commit();
	}

	/**
	 * get last study class id
	 * 
	 * @return
	 */
	public String getLastStudyClassId() {
		return settings.getString("lastStudyClassId", "");
	}

	public void storeIsShowContinuesLearn(boolean isShow) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putBoolean("IsShowContinuesLearn", isShow);
		editor.commit();
	}

	public boolean getIsShowContinuesLearn() {
		return settings.getBoolean("IsShowContinuesLearn", true);
	}

	/**
	 * 返回是否创建过快捷方式
	 *
	 * @param context
	 * @return
	 */
	public  boolean isAddShortCut(Context context) {
		return settings.getBoolean("addShortCut", false);
	}

	/**
	 * 保存用户创建过快捷方式
	 */
	public void addShortCut(Context context) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putBoolean("addShortCut", true);
		editor.commit();
	}

	/**
	 * 用户还可以开通班级的数量
	 *
	 * @param context
	 * @return
	 */
	public int getOpenedClassCount(Context context) {
		return settings.getInt("OpenedClassCount", 0);
	}

	/**
	 * 用户还可以开通班级的数量
	 *
	 * @param context
	 * @return
	 */
	public void setOpenedClassCount(Context context, int count) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putInt("OpenedClassCount", count);
		editor.commit();
	}

	/**
	 * 保存每日一句读取时间以及内容
	 * @param time 当前时间
	 * @param word 语句
	 */
	public void storeSplashAWrodTime(String time, String word) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putString("splashAWrodTime", time);
		editor.putString("splashAWrod", word);
		editor.commit();
	}

	/**
	 * 返回每日一句存储时间
	 * @return
	 */
	public String getSplashAWrodTime() {
		return settings.getString("splashAWrodTime", "");
	}

	/**
	 * 返回每日一句句子
	 * @return
	 */
	public String getSplashAWrod() {
		return settings.getString("splashAWrod", "");
	}

	/**
	 * 同步数据日期
	 */
	public void storeSynchronizationDate(String date) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putString("synchronizationDate", date);
		editor.commit();
	}

	public String getSynchronizationDate() {
		return settings.getString("synchronizationDate", "");
	}

	/**
	 * 保存学习日期供上报学习时间使用
	 */
	public void storeStudyDate(String date) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putString("StudyDate", date);
		editor.commit();
	}

	public String getStudyDate() {
		return settings.getString("StudyDate", "");
	}
}
