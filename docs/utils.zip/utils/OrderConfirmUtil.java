package com.hujiang.hjclass.utils;

import android.app.Activity;
import android.text.TextUtils;

import com.hujiang.hjclass.AppConfig;

/**
 * Created by lvhuacheng on 2016/9/28.
 */
public class OrderConfirmUtil {

    public static void orderConfirm(Activity act, String classId){
        orderConfirm(act,classId,null);
    }

    public static void orderConfirm(Activity act, String classId, String couponCode){
        if(act == null || TextUtils.isEmpty(classId)){
            return;
        }
        String url = AppConfig.ORDER_CONFIRM_URL + classId;
        if (couponCode != null && couponCode.trim().length() > 0) {
            url = url+ "&code=" + couponCode;
        }
        orderConfirmByURL(act,url);
    }

    public static void orderConfirmByURL(Activity act, String url){
        if (act == null || TextUtils.isEmpty(url)){
            return;
        }
        LogUtil.error("orderConfirm","url: "+url);
        HJWebBrowserUtil.start(act,url);
    }
}
