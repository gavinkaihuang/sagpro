package com.hujiang.hjclass.utils;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;

public class PNGUtlis {

	/**
	 * 移除PNG 多边框
	 * 
	 * @return
	 */
	public static Bitmap removerTransparentFrame(Bitmap bm) {
		Point startPoint = getTranspanrent(bm, Color.TRANSPARENT); // 获取开始点
		Bitmap tempBitmap = adjustPhotoRotation(bm, 180);
		Point endPoint = getTranspanrent(tempBitmap, Color.TRANSPARENT); // 获取结束点
		if (tempBitmap != null) {
			tempBitmap.recycle();
			tempBitmap = null;
		}
		int w = bm.getWidth() - startPoint.x - endPoint.x;
		int h = bm.getHeight() - startPoint.y - endPoint.y;
		return crop(bm, startPoint.x, startPoint.y, w, h);
	}

	/**
	 * 背景改为白色
	 * @param color
	 * @param orginBitmap
	 * @return
	 */
	public static Bitmap drawBg4Bitmap(int color, Bitmap orginBitmap) {
		Paint paint = new Paint();
		paint.setColor(color);
		Bitmap bitmap = Bitmap.createBitmap(orginBitmap.getWidth(), orginBitmap.getHeight(), orginBitmap.getConfig());
		Canvas canvas = new Canvas(bitmap);
		canvas.drawRect(0, 0, orginBitmap.getWidth(), orginBitmap.getHeight(), paint);
		canvas.drawBitmap(orginBitmap, 0, 0, paint);
		return bitmap;
	}

	/**
	 * 旋转
	 * 
	 * @param bm
	 * @param orientationDegree
	 * @return
	 */
	public static Bitmap adjustPhotoRotation(Bitmap bm, int orientationDegree) {
		Matrix matrix = new Matrix();
		matrix.reset();
		matrix.setRotate(orientationDegree);
		Bitmap bm1 = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), matrix, true);
		return bm1;
	}

	/**
	 * 获取与传入颜色不同的第一个颜色
	 * 
	 * @param mBitmap
	 * @param dot
	 */
	private static Point getTranspanrent(Bitmap mBitmap, int color) {
		int mBitmapHeight = mBitmap.getHeight();
		int mBitmapWidth = mBitmap.getWidth();
		Point mPoint = new Point();
		for (int i = 0; i < mBitmapHeight; i++) {
			for (int j = 0; j < mBitmapWidth; j++) {
				int mColor = mBitmap.getPixel(j, i);
				if (mColor != color) {
					mPoint.x = j;
					mPoint.y = i;
					return mPoint;
				}
			}
		}
		return mPoint;
	}

	/**
	 * 裁剪图片
	 * 
	 * @param bm
	 *            原图
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 * @return
	 */
	private static Bitmap crop(Bitmap bm, int x, int y, int width, int height) {
		if (bm == null) {
			return null;
		}
		if (bm.getWidth() < width || bm.getHeight() < height) {
			return bm;
		}
		try {
			bm = Bitmap.createBitmap(bm, x, y, width, height);
		} catch (Exception e) {
		}
		return bm;
	}

}
