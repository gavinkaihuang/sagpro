package com.hujiang.hjclass.utils;

import android.content.pm.PackageInfo;
import android.text.TextUtils;

import com.hujiang.hjclass.MainApplication;

import java.util.List;

/**
 * Created by lvhuacheng on 2016/6/14.
 */
public class PackageUtil {

    /**
     * 判断包名为package_name的app是否已经安装
     * @param package_name
     * @return
     */
    public static boolean app_is_install(String package_name){
        if(TextUtils.isEmpty(package_name)){
            return false;
        }
        List<PackageInfo> appList = MainApplication.getContext().getPackageManager().getInstalledPackages(0);
        if(appList == null || appList.size() == 0){
            return false;
        }
        PackageInfo info = null;
        for (int i = 0; i < appList.size(); i++) {
            info = appList.get(i);
            if(package_name.equals(info.packageName)){
                return true;
            }
        }
        return false;
    }

}
