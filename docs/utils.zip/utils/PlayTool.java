package com.hujiang.hjclass.utils;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;

import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.R;
import com.hujiang.hjclass.activity.lesson.TrunkErrorTool;
import com.hujiang.hjclass.db.ClassPorvider;
import com.hujiang.hjclass.db.tables.TLastClassOpenTimeColumns;
import com.hujiang.hjclass.db.tables.TLessonInfoColumns;
import com.hujiang.hjclass.db.tables.TStudyRecordColumns;
import com.hujiang.hjclass.db.tables.URIList;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.util.AppPara;
import com.hujiang.util.DateUtil;

/**
 * 播放工具
 * 
 * @author pengjia
 * 
 */
public class PlayTool {

	/**
	 * 跳转到播放
	 */
	public void play(Activity context, String classId, String lessonId) {
		String userID = LoginUtils.getUserId(context);
		if (TrunkErrorTool.isTrunkFileExist(context, userID)) {
			String userTOKEN = LoginUtils.getUserToken(context);
			int status = ClassUtils.checkClassPlayStatus(context, userID, classId, "" + lessonId);
			switch (status) {
			case 0:
				ClassPorvider classPorvider = new ClassPorvider();
				Cursor cursor = null;
				try {
					cursor = classPorvider.query(URIList.LESSON_INFO_URI, null, TLessonInfoColumns.CLASS_ID + "=? and " + TLessonInfoColumns.LESSON_ID + "=? " + " and " + TLessonInfoColumns.USER_ID + "=? ", new String[] {
							classId, lessonId, userID }, null);
					if (cursor != null && cursor.getCount() > 0) {
						cursor.moveToFirst();
						int playTime = cursor.getInt(cursor.getColumnIndex(TLessonInfoColumns.LESSON_PLAY_TIME));
						String isStudy = cursor.getString(cursor.getColumnIndex(TLessonInfoColumns.IS_STUDY));
						String lessonName = cursor.getString(cursor.getColumnIndex(TLessonInfoColumns.LESSON_NAME));
						String lessonVersion = cursor.getString(cursor.getColumnIndex(TLessonInfoColumns.LESSON_VERSION));
						String tempLock = cursor.getString(cursor.getColumnIndex(TLessonInfoColumns.IS_LOCK));
						boolean isLocked = tempLock.equalsIgnoreCase("true") ? true : false;
						int score = getLessonScore(lessonId, userID);
						int studyTime = getLessonTime(lessonId, userID);
						int studyStatus = getLessonStatus(lessonId, userID);
						int updatedStudyStatus = isStudy.equalsIgnoreCase("true") ? 1 : 0;
						if (updatedStudyStatus != studyStatus) {
							// 用网上的学习就更新本地的学习记录
							studyStatus = updatedStudyStatus;
							updateLessonStudyStatus(userID, lessonId, studyStatus, score);
						}
						ContentValues contentValues = new ContentValues();
						contentValues.put("last_enter_time", DateUtil.formatDateLongToString(System.currentTimeMillis()));
						MainApplication.getContext().getContentResolver()
								.update(URIList.CLASS_LAST_ENTER_CLASS_TIME_URL, contentValues, TLastClassOpenTimeColumns.USER_ID + "=? and " + TLastClassOpenTimeColumns.CLASS_ID + "=? ", new String[] { userID, classId });
//						HJLessonVO vo = ClassUtils.createLessonVO(MainApplication.getContext(), Integer.parseInt(classId), lessonName, userTOKEN, Integer.parseInt(lessonId), true, playTime, score, studyStatus, studyTime, false);
//						ClassUtils.playVideo(context, vo, lessonVersion + "", isLocked);
                   //     Bundle vo = ClassUtils.createLessonVO(MainApplication.getContext(), classId, lessonName, userTOKEN, lessonId, true, playTime, score, studyStatus, studyTime, false);
						ClassUtils.playVideo(context, userID, classId, lessonId, playTime);
					}
				} catch (Exception e) {

				} finally {
					if (cursor != null) {
						cursor.close();
					}
				}
				break;
			case -1:
				HJToast.makeText(context, R.string.prompt_class_file_no_permission, HJToast.LENGTH_LONG).show();
				break;
			case -2:
				HJToast.makeText(context, R.string.prompt_class_file_broken, HJToast.LENGTH_LONG).show();
				break;
			}
		} else {
			String message = context.getString(R.string.bind_over_max_devices_title);
			ClassUtils.showNoTrunkFileNDKAlertDialog(context, message, true);
		}
	}

	public int updateLessonStudyStatus(String userID, String lessonID, int status, int score) {
		ContentValues contentValues = new ContentValues();
		contentValues.put(TStudyRecordColumns.STUDY_SIGN, status);
		ClassPorvider classPorvider = new ClassPorvider();
		int r_status = getLessonData(TStudyRecordColumns.STUDY_SIGN, lessonID, userID, true);

		if (r_status == -1) {
			ContentValues cv = new ContentValues();
			cv.put(TStudyRecordColumns.USESR_ID, "" + userID);
			cv.put(TStudyRecordColumns.LESSON_ID, "" + lessonID);
			cv.put(TStudyRecordColumns.STUDY_SIGN, status);
			cv.put(TStudyRecordColumns.STUDY_SCROE, "" + score);
			Uri uri = classPorvider.insert(URIList.TSTUDY_RECORD_URI, cv);
			return 0;
		} else {
			return classPorvider.update(URIList.TSTUDY_RECORD_URI, contentValues, TStudyRecordColumns.USESR_ID + "=? and " + TStudyRecordColumns.LESSON_ID + "=?", new String[] { userID, "" + lessonID });
		}
	}

	private int getLessonData(String column, String lessonID, String userID) {
		return getLessonData(column, lessonID, userID, false);
	}

	private int getLessonData(String column, String lessonID, String userID, boolean checkData) {
		int data = checkData ? -1 : 0;
		Cursor cursor = MainApplication.getContext().getContentResolver()
				.query(URIList.TSTUDY_RECORD_URI, null, TStudyRecordColumns.USESR_ID + "=? AND " + TStudyRecordColumns.LESSON_ID + " = ?", new String[] { "" + userID, "" + lessonID }, null);
		if (cursor != null) {

			while (cursor.moveToNext()) {
				data = cursor.getInt(cursor.getColumnIndex(column));// TStudyRecordColumns.STUDY_SIGN));
				break;
			}

			cursor.close();
		}
		return data;
	}

	private int getLessonTime(String lessonID, String userID) {
		return getLessonData(TStudyRecordColumns.PLAY_POSITION, lessonID, userID);
	}

	private int getLessonStatus(String lessonID, String userID) {
		return getLessonData(TStudyRecordColumns.STUDY_SIGN, lessonID, userID);
	}

	private int getLessonScore(String lessonID, String userID) {
		return getLessonData(TStudyRecordColumns.STUDY_SCROE, lessonID, userID);
	}

	/**
	 * 获取课程信息
	 * 
	 * @param classId
	 * @param lessonId
	 */
	private Cursor getLessonInfo(String classId, String lessonId, String userid) {

		ClassPorvider classPorvider = new ClassPorvider();
		Cursor cursor = null;
		try {
			cursor = classPorvider.query(URIList.LESSON_INFO_URI, null, TLessonInfoColumns.CLASS_ID + "=? and " + TLessonInfoColumns.LESSON_ID + "=? " + "=? and " + TLessonInfoColumns.USER_ID + "=? ", new String[] { classId,
					lessonId, userid }, null);

		} catch (Exception e) {
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return cursor;
	}



}
