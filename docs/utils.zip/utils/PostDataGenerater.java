package com.hujiang.hjclass.utils;

import android.content.Context;
import android.text.TextUtils;

import com.hujiang.hjclass.AppConfig;
import com.hujiang.hjclass.Constant.RequestActionConstant;
import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.adapter.model.ClassTaskCommitParamModel;
import com.hujiang.hjclass.db.business.LearningSystemBusiness;
import com.hujiang.hjclass.model.LearningSystemBaseNodeBean;
import com.hujiang.hjclass.model.LearningSystemClassTaskSubmitPostDataModel;
import com.hujiang.hjclass.model.LearningSystemClassTaskSyncPostDataModel;
import com.hujiang.hjclass.model.LearningSystemIntensivePackageBean;
import com.hujiang.hjclass.model.LearningSystemSectionBean;
import com.hujiang.hjclass.model.LearningSystemTaskBean;
import com.hujiang.hjclass.utils.DiscountWebAPI.DiscountKeyWords;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.util.DateUtil;
import com.hujiang.util.EncodeUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

/**
 * Created by Gavin on 13-10-14.
 */
public class PostDataGenerater {

	public static final String TAG = "PostDataGenerater";

	/**
	 * 我的网校每页显示数量
	 */
	public static final int MY_CLASS_PER_PAGE = 500;

	/**
	 * 检查优惠劵
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateCheckCouponCode(Context context, String code, String verify_code) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_COUPON_CHECK_CODE);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("token", token);
		htable.put("time_stamp", 0);
		htable.put("code", code);
		htable.put("verify_code", verify_code);
		root.put("data", htable);
		return root;
	}

	public static Hashtable generateCheckOrder(Context context, String class_id, String code) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ORDER_CHECKORDER);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("token", token);
		htable.put("time_stamp", 0);
		if (class_id != null && class_id.length() > 0) {
			htable.put("class_id", class_id);
		}
		if (code != null && code.length() > 0) {
			htable.put("code", code);
		}
		root.put("data", htable);
		return root;
	}

	/**
	 * Lesson List 班级列表
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generatePunchParams(Context context, String classID) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_PUNCH);

		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("class_id", classID);
		htable.put("token", token);
		root.put("data", htable);

		return root;
	}

	/**
	 * Lesson List 班级列表
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateLessonListParams(Context context, int classID, int line) {
		Hashtable root = new Hashtable();
		root.put("action", RequestActionConstant.ACTION_CLASS_LESSON_LIST_NEW_TASK);

		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("class_id", classID);
		htable.put("token", token);
		htable.put("line", line);
		htable.put("time_stamp", "");
		root.put("data", htable);

		return root;
	}

	/**
	 * My Class List 我的网校
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateMyClassListParams(Context context, int classKind, int pageNo) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_MY_CLASS_LIST);

		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("class_kind", classKind);
		htable.put("num_page", MY_CLASS_PER_PAGE);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("index", pageNo);
		root.put("data", htable);

		return root;
	}

	/**
	 * 体验中心列表
	 * 
	 * @param context
	 * @param category_id
	 * @return
	 */
	public static Hashtable generateExperienceListParams(Context context, int class_id) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_EXPERIENCE_CATEGORY_LIST);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("category_id", class_id);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	/**
	 * 班级首页
	 * 
	 * @param context
	 * @param category_id
	 * @return
	 */
	public static Hashtable generateClassIndexParams(Context context, String class_id) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_CLASS_HOME_PAGE);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("class_id", class_id);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Hashtable generatSplashParams(Context context, String screen_paramter) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_SPLASH);
		Hashtable htable = new Hashtable();
		htable.put("platform", "Android");
		htable.put("screen_paramter", screen_paramter);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("time_stamp", "");
		root.put("data", htable);
		return root;
	}

	/**
	 * 选课中心 or 优惠券选课
	 * 
	 * @param context
	 * @param classTypeID
	 * @param pageNo
	 * @return
	 */
	public static Hashtable generateClassListParams(Context context, int classTypeID, String keyWord, int pageNo, String discountCode) {
		Hashtable root = new Hashtable();
		root.put("action", (discountCode != null) ? DiscountKeyWords.GET_COURSE_BYCODE : Constant.ACTION_CLASS_CENTER_LIST);

		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("index", pageNo);
		htable.put("time_stamp", MY_CLASS_PER_PAGE);
		htable.put("class_type_id", classTypeID);
		htable.put("num_page", MY_CLASS_PER_PAGE);
		if (discountCode != null) {
			htable.put(DiscountKeyWords.CODE, discountCode);
		}
		htable.put("key_word", keyWord == null ? "" : keyWord);
		root.put("data", htable);
		return root;
	}

	/**
	 * 获取笔记
	 * 
	 * @param context
	 * @param class_id
	 * @param lesson_id
	 * @param ismine
	 * @param keywords
	 * @param index
	 * @return
	 */
	public static Hashtable generateNoteListParams(Context context, int class_id, int lesson_id, int ismine, String keywords, int index) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_NOTE_LIST);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("class_id", class_id);
		htable.put("lesson_id", lesson_id);
		htable.put("ismine", ismine);
		htable.put("index", index);
		htable.put("keywords", keywords);
		root.put("data", htable);
		return root;
	}

	/**
	 * 收藏
	 * 
	 * @param context
	 * @param class_id
	 * @param lesson_id
	 * @param ismine
	 * @param keywords
	 * @param index
	 * @return
	 */
	public static Hashtable generateAddCollectionParams(Context context, int class_id, int lesson_id, int note_parent_id, int note_id) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_NOTE_ADD_COLLECTION);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("class_id", class_id);
		htable.put("lesson_id", lesson_id);
		htable.put("note_parent_id", note_parent_id);
		htable.put("note_id", note_id);
		htable.put("note_device_type", 3);
		root.put("data", htable);
		return root;
	}

	/**
	 * 推荐
	 * 
	 * @param context
	 * @param class_id
	 * @param lesson_id
	 * @param ismine
	 * @param keywords
	 * @param index
	 * @return
	 */
	public static Hashtable generateNoteRecommendParams(Context context, int class_id, int lesson_id, int note_parent_id, int note_id) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_NOTE_RECOMMEND);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("class_id", class_id);
		htable.put("lesson_id", lesson_id);
		htable.put("note_parent_id", note_parent_id);
		htable.put("note_id", note_id);
		root.put("data", htable);
		return root;
	}

	/**
	 * 取消收藏
	 * 
	 * @param context
	 * @param class_id
	 * @param lesson_id
	 * @param ismine
	 * @param keywords
	 * @param index
	 * @return
	 */
	public static Hashtable generateNoteCancelCollectionParams(Context context, int class_id, int lesson_id, int note_parent_id, int note_id) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_NOTE_CANCEL_COLLECTION);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("class_id", class_id);
		htable.put("lesson_id", lesson_id);
		htable.put("note_parent_id", note_parent_id);
		htable.put("note_id", note_id);
		root.put("data", htable);
		return root;
	}

	/**
	 * 选课中心分类
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateClassCategoryParams(Context context) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_CLASS_CENTER_CLASSIFICATION);

		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		// htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);

		return root;
	}

	/**
	 * 解绑设备
	 */
	public static Hashtable generateUnBindParams(Context context, String token) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_UNBIND);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	/**
	 * 开通课程
	 */
	public static Hashtable generateOpenExperienceClassParams(Context context, String class_id) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_EXPERIENCE_OPEN_CLASS);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("class_id", class_id);
		root.put("data", htable);
		return root;
	}

	/**
	 * 答疑-提问
	 */
	public static Hashtable generateAddQuestionParams(Context context, String classId, String question, String detail, String[] posts_images, String[] posts_image_types) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ADD_QUESTION);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("class_id", classId);
		htable.put("question", EncodeUtil.encode(question));
		htable.put("detail", EncodeUtil.encode(detail));
		htable.put("posts_images", Arrays.toString(posts_images));
		htable.put("posts_image_types", Arrays.toString(posts_image_types));
		root.put("data", htable);
		return root;
	}

	/**
	 * 答疑-回答问题
	 */
	public static Hashtable generateAddAnswerParams(Context context, String questionId, String answer) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ADD_ANSWER);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("question_id", questionId);
		htable.put("answer", EncodeUtil.encode(answer));
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	/**
	 * 提交错误信息:点击课程下载或者播放时
	 */
	public static Hashtable generateSubmitErrorParams(Context context, String errorString) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_SUBMIT_ERROR);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("time_stamp", DateUtil.formatDateLongToString(System.currentTimeMillis()));
		htable.put("content", errorString);
		root.put("data", htable);
		return root;
	}

	/**
	 * 检查该班级是否已经开通
	 */
	public static Hashtable generateCheckIsClassOpenParams(Context context, String classId) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_CHECK_IS_CLASS_OPEN);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("time_stamp", DateUtil.formatDateLongToString(System.currentTimeMillis()));
		htable.put("class_id", classId);
		root.put("data", htable);
		return root;
	}

	/**
	 * 检查体验班推荐购买的intro页面 {"action": "sale_recommend","data": {"token":
	 * "houleixx","class_id":10097,"user_agent":
	 * "ios/4.3/ksjdfkjskfjksfjksjfksjkfsjkjksjk","time_stamp":
	 * "2013.10.13.10.10.12"}}
	 */
	public static Hashtable generateSaleRecommendParams(Context context, String classId) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_SALE_RECOMMEND);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("time_stamp", DateUtil.formatDateLongToString(System.currentTimeMillis()));
		htable.put("class_id", classId);
		root.put("data", htable);
		return root;
	}

	/**
	 * 消息中心
	 * {"action":"message_center_list","data":{"user_agent":"ios/4","token":"",
	 * "message_stamp":"","time_stamp":"2013-10-13","message_channel":"system"}}
	 */
	public static Hashtable generateMessageCenterParams(Context context, String msgStamp, String timeStamp) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_MESSAGE_CENTER);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("time_stamp", timeStamp);
		htable.put("message_stamp", msgStamp);
		// htable.put("message_id", msgId);
		root.put("data", htable);
		return root;
	}

	/**
	 * 获取讨论区分类 {"action": "discuss_category","data":
	 * {"class_id":10097,"user_agent": "ios/4.3/abcde","time_stamp":
	 * "2013.10.13.10.10.12"} }
	 */
	public static Hashtable generatediscussCategoryParams(Context context, String classId) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_DISCUSS_CATEGORY);
		Hashtable htable = new Hashtable();
		htable.put("class_id", classId);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		// htable.put("time_stamp",
		// com.hjclass.utils.Utils.formatDateLongToString(System.currentTimeMillis()));
		root.put("data", htable);
		return root;
	}

	/**
	 * 回复帖子
	 */
	public static Hashtable generateHomeworkAnswerParams(Context context, String classId, String postsId, String postsAnswerId, String postsText, String[] postsImages, String[] postsImageTypes, String postsAudio, int isOwnerOnly, int isGood) {
		Hashtable root = new Hashtable();
		String token = LoginUtils.getUserToken(context);
		root.put("action", Constant.ACTION_DISCUSS_ANSWER);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("token", token);
		htable.put("class_id", classId);
		htable.put("thread_id", postsId);
		htable.put("post_id", postsAnswerId);
		htable.put("posts_images", Arrays.toString(postsImages));
		htable.put("posts_text", EncodeUtil.encode(postsText));
		htable.put("posts_image_types", Arrays.toString(postsImageTypes));
		htable.put("posts_audio", postsAudio);
		htable.put("is_landlord_see", isOwnerOnly);
		htable.put("is_best", isGood);
		root.put("data", htable);
		return root;
	}
	/**
	 * 回复帖子
	 */
	public static Hashtable generatediscussAnswerParams(Context context, String classId, String postsId, String postsAnswerId, String postsText, String[] postsImages, String[] postsImageTypes, String postsAudio, int isOwnerOnly) {
		Hashtable root = new Hashtable();
		String token = LoginUtils.getUserToken(context);
		root.put("action", Constant.ACTION_DISCUSS_ANSWER);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("token", token);
		htable.put("class_id", classId);
		htable.put("posts_id", postsId);
		htable.put("posts_answer_id", postsAnswerId);
		htable.put("posts_images", Arrays.toString(postsImages));
		htable.put("posts_text", EncodeUtil.encode(postsText));
		htable.put("posts_image_types", Arrays.toString(postsImageTypes));
		htable.put("posts_audio", postsAudio);
		htable.put("is_landlord_see", isOwnerOnly);
		root.put("data", htable);
		return root;
	}

	/**
	 * 发布帖子
	 */
	public static Hashtable generatePostsParams(Context context, String classId, String postsTitle, String postsText, String[] postsImages, String[] postsImageTypes, String postsAudio, String postsCategory) {
		Hashtable root = new Hashtable();
		String token = LoginUtils.getUserToken(context);
		root.put("action", Constant.ACTION_POSTS);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("token", token);
		htable.put("class_id", classId);
		htable.put("posts_title", EncodeUtil.encode(postsTitle));
		htable.put("posts_text", EncodeUtil.encode(postsText));
		htable.put("posts_images", Arrays.toString(postsImages));
		htable.put("posts_image_types", Arrays.toString(postsImageTypes));
		htable.put("posts_audio", postsAudio);
		htable.put("posts_category", postsCategory);
		root.put("data", htable);
		return root;
	}

	/**
	 * @param array
	 * @param class_id
	 *            int 班级类型
	 * @param lesson_id
	 *            int 课程类型
	 * @param last_page_num
	 *            int 课件页数
	 * @param play_time
	 *            int 课件播放时间
	 * @param is_studyed
	 *            int 课件是否学完
	 * @param study_time
	 *            string 课件总的学习时间
	 * @param media_total_time
	 *            string 课件总的播放时间
	 * @param lesson_xml
	 *            string 课程测试结果
	 * @param study_rate
	 *            float 做题正确率
	 * @param correct_question_num
	 *            int 正确的题目数量
	 * @param total_question_num
	 *            int 总的题目数量
	 * @param time_stamp
	 *            string 记录的时间戳
	 * @return
	 */
	public static JSONArray addToSyncDataArray(JSONArray array, String class_id, String lesson_id, int last_page_num, int play_time, int is_studyed, String study_time, String media_total_time, String lesson_xml, double study_rate, int correct_question_num,
			int total_question_num, String time_stamp) {
		JSONObject item = new JSONObject();
		try {
			item.put("class_id", class_id);
			item.put("lesson_id", lesson_id);
			item.put("last_page_num", last_page_num);
			item.put("play_time", play_time);
			item.put("is_studyed", is_studyed);
			item.put("study_time", study_time);
			item.put("media_total_time", media_total_time);
			item.put("lesson_xml", lesson_xml);
			item.put("study_rate", study_rate);
			item.put("correct_question_num", correct_question_num);
			item.put("total_question_num", total_question_num);
			item.put("time_stamp", time_stamp);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		array.put(item);
		return array;
	}

	/**
	 * @param syncData
	 *            array 要同步的数据
	 * @return
	 */
	public static JSONObject getJsonStr_SyncRecord(Context context, JSONArray syncData) {
		JSONObject record = new JSONObject();
		try {
			record.put("action", Constant.ACTION_LESSON_RECORD);
			JSONObject data = new JSONObject();
			String token = LoginUtils.getUserToken(context);
			data.put("token", token);

			data.put("syn_data", syncData);

			data.put("user_agent", DeviceInfo.getUserAgent(context));
			data.put("time_stamp", MY_CLASS_PER_PAGE);

			record.put("data", data);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return record;
	}

	public static Hashtable generateAddAnswerAsk(Context context, String questionId, String answerId, String askContent) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ADD_ANSWERASK);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("question_id", questionId);
		htable.put("answer_id", answerId);
		htable.put("ask_content", EncodeUtil.encode(askContent));
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	public static Hashtable generateAddAnswerAskAnswer(Context context, String questionId, String answerId, String askId, String askContent) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ADD_ANSWERASKANSWER);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("question_id", questionId);
		htable.put("answer_id", answerId);
		htable.put("ask_id", askId);
		htable.put("ask_content", EncodeUtil.encode(askContent));
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	public static Hashtable generateAddAnswerComment(Context context, String answerId, String content) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ADD_ANSWERCOMMENT);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("answer_id", answerId);
		htable.put("content", EncodeUtil.encode(content));
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	/**
	 * 获取登录用户已毕业的classIds
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateGraduatedClassIds(Context context) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_MY_GRADUATE_CLASS);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("token", token);
		htable.put("time_stamp", "");
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	/**
	 * 学币订单列表数据请求参数
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateHJCurrencyOrderlist(Context context, int index) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ORDER_XBORDER_LIST);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("index", index);
		htable.put("token", token);
		htable.put("time_stamp", "");
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	/**
	 * 课程订单列表数据请求参数
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateLessonOrderlist(Context context, int index) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ORDER_CLASSORDER_LIST);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("index", index);
		htable.put("token", token);
		htable.put("time_stamp", "");
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	/**
	 * 课程订单列表数据请求参数
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateCancelOrder(Context context, String orderId) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ORDER_CANCELORDER);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("order_id", orderId);
		htable.put("token", token);
		htable.put("time_stamp", "");
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	/**
	 * 获取是否能支付标示
	 * 
	 * @param context
	 * @param orderId
	 * @return
	 */
	public static Hashtable generateOrderCanpay(Context context, String orderId) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ORDER_CANPAY);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("order_id", orderId);
		htable.put("token", token);
		htable.put("time_stamp", "");
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		root.put("data", htable);
		return root;
	}

	/**
	 * 获取课程咨询内容
	 * 
	 * @param url
	 * @param classID
	 * @return
	 */
	public static String generateClassConsult(String url, String classID) {
		return url + Constant.ACTION_CLASS_CONSULT + "?classId=" + classID;
	}

	/**
	 * 教验coupon 是否可用 可以传多张卡券，已逗号隔开
	 * 
	 * @param url
	 * @param type
	 *            卡券类型
	 * @param
	 *
	 * @return
	 */
	public static String generateCheckCoupon(String url, int type, String codes) {
		return url + Constant.ACTION_CHECK_COUPON_BY_LIST + "?type=" + type + "&code=" + codes;
	}

	/**
	 * 验证优惠券 只能验证一张
	 * 
	 * @param url
	 * @param code
	 * @return
	 */
	public static String generateCheckCoupon(String url, String code) {
		return url + Constant.ACTION_COUPON_DETAIL + "?code=" + code;
	}

	/**
	 * 获取用户卡券
	 * 
	 * @param url
	 * @return
	 */
	public static String generateGetCouponList(String url) {
		return url + Constant.ACTION_GET_COUPON_LIST;
	}

	/**
	 * 获取用户状态
	 * 
	 * @param preUrl
	 * @return
	 */
	public static String genLoadUserTokenUrl(String preUrl) {
		return preUrl + Constant.ACTION_LOAD_USER_STATUS;
	}

	/**
	 * 获取课程延期信息
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateLessonExtensionInfoParams(Context context, String classId) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_CLASS_DELAY_INFO);
		String token = LoginUtils.getUserToken(MainApplication.getContext());
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(MainApplication.getContext()));
		htable.put("token", token);
		htable.put("time_stamp", "");
		htable.put("class_id", classId);
		root.put("data", htable);
		return root;
	}

	/**
	 * 生成毕业班级请求参数
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateMyGraduateClassParams(Context context, String classId) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.CLASS_GRADUATE_CLASS);
		String token = LoginUtils.getUserToken(MainApplication.getContext());
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(MainApplication.getContext()));
		htable.put("token", token);
		htable.put("time_stamp", "");
		htable.put("class_id", classId);
		root.put("data", htable);
		return root;
	}

	/**
	 * 生成课程延期请求参数
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateLessonExtensionParams(Context context, String classId, String extensionDay, String reason) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_CLASS_DELAY);
		String token = LoginUtils.getUserToken(MainApplication.getContext());
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(MainApplication.getContext()));
		htable.put("token", token);
		htable.put("time_stamp", "");
		htable.put("class_id", classId);
		htable.put("day", extensionDay);
		htable.put("reason", reason);
		htable.put("index", 1);
		root.put("data", htable);
		return root;
	}

	/**
	 * 生成社团帖子发布参数
	 * 
	 * @param context
	 *            ctx
	 * @param communityId
	 *            社团ID
	 * @param postsTitle
	 *            帖子标题
	 * @param postsText
	 *            帖子内容
	 * @param postsImages
	 *            图片URL数组
	 * @param postsAudio
	 *            音频
	 * @param categoryId4ST
	 *            社团帖子分类ID
	 * @return
	 */
	public static Hashtable generateSTCreateTopicParams(Context context, String communityId, String postsTitle, String postsText, String[] postsImages, String[] postsImageTypes, String postsAudio, String categoryId4ST) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_SET_COMMUNITY_TOPIC);
		String token = LoginUtils.getUserToken(MainApplication.getContext());
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(MainApplication.getContext()));
		htable.put("token", token);
		htable.put("time_stamp", "");
		htable.put("community_id", communityId);
		htable.put("posts_title", !TextUtils.isEmpty(postsTitle) ? EncodeUtil.encode(postsTitle) : "");
		htable.put("posts_text", !TextUtils.isEmpty(postsText) ? EncodeUtil.encode(postsText) : "");
		htable.put("posts_images", Arrays.toString(postsImages));
		htable.put("posts_image_types", Arrays.toString(postsImageTypes));
		htable.put("posts_audio", postsAudio);
		htable.put("source_id", Constant.ST_ANDROID_SOURCE_CODE);
		htable.put("board_id", categoryId4ST);
		root.put("data", htable);
		return root;
	}

	/**
	 * 生成社团帖子回复参数
	 * 
	 * @param context
	 *            ctx
	 * @param topicId
	 *            帖子ID
	 * @param postId
	 *            帖子一级回复ID
	 * @param replyId
	 *            帖子二级回复ID
	 * @param postsText
	 *            帖子内容
	 * @param replyLevel
	 *            0：一级回复；1：二级回复
	 * @param postsImages
	 *            图片URL数组
	 * @param postsAudio
	 *            音频
	 * @param onlyOwnerVisible
	 * 			  仅楼主可见
	 * @return
	 */
	public static Hashtable generateSTReplyParams(Context context, String topicId, String postId, String replyId, String postsText, String replyLevel, String[] postsImages, String[] postsImageTypes, String postsAudio,boolean onlyOwnerVisible) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_REPLY_COMMUNITY_TOPIC);
		String token = LoginUtils.getUserToken(MainApplication.getContext());
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(MainApplication.getContext()));
		htable.put("token", token);
		htable.put("time_stamp", "");
		htable.put("topic_id", topicId == null ? "" : topicId);
		htable.put("post_id", postId == null ? "" : postId);
		htable.put("reply_id", replyId == null ? "" : replyId);
		htable.put("posts_text", postsText == null ? "" : EncodeUtil.encode(postsText));
		htable.put("reply_level", replyLevel);
		htable.put("posts_images", Arrays.toString(postsImages));
		htable.put("posts_image_types", Arrays.toString(postsImageTypes));
		htable.put("posts_audio", postsAudio == null ? "" : postsAudio);
		htable.put("source_id", Constant.ST_ANDROID_SOURCE_CODE);
		htable.put("visibility", onlyOwnerVisible ? 1 : 0);
		root.put("data", htable);
		return root;
	}

	/**
	 * 生成获取社团发帖分类的参数
	 * 
	 * @param context
	 *            ctx
	 * @param communityId
	 *            社团ID
	 * @return
	 */
	public static Hashtable generateSTGetCategoriesParams(Context context, String communityId) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_GET_TOPIC_BOARD);
		String token = LoginUtils.getUserToken(MainApplication.getContext());
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(MainApplication.getContext()));
		htable.put("token", token);
		htable.put("time_stamp", "");
		htable.put("community_id", communityId);
		root.put("data", htable);
		return root;
	}

	/**
	 * Lesson List 班级列表
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateUserInfoParams(Context context) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_USER_MESSAGE);
		String token = LoginUtils.getUserToken(MainApplication.getContext());
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(MainApplication.getContext()));
		htable.put("token", token);
		htable.put("time_stamp", "");
		root.put("data", htable);
		return root;
	}

	/**
	 * Lesson List 班级列表
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateExperienceCenter(Context context) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_EXPERIENCE);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("token", token);
		root.put("data", htable);

		return root;
	}

	/**
	 * 获取班级详情
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateClassInfo(Context context, String classID, String code) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_SINGLE_CLASS_DETAIL);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("app_info", DeviceInfo.getHeadUserAgent());
		htable.put("class_id", classID);
		if (code != null) {
			htable.put("discount_code", code);
		}
		if (token == null || token.length() == 0) {
			token = "";
		}
		htable.put("token", token);
		root.put("data", htable);
		return root;
	}

	/**
	 * 获取大纲信息
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateClassOutline(Context context, String classID) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_COURSE_OUTLINE);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("app_info", DeviceInfo.getHeadUserAgent());
		htable.put("class_id", classID);
		if (token == null || token.length() == 0) {
			token = "";
		}
		htable.put("token", token);
		root.put("data", htable);
		return root;
	}

	/**
	 * 
	 * @param context
	 * @param classId
	 *            班级ID
	 * @param code
	 *            券号
	 * @param xbfee
	 *            使用学币,0：不使用，1：使用
	 * @param cellphone
	 *            电话号码
	 * @return
	 */
	public static Hashtable generateCreateClassOrder(Context context, String classId, String code, int xbfee, String cellphone) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ORDER_CREATEORDER);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("class_id", classId);
		if (code != null && code.length() > 0) {
			htable.put("code", code);
		}
		htable.put("xbfee", xbfee);
		htable.put("cellphone", cellphone);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("token", token);
		htable.put("time_stamp", 0);
		root.put("data", htable);
		return root;
	}

	/**
	 * 学币订单生成
	 * 
	 * @param context
	 * @param xbfee
	 *            学币数
	 * @param payfee
	 *            支付金额
	 * @param cellphone
	 *            手机号
	 * @return
	 */
	public static Hashtable generateCreateXBOrder(Context context, String xbfee, String payfee, String cellphone) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ORDER_CREATEXBORDER);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("payfee", payfee);
		htable.put("xbfee", xbfee);
		htable.put("cellphone", cellphone);
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("token", token);
		htable.put("time_stamp", 0);
		root.put("data", htable);
		return root;
	}

	/**
	 * 获取优惠劵列表
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generateCouponList(Context context) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_GET_USERCOUPON);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("token", token);
		htable.put("time_stamp", 0);
		root.put("data", htable);
		return root;
	}

	/**
	 * 获取充值优惠信息
	 * 
	 * @param context
	 * @return
	 */
	public static Hashtable generatetRechargePreferential(Context context) {
		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_ORDER_XBORDER_PAGEINFO);
		String token = LoginUtils.getUserToken(context);
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("token", token);
		htable.put("time_stamp", 0);
		root.put("data", htable);
		return root;
	}
	/**
	 * 提交学习任务
	 * @param classId
	 * @param taskIds
	 * @return
	 */
	public static ClassTaskCommitParamModel generateTaskPost(String classId, ArrayList<Integer> taskIds) {
		ClassTaskCommitParamModel model = new ClassTaskCommitParamModel();
		model.setClassId(classId);
		model.setTaskIds(taskIds);
		return model;
	}

	public static String generateUserInfo(String url) {
		String result = url + Constant.ACTION_USER_DETAIL;
		return result;
	}

	/**
	 * 沪江首页
	 * 
	 * @param url
	 * @return
	 */
	public static String generateHJClass(String url) {
		return url + Constant.ACTION_GET_HJ_INDEX;
	}

	/**
	 * 获取课程咨询内容
	 * @param url
	 * @param classKind
     * @return
     */
	public static String generateMyClassList(String url, int classKind) {
		return url + Constant.ACTION_MY_CLASS + "?class_kind=" + classKind;
	}

	/**
	 * 新的体验班首页
	 *
	 * @param url
	 * @param class_id
	 * @return
	 */
	public static String generateClassExperienceParams(String url, String class_id) {
		return url + Constant.CLASS_EXPERIENCE_ACTION + "?classID=" + class_id;
	}

	/**
	 * 免费班级的课程列表
	 *
	 * @param url
	 * @param class_id
	 * @return
	 */
	public static String generateLessonListParams(String url, String class_id) {
		return url + Constant.EXPERIENCE_LESSON_LIST + "?classID=" + class_id;
	}

	public static String generateLessonSummaryParams(String url,String lessonId, int teacherScore, int lessonScore, int uiScore) {
		return url + Constant.ACTION_GET_MOBILELESSON_LESSONSUMMARY + "?lessonId=" + lessonId +"&teacherScore="+teacherScore +"&lessonScore="+lessonScore +"&uiScore="+uiScore;
	}

	//获取用户点赞数量
	public static String generatePraiseParams(String url,int index) {
		return url + Constant.PRAISE_URL+"?index="+index;
	}

	//学习报告
	public static String generateLearnReportParams(String url,String classId) {
		return url + Constant.CLASS_REPORT+"?classid="+classId;
	}

	//完成任务用户
	public static String generateCompletedTaskUserParams(String url,String classId,int index,int pagesize) {
		return url + Constant.COMPLETED_TASK_USER+"?classid="+classId+"&index="+index+"&pagesize="+pagesize;
	}

	//点赞
	public static String generatePraiseParams(String url,String classId,String userid) {
		return url + Constant.USER_PRAISE+"?classId="+classId+"&userid="+userid;
	}


	/***
	 * 导流
	 * @param url
	 * @return
	 */
	public static String generateDiversionParams(String url) {
		return url + Constant.INIT_GUIDEPOPUP;
	}

	/**
	 * 班级首页加群
	 * @param classId
	 * @param className
	 * @return
	 */
	public static Hashtable generatetGetClassGroupEntryPostParams(String classId, String className) {
		Hashtable root = new Hashtable();
		root.put("group_id", classId);
		root.put("group_name", className);
		return root;
	}

	/**
	 * 生成收藏课程请求参数
	 * @param context
	 * @param classId
	 * @param token
	 * @return
	 */
	public static Hashtable generateAddCollectParams(Context context, String classId, String token) {
		Hashtable htable = new Hashtable();
		htable.put("user_agent", DeviceInfo.getUserAgent(context));
		htable.put("token", token);
		htable.put("class_id", classId);
		htable.put("time_stamp", "");

		Hashtable root = new Hashtable();
		root.put("action", Constant.ACTION_LESSON_ADD_COLLECTION);
		root.put("data", htable);
		return root;
	}

	/**
	 * 生成取消收藏课程请求参数
	 * @param context
	 * @param classId
	 * @param token
	 * @return
	 */
	public static String generateCancleCollectParams(Context context, String classId, String token){
		if(TextUtils.isEmpty(classId) || TextUtils.isEmpty(token)){
			return null;
		}
		try{
			JSONArray classIdArray = new JSONArray();
			classIdArray.put(classId);

			JSONObject dataObject = new JSONObject();
			dataObject.put("user_agent", DeviceInfo.getUserAgent(context));
			dataObject.put("token", token);
			dataObject.put("class_id", classIdArray);
			dataObject.put("time_stamp", "");

			JSONObject rootObject = new JSONObject();
			rootObject.put("action", Constant.ACTION_LESSON_CANCEL_COLLECTION);
			rootObject.put("data", dataObject);
			return rootObject.toString();
		}catch (Exception e){
			LogUtil.error(TAG,e);
		}
		return null;
	}

	/**
	 * 发布公告接口
	 * @param groupId
	 * @param content
     * @return
     */
	public static Hashtable  generatePublicBulletinParams(String groupId,String content){
		Hashtable hashtable = new Hashtable();
		hashtable.put("group_id",groupId);
		hashtable.put("bulletin",content);
		return hashtable;
	}

	/**
	 * 删除公告接口
	 * @param bulletin_id
	 * @return
     */
	public static Hashtable  generateDeletedBulletinParams(int bulletin_id) {
		Hashtable hashtable = new Hashtable();
		hashtable.put("bulletinid", bulletin_id);
		return hashtable;
	}

	public static Hashtable generateExperienceClassIndexParams(String classId){
		if(TextUtils.isEmpty(classId)){
			return null;
		}
		Hashtable root = null;
		try{
			root = new Hashtable();
			root.put("class_id", Integer.parseInt(classId));
		}catch (Exception e){
			LogUtil.error(TAG,e);
		}
		return root;
	}

	/**
	 * 获取学习报告
	 *
	 * @param url  url
	 * @param code code
	 * @return 学习报告
	 */
	public static String generateStudyReport(String url, String code) {
		//http://api2.class.hujiang.com/mobile/4.0/class/ClassReport?classid=
		return url + Constant.GET_CLASS_REPORT + "?classid=" + code;
	}


	/**
	 * 学习记录列表
	 * @param url
	 * @param code
	 * @return
	 */
	public static String generateStudyReportList(String url, String code) {
		return url + Constant.GET_STUDY_REPORT_LIST + "?StartTime=" + code;
	}


	/**
	 * 体验课列表
	 * @param url
	 * @return
	 */
	public static String generateGetAnonymousClassInfoListParams(String url) {
		return url + Constant.ACTION_GET_ANONYMOUS_CLASSINFO_LIST+"?pageSize=100";
	}

	/**
	 * 生成待做任务信息接口url
	 * @param classId
	 * @return
	 */
	public static String generateGetToDoTaskInfoUrl(String classId) {
//		return String.format(AppConfig.HOST_URL_FOR_4+Constant.GET_TO_DO_TASK_INFO,classId);
		return String.format(AppConfig.LEARNING_SYSTEM_GET_TO_DO_TASKINFO_URL,classId);
	}


	/**
	 * 学习提醒数据
	 * @param url
	 * @return
	 */
	public static String generateStudyRemindData(String url) {
		return url + Constant.GET_MOBILECOMMON_STUDYREMIND;
	}

	/**
	 * 辞书同步post数据
	 * @return
     */
	public static Hashtable generateCishuSyncData(String classId, String taskId, String taskKey) {
		Hashtable root = new Hashtable();
		root.put("ClassId", classId);
		root.put("TaskId", taskId);
		root.put("TaskKey", taskKey);
		return root;
	}

	/**
	 * 得到获取课件信息的post的数据
	 * @param classId
	 * @param lessonIdList
     * @return
     */
	public static String generateOCSItemData(String classId, List<String> lessonIdList){
		if(TextUtils.isEmpty(classId)){
			return null;
		}
		try{
			JSONObject object = new JSONObject();
			object.put("classId",classId);
			if(lessonIdList != null && lessonIdList.size() > 0){
				JSONArray array = new JSONArray();
				for(String id : lessonIdList){
					array.put(id);
				}
				object.put("lessonIds",array);
			}
			return object.toString();
		}catch (Exception e){
			LogUtil.error(TAG,e);
		}
		return null;
	}

	/**
	 * 同步学习系统班前测状态
	 * @param classId
	 * @return
     */
	public static String generateSyncClassBreTestStatusData(String classId){
		if(TextUtils.isEmpty(classId)){
			return null;
		}
		try{
			JSONObject object = new JSONObject();
			object.put("classId",classId);
			return object.toString();
		}catch (Exception e){
			LogUtil.error(TAG,e);
		}
		return null;
	}

	/**
	 * 学习系统班提交任务
	 * @param userId
	 * @param classId
     * @return
     */
	public static String generateSubmitClassTaskData(String userId, String classId){
		LearningSystemTaskBean taskBean = LearningSystemBusiness.getLearningSystemClassTask(userId, classId);
		if(taskBean == null || taskBean.getTasks() == null || taskBean.getTasks().size() == 0){
			return null;
		}
		List<String> sectionIdList = new ArrayList<>();
		for(LearningSystemBaseNodeBean baseNodeBean : taskBean.getTasks()){
			if(baseNodeBean instanceof LearningSystemSectionBean){
				sectionIdList.add(((LearningSystemSectionBean)baseNodeBean).getSectionId());
			}
		}
		if(sectionIdList == null || sectionIdList.size() == 0){
			return null;
		}
		LearningSystemClassTaskSubmitPostDataModel model = new LearningSystemClassTaskSubmitPostDataModel();
		model.setClassId(classId);
		model.setLessonIds(sectionIdList);
		return GsonUtil.objectToJson(model);
	}

	/**
	 * 课节条目状态同步
	 * @param classId
	 * @param contentId
	 * @param packageType
	 * @param taskId
	 * @param taskKey
	 * @param taskType
     * @return
     */
	public static String generateSyncClassTaskData(String classId, String contentId, String packageType, String taskId, String taskKey, String taskType){
		LearningSystemClassTaskSyncPostDataModel.LearningSystemClassTaskSyncItem syncItem = new LearningSystemClassTaskSyncPostDataModel.LearningSystemClassTaskSyncItem();
		syncItem.setContentId(contentId);
		syncItem.setPackageType(packageType);
		syncItem.setTaskId(taskId);
		syncItem.setTaskKey(taskKey);
		syncItem.setTaskType(taskType);

		List<LearningSystemClassTaskSyncPostDataModel.LearningSystemClassTaskSyncItem> syncItemList = new ArrayList<>();
		syncItemList.add(syncItem);

		LearningSystemClassTaskSyncPostDataModel model = new LearningSystemClassTaskSyncPostDataModel();
		model.setClassId(classId);
		model.setTaskInfos(syncItemList);

		return GsonUtil.objectToJson(model);
	}
}
