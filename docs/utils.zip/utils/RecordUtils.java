package com.hujiang.hjclass.utils;

import java.util.Date;

import android.content.Context;
import android.content.SharedPreferences;

import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.util.DateUtil;


/**
 * Created by Gavin on 13-11-13.
 * 统计每次请求刷新列表的时间
 *
 *
 * requestType 见 Constant.java  中的 ACTION_**
 *  如： public static final String ACTION_USER_MESSAGE = "user_message";
 *       public static final String ACTION_PUNCH = "punch";
 *       ......
 */
public class RecordUtils {

    private static final String PREFERNECE_REQUEST_RECORD_FILE = "PREFERNECE_REQUEST_RECORD_FILE";

    private static final String APP_REQUEST = "APP_REQUEST";

    private static final long REQUEST_DISTANCE = 60;

    /**
     * 清除请求的记录，保证请求必须刷新
     * @param context
     * @param requestType
     */
    public static void clearRequestRecord(Context context, String requestType, int pageNo, String appendKey) {
        String requestKey = getUserAppRequestKey(context, requestType, pageNo, appendKey);
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERNECE_REQUEST_RECORD_FILE,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(requestKey, "");
        editor.commit();
    }

    /**
     * 请求是否需要刷新
     * @param context
     * @param requestType
     * @return
     */
    public static boolean is5MinsNeedReflash(Context context, String requestType, int pageNo, String appendKey) {
        String request = getRequestRecord(context, requestType, pageNo, appendKey);
//        DebugUtils.println(requestType + "_" + appendKey + " last_time " + request);
        if (request.equals("")) {
            return true;
        }

        try {
            long minutes = Math.abs(DateUtil.getDifferenceMinutes(request, new Date()));
            if (minutes >= 5)
                return true;
            else
                return false;
        } catch (Exception e) {
            e.printStackTrace();
            //出错的话确定要刷新
        }
        return true;
    }

    /**
     * 是否需要刷新文件
     * @param context
     * @param requestType
     * @param pageNo
     * @param appendKey
     * @param distance minutes
     * @return
     */
    public static boolean isNeedReflash(Context context, String requestType, int pageNo, String appendKey, long distance) {
        String request = getRequestRecord(context, requestType, pageNo, appendKey);
//        DebugUtils.println(requestType + "_" + appendKey + " last_time " + request);
        if (request.equals("")) {
            return true;
        }

        try {
            long minutes = Math.abs(DateUtil.getDifferenceMinutes(request, new Date()));
            if (minutes >= distance)
                return true;
            else
                return false;
        } catch (Exception e) {
            e.printStackTrace();
            //出错的话确定要刷新
        }
        return true;
    }


    /**
     * 请求是否需要刷新
     * @param context
     * @param requestType
     * @return
     */
    public static boolean isNeedReflash(Context context, String requestType, int pageNo, String appendKey) {
        return isNeedReflash(context, requestType, pageNo, appendKey, REQUEST_DISTANCE);
//        String request = getRequestRecord(context, requestType, pageNo, appendKey);
//        DebugUtils.println(requestType + "_" + appendKey + " last_time " + request);
//        if (request.equals("")) {
//            return true;
//        }
//
//        try {
//            long minutes = Math.abs(DateUtil.getDifferenceMinutes(request, new Date()));
//            if (minutes >= REQUEST_DISTANCE)
//                return true;
//            else
//                return false;
//        } catch (Exception e) {
//            e.printStackTrace();
//            //出错的话确定要刷新
//        }
//        return true;
    }



    /**
     * 取得用户的访问记录
     *
     * @param context
     * @return
     */
    public static String getRequestRecord(Context context, String requestType, int pageNo, String appendKey) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERNECE_REQUEST_RECORD_FILE,
                Context.MODE_PRIVATE);
        String requestKey = getUserAppRequestKey(context, requestType, pageNo, appendKey);
        String requestValue = sharedPreferences.getString(requestKey, "");
//        DebugUtils.println(punchKey + " request key " + requestValue);
        return requestValue;
    }


    /**
     * 保存某个用户的某次请求的时间
     * @param context
     * @param requestType
     * appendKey 统一个请求可能包含不同参数的数据
     * @return
     */
    public static boolean saveRequestRecord(Context context, String requestType, int pageNo, String appendKey) {

        String requestKey = getUserAppRequestKey(context, requestType, pageNo, appendKey);
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERNECE_REQUEST_RECORD_FILE,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(requestKey, DateUtil.getNowDateTimeStringEn2());
        editor.commit();

        return true;
    }

    /**
     * 用户请求KEY
     * appendKey 统一个请求可能包含不同参数的数据
     * @param context
     * @return
     */
    private static String getUserAppRequestKey(Context context, String requestType, int pageNo, String appendKey) {
        String userID = LoginUtils.getUserId(context);
        return APP_REQUEST + "_" + userID + "_" + requestType + "_" + pageNo + "_" + appendKey;
    }

    //强制更新
    public static void setForceRefresh(Context context, String requestType, int pageNo, String appendKey) {
        String requestKey = getUserAppRequestKey(context, requestType, pageNo, appendKey);
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERNECE_REQUEST_RECORD_FILE,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(requestKey, DateUtil.getDateTimeString(new Date((2000 - 1900), 12, (12))));
        editor.commit();
    }
}
