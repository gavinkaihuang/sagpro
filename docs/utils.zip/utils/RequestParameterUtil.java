package com.hujiang.hjclass.utils;

import com.hujiang.hjclass.Constant.RequestParameterConstant;
import com.hujiang.hjclass.Constant.StatusConstant;
import com.hujiang.hjclass.model.LearningSystemItemBean;
import com.hujiang.hjclass.model.MainBottomTabResEntity;

import java.util.HashMap;
import java.util.List;

/**
 * 网络请求参数处理类
 * Created by lvhuacheng on 2016/8/10.
 */
public class RequestParameterUtil {

    private static HashMap<String,Object> createEmptyMap(){
        return new HashMap<>();
    }

    private static void addLoadModeParameter(HashMap<String,Object> map,int loadMode){
        if(map == null){
            return;
        }
        map.put(RequestParameterConstant.LOAD_MODE,loadMode);
    }

    /**
     * 创建刷新模式参数
     * @param loadMode
     * @return
     */
    public static HashMap<String,Object> createRequestParameterOfPullMode(int loadMode){
        HashMap<String,Object> map = createEmptyMap();
        addLoadModeParameter(map,loadMode);
        return map;
    }

    /**
     * 创建"同步消息状态"参数集合
     * @param messageId
     * @return
     */
    public static HashMap<String,Object> createRequestParameterOfSyncMessageStatus(String messageId){
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.MESSAGE_ID,messageId);
        return map;
    }

    /**
     * 创建"获取试卷"参数集合
     * @param paperId
     * @return
     */
    public static HashMap<String,Object> createRequestParameterOfQuestionPaper(String paperId,boolean show_answer_result){
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.PAPER_ID,paperId);
        map.put(RequestParameterConstant.SHOW_ANSWER_RESULT,show_answer_result);
        return map;
    }

    /**
     * 创建"同步辞书数据"参数集合
     * @param classId
     * @param taskId
     * @return
     */
    public static HashMap<String,Object> createSyncCishuDataRequestData(String classId, String taskId, String taskKey){
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.CLASS_ID, classId);
        map.put(RequestParameterConstant.TASK_ID, taskId);
        map.put(RequestParameterConstant.TASK_KEY, taskKey);
        return map;
    }

    /**
     * 创建"设备解绑"参数集合
     * @param token
     * @return
     */
    public static HashMap<String,Object> createUnbindDeviceDataRequestData(String token){
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.TOKEN, token);
        return map;
    }

    /**
     * 创建"下载首页tab图片"参数集合
     * @param beans
     * @return
     */
    public static HashMap<String,Object> createMainBottomTabPicsRequestData(List<MainBottomTabResEntity.MainBottomTabResBean> beans){
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.MAIN_BOTTOM_TAB_LIST, beans);
        return map;
    }

    /**
     * 创建"班级列表请求"参数集合
     * @param loadMode 加载模式
     * @param requestServer 是否请求服务器
     * @param classKind 类型
     * @param classListOrder 排序
     * @return
     */
    public static HashMap<String,Object> createGetClassListDataRequestData(int loadMode, boolean requestServer, int classKind, int classListOrder){
        HashMap<String,Object> map = createEmptyMap();
        addLoadModeParameter(map,loadMode);
        map.put(RequestParameterConstant.REQUEST_SERVER,requestServer);
        map.put(RequestParameterConstant.CLASS_KIND, classKind);
        map.put(RequestParameterConstant.CLASS_LIST_ORDER, classListOrder);
        return map;
    }

    /**
     * 创建"学习报告请求"参数集合
     * @param code code
     * @return
     */
    public static HashMap<String,Object> createGetStudyReportDataRequestData(String code) {
        HashMap<String, Object> map = createEmptyMap();
        map.put(RequestParameterConstant.STUDY_REPORT_CODE, code);
        return map;
    }
    /**
     * 创建上传用户选择的标签参数集合
     * @param params
     * @return
     */
    public static HashMap<String,Object> createUserSelectedLabelsRequestData(Object params){
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.TAG_IDS, params);
        return map;
    }

    /**
     * 学习卡片数据请求参数
     * @param cardId
     * @return
     */
    public static HashMap<String,Object> createStudyCardRequestData(String cardId){
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.CARD_ID, cardId);
        return map;
    }

    /***
     * 班级首页学习系统班数据请求参数
     * @param classId
     * @return
     */
    public static HashMap<String,Object> createRequestLearningSystemClassIndexData(String classId, String action) {
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.CLASS_ID, classId);
        map.put(RequestParameterConstant.TASK_ACTION_ID, action);
        map.put(RequestParameterConstant.NEED_RESET_INTENSIVE_PACKAGE_NEW_FLAG, true);
        map.put(RequestParameterConstant.LEARNING_SYSTEM_DATA_TYPE, StatusConstant.LEARNING_SYSTEM_DATA_TYPE_TASK);
        return map;
    }

    /**
     * 学习系统新课程表数据请求参数
     * @param loadMode
     * @param classId
     * @return
     */
    public static HashMap<String,Object> createRequestLearningSystemLessonListData(int loadMode, String classId) {
        HashMap<String, Object> map = createEmptyMap();
        map.put(RequestParameterConstant.CLASS_ID, classId);
        map.put(RequestParameterConstant.LEARNING_SYSTEM_DATA_TYPE, StatusConstant.LEARNING_SYSTEM_DATA_TYPE_LESSON);
        addLoadModeParameter(map,loadMode);
        return map;
    }
    /***
     * 班级首页学习系统班任务提交参数
     * @param classId
     * @return
     */
    public static HashMap<String,Object> createSubmitLearningSystemClassIndexTaskData(String classId) {
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.CLASS_ID, classId);
        return map;
    }

    /***
     * 获取班级首页学习系统班任务参数
     * @param classId
     * @return
     */
    public static HashMap<String,Object> createGetLearningSystemClassIndexTaskData(String classId) {
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.CLASS_ID, classId);
        map.put(RequestParameterConstant.NEED_RESET_INTENSIVE_PACKAGE_NEW_FLAG, false);
        map.put(RequestParameterConstant.TASK_ACTION_ID, StatusConstant.LEARNING_SYSTEM_TASK_GET);
        map.put(RequestParameterConstant.LEARNING_SYSTEM_DATA_TYPE, StatusConstant.LEARNING_SYSTEM_DATA_TYPE_TASK);
        return map;
    }


    /**
     * 获取试卷的跳转link
     * @param bean
     * @return
     */
    public static HashMap<String,Object> createGetPaperLink(LearningSystemItemBean bean) {
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.SECTION_ITEM_BEAN, bean);
        return map;
    }

    /**
     * 同步学测状态
     * @param classId
     * @return
     */
    public static HashMap<String,Object> createSyncLearningSystemPreTestStatus(String classId) {
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.CLASS_ID, classId);
        return map;
    }

    /**
     * 班级问答数据请求参数
     * @param classId
     * @return
     */
    public static HashMap<String,Object> createClassWendaRequestData(String classId){
        HashMap<String,Object> map = createEmptyMap();
        map.put(RequestParameterConstant.CLASS_ID, classId);
        return map;
    }
}
