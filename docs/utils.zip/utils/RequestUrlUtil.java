package com.hujiang.hjclass.utils;

import android.text.TextUtils;

import com.hujiang.hjclass.AppConfig;
import com.hujiang.hjclass.AppHost;
import com.hujiang.hjclass.Constant.RequestActionConstant;

/**
 * 请求url创建类
 * Created by lvhuacheng on 2016/8/10.
 */
public class RequestUrlUtil {

    /**
     * 创建"同步消息状态"请求url
     * @param messageId
     * @return
     */
    public static String createSyncMessageStatusURL(String messageId){
        if(TextUtils.isEmpty(messageId)){
            return null;
        }
        StringBuffer urlSB = new StringBuffer();
        urlSB.append(AppConfig.HOST_URL_FOR_4);
        urlSB.append(RequestActionConstant.ACTION_SYNC_MESSAGE_STATUS);
        urlSB.append("?id=").append(messageId);
        return urlSB.toString();
    }

    /**
     * 创建"获取题库试卷"请求URL
     * @param paperId
     * @param questionIdStr
     * @return
     */
    public static String createQuestionPaperURL(String paperId,String questionIdStr){
        if(TextUtils.isEmpty(questionIdStr)){
            return AppConfig.QUESTION_LIBRARY_PAPER_URL+paperId;
        }
        return AppConfig.QUESTION_LIBRARY_PAPER_URL+paperId+questionIdStr;
    }

    /**
     * 创建"获取题库试卷作答结果"请求URL
     * @param paperId
     * @return
     */
    public static String createQuestionPaperAnswerResultGetURL(String paperId){
        return AppConfig.QUESTION_LIBRARY_GET_REPORT_URL+paperId;
    }

    /**
     * 创建"提交题库试卷作答结果"请求URL
     * @return
     */
    public static String createQuestionPaperAnswerResultPostURL(){
        return AppConfig.QUESTION_LIBRARY_POST_REPORT_URL;
    }

    /**
     * 创建辞书同步url
     * @return
     */
    public static String generateStudyRemindDataUrl() {
        return AppConfig.LEARNING_SYSTEM_SYNC_CISHU_DATA_URL;
    }

    /**
     * 创建获取收藏列表请求地址
     * @param pageIndex 页码
     * @param pageSize  每页数量,为0则不分页
     * @return
     */
    public static String createClassCollectURL(int pageIndex, int pageSize){
        return AppConfig.HOST_URL_FOR_4 + RequestActionConstant.ACTION_CLASS_COLLECT + "?index="+pageIndex+"&pageSize="+pageSize;
    }

    /**
     * 创建获取学习框架数据请求地址
     * @return
     */
    public static String createStudyStructureURL(){
        return AppHost.HJAPI_HOST + RequestActionConstant.ACTION_STUDY_STRUCTURE;
    }

    /**
     * 创建获取用户兴趣标签数据请求地址
     * @return
     */
    public static String createUserLabelURL() {
        return AppHost.HJAPI_HOST + RequestActionConstant.ACTION_USER_LABEL;
    }

    /**
     * 创建获取首页任务卡片请求地址
     * @return
     */
    public static String createGetTaskCardURL(){
        return AppHost.HJAPI_HOST + RequestActionConstant.ACTION_GET_TASK_CARD;
    }

    /**
     * 创建获取首页文章、导购卡片请求地址
     * @return
     */
    public static String createGetArticleCardURL(){
        return AppHost.HJAPI_HOST + RequestActionConstant.ACTION_GET_ARTICLE_CARD;
    }
    /**
     * 创建获取首页导购卡片请求地址
     * @return
     */
    public static String createGetShoppingGuideCardURL(){
        return AppHost.HJAPI_HOST + RequestActionConstant.ACTION_GET_SHOPPING_GUIDE_CARD;
    }

    /**
     * 创建获取首页问答卡片请求地址
     * @return
     */
    public static String createGetQACardURL() {
        return AppHost.HJAPI_HOST + RequestActionConstant.ACTION_GET_QA_CARD;
    }
    /**
     * 创建获取所有标签的url
     * @return
     */
    public static String createTagsURL(){
        return  AppHost.HJAPI_HOST + RequestActionConstant.ACTION_V1_TAGS;
    }

    /**
     * 创建上传用户选择的所有标签的url
     * @return
     */
    public static String postUserSelectedURL(){
        return  AppHost.HJAPI_HOST + RequestActionConstant.ACTION_V1_TAGS_SET;
    }

    /**
     * 创建获取小4块／长8块／运营位url
     * @return
     */
    public static String getConfigADURL(String type){
        return  AppHost.HJAPI_HOST + RequestActionConstant.ACTION_V1_CONFIG_AD +"?cardId="+type;
    }

    /**
     * 创建学习系统班前测数据url
     * @param classId
     * @return
     */
    public static String createLearningSystemBreTestURL(String classId){
        return  AppHost.HJAPI_HOST + RequestActionConstant.ACTION_LEARNING_SYSTEM_BRETEST +"?classId="+classId;
    }

    /**
     * 创建同步学习系统班前测跳过状态url
     * @param classId
     * @return
     */
    public static String createSyncLearningSystemBreTestSkipStatusURL(String classId){
        return  AppHost.HJAPI_HOST + RequestActionConstant.ACTION_SYNC_LEARNING_SYSTEM_BRETEST_SKIP_STATUS +"?classId="+classId;
    }

    /**
     * 创建学习系统班获取任务url
     * @param classId
     * @param actionId
     * @return
     */
    public static String createLearningSystemGetTaskURL(String classId, String actionId){
        return  AppHost.HJAPI_HOST + RequestActionConstant.ACTION_LEARNING_SYSTEM_GET_TASK +"?classId="+classId+"&actionId="+actionId;
    }

    /**
     * 创建学习系统班课表url
     * @param classId
     * @return
     */
    public static String createLearningSystemLessonURL(String classId){
        return  AppHost.HJAPI_HOST + RequestActionConstant.ACTION_LEARNING_SYSTEM_LESSON +"?classId="+classId;
    }

    /**
     * 创建学习系统班提交任务url
     * @return
     */
    public static String createLearningSystemSubmitTaskURL(){
        return  AppHost.HJAPI_HOST + RequestActionConstant.ACTION_LEARNING_SYSTEM_SUBMIT_TASK;
    }

    /**
     * 创建学习系统班任务完成信息url
     * @param classId
     * @return
     */
    public static String createLearningSystemTaskCompleteURL(String classId){
        return  AppHost.HJAPI_HOST + RequestActionConstant.ACTION_LEARNING_SYSTEM_TASK_COMPLETE +"?classId="+classId;
    }

    /**
     * 创建学习系统班提交任务url
     * @return
     */
    public static String createLearningSystemSyncTaskURL(){
        return  AppHost.HJAPI_HOST + RequestActionConstant.ACTION_LEARNING_SYSTEM_TASK_SYNC;
    }

    /**
     * 创建课件获取地址
     * @return
     */
    public static String createOCSItemURL(){
        return AppConfig.HOST_URL_FOR_4 + RequestActionConstant.ACTION_OCS_ITEM;
    }

    /**
     * 创建学习系统班获取试卷url
     * @param classId
     * @param contentId
     * @return
     */
    public static String createLearningSystemGetPaperURL(String classId, String contentId, String sectionId, String packageType){
        return  AppHost.HJAPI_HOST + RequestActionConstant.ACTION_LEARNING_SYSTEM_GET_PAPER +"?classId="+classId+"&contentId="+contentId+"&lessonId="+sectionId+"&packageType="+packageType;
    }

    /**
     * 创建获取班级扩展功能地址
     * @return
     */
    public static String createClassExtendModuleURL(String classId){
        return AppHost.HJAPI_HOST + RequestActionConstant.ACTION_CLASS_EXTEND_MODULE + classId;
    }
}
