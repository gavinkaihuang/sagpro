package com.hujiang.hjclass.utils;

import java.io.File;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;

import android.content.Context;
import android.os.Environment;
import android.os.StatFs;
import android.os.storage.StorageManager;
import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.R;
import com.hujiang.hjclass.adapter.model.SDcardInfo;

/**
 * Created by Gavin on 13-11-21.
 */
public class SDCardUtils {

    @SuppressWarnings("unused")
    private static final String SDCARD_ROOT = Environment.getExternalStorageDirectory()
            .getAbsolutePath() + "/";

    private static final long LOW_STORAGE_THRESHOLD = 1024 * 1024 * 10;


    public static boolean isSdCardWrittenable() {

        if (android.os.Environment.getExternalStorageState().equals(
                android.os.Environment.MEDIA_MOUNTED)) {
            return true;
        }
        return false;
    }

    public static long getAvailableStorage() {
        String storageDirectory = null;
        storageDirectory = Environment.getExternalStorageDirectory().toString();

        try {
            StatFs stat = new StatFs(storageDirectory);
            long avaliableSize = ((long) stat.getAvailableBlocks() * (long) stat.getBlockSize());
            return avaliableSize;
        } catch (RuntimeException ex) {
            return 0;
        }
    }

    public static long getTotalStorage() {
        String storageDirectory = null;
        storageDirectory = Environment.getExternalStorageDirectory().toString();

        try {
            StatFs stat = new StatFs(storageDirectory);
            long avaliableSize = ((long) stat.getBlockCount() * (long) stat.getBlockSize());
            return avaliableSize;
        } catch (RuntimeException ex) {
            return 0;
        }
    }

    public static boolean checkAvailableStorage() {

        if (getAvailableStorage() < LOW_STORAGE_THRESHOLD) {
            return false;
        }

        return true;
    }

    public static boolean isSDCardPresent() {

        return Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
    }

    /**
     * 取得可用空间比例
     *
     * @return
     */
    public static int getSDCardPercent() {
        try {
            int value = (int) (getAvailableStorage() * 100 / getTotalStorage());
            return value;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static String getPromptSize(long size) {

        if (size / (1024 * 1024 * 1024) > 0) {
            float tmpSize = (float) (size) / (float) (1024 * 1024 * 1024);
            DecimalFormat df = new DecimalFormat("#.##");
            return "" + df.format(tmpSize) + "GB";
        } else if (size / (1024 * 1024) > 0) {
            float tmpSize = (float) (size) / (float) (1024 * 1024);
            DecimalFormat df = new DecimalFormat("#.##");
            return "" + df.format(tmpSize) + "MB";
        } else if (size / 1024 > 0) {
            return "" + (size / (1024)) + "KB";
        } else
            return "" + size + "B";

//        if (size / (1024 * 1024) > 0) {
//            float tmpSize = (float) (size) / (float) (1024 * 1024);
//            DecimalFormat df = new DecimalFormat("#.##");
//            return "" + df.format(tmpSize) + "MB";
//        } else if (size / 1024 > 0) {
//            return "" + (size / (1024)) + "KB";
//        } else
//            return "" + size + "B";
    }

    /**
     * 加载本机SD卡列表
     */
    public static ArrayList<SDcardInfo> loadSdcardList(Context context) {
        ArrayList<SDcardInfo> mSDcardInfoList =new ArrayList<SDcardInfo>() ;
        if (Integer.valueOf(android.os.Build.VERSION.SDK_INT) < 11) { // 如果失败则是3.0以下系统
            mSDcardInfoList.add(getSDcardInfo(context.getString(R.string.setting_sdcard_phone), Environment.getExternalStorageDirectory().getAbsolutePath()));
            return mSDcardInfoList;
        }
        try {
            /** 4.4以及以上的算法 ***/
            if (Integer.valueOf(android.os.Build.VERSION.SDK_INT) > 18) {
                File[] files = getSDCardFiles();
                if (files == null) {
                    mSDcardInfoList.add(getSDcardInfo(context.getString(R.string.setting_sdcard_phone), Environment.getExternalStorageDirectory().getAbsolutePath()));
                    return mSDcardInfoList;
                }
                String name = "";
                String path = "";
                for (int i = 0; i < files.length; i++) {
                    if (i == 0) {
                        name = context.getString(R.string.setting_sdcard_phone);
                        path = Environment.getExternalStorageDirectory().getAbsolutePath();
                    } else if( files[i] instanceof File && checkSDCardAvailable(files[i].getPath())) {
                        name = context.getString(R.string.setting_sdcard_sd) + i;
                        path = files[i].getPath();
                    } else {
                        continue;
                    }
                    SDcardInfo tempSDcardInfo = getSDcardInfo(name, path);
                    // 根据容量来判断是否显示SD卡
                    if (tempSDcardInfo.capacity != 0) {
                        mSDcardInfoList.add(tempSDcardInfo);
                    }
                }
                return mSDcardInfoList;
            }
            /******* 大于11小于19号版本的算法 *********/
            String[] paths = getSDCardPaths();
            for (int i = 0; i < paths.length; i++) {
                String name;
                if (i == 0) {
                    name = context.getString(R.string.setting_sdcard_phone);
                } else {
                    name = context.getString(R.string.setting_sdcard_sd) + i;
                }
                SDcardInfo tempSDcardInfo = getSDcardInfo(name, paths[i]);
                // 根据容量来判断是否显示SD卡
                if (tempSDcardInfo.capacity != 0) {
                    mSDcardInfoList.add(tempSDcardInfo);
                }
            }
            return mSDcardInfoList;
        } catch (Exception e) {
            e.printStackTrace();
            mSDcardInfoList.add(getSDcardInfo(context.getString(R.string.setting_sdcard_phone), Environment.getExternalStorageDirectory().getAbsolutePath()));
        }
        return mSDcardInfoList;

    }

    public static SDcardInfo getSDcardInfo(String sdcardName, String path) {
        SDcardInfo tempSDcardInfo = new SDcardInfo();
        android.os.StatFs statfs = new android.os.StatFs(path);
        long nTotalBlocks = statfs.getBlockCount();
        // 获取SDCard上每个block的SIZE
        long nBlocSize = statfs.getBlockSize();
        // 获取可供程序使用的Block的数量mMountService
        long nAvailaBlock = statfs.getAvailableBlocks();
        // 获取剩下的所有Block的数量(包括预留的一般程序无法使用的块)
        long nFreeBlock = statfs.getFreeBlocks();
        // 计算SDCard 总容量大小MB
        long nSDTotalSize = nTotalBlocks * nBlocSize;
        tempSDcardInfo.capacity = nSDTotalSize;
        // 计算 SDCard 剩余大小MB
        long nSDFreeSize = nAvailaBlock * nBlocSize;
        tempSDcardInfo.availableCapacity = nSDFreeSize;
        tempSDcardInfo.name = sdcardName;
        tempSDcardInfo.path = path;
        double percentage = (((double) nSDFreeSize / (double) nSDTotalSize) * 100);
        tempSDcardInfo.percentage = 100 - ((int) percentage);
        return tempSDcardInfo;
    }

    /**
     * 获取SD卡路径
     * 大于11小于19号版本的算法
     * @return
     */
    public static String [] getSDCardPaths() {
        String[] paths = null;
        try {
//            StorageManager sm = (StorageManager) MainApplication.getContext().getSystemService(Context.STORAGE_SERVICE);
//              paths = (String[]) sm.getClass().getMethod("getVolumePaths", (Class<?>) null).invoke(sm, (Object) null);
//            paths = (String[]) sm.getClass().getMethod("getVolumePaths", null).invoke(sm, null);
//            return paths;

            StorageManager storageManager = (StorageManager) MainApplication.getContext().getSystemService(Context.STORAGE_SERVICE);
            Class<?>[] paramClasses = {};
            Method getVolumePathsMethod = StorageManager.class.getMethod("getVolumePaths", paramClasses);
            getVolumePathsMethod.setAccessible(true);
            Object[] params = {};
            Object invoke = getVolumePathsMethod.invoke(storageManager, params);
            return (String[])invoke;

        }catch (Exception e) {
            e.printStackTrace();
            paths = new String[] { Environment.getExternalStorageDirectory().getAbsolutePath() };
            return paths;
        }
    }

    /**
     * 获取SD卡路径
     * 大于等于19号版本的算法
     * @return
     */
    public static  File[] getSDCardFiles() {
        try {
            File[] files = MainApplication.getContext().getExternalFilesDirs(null);
            return files;
        }catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean checkSDCardAvailable(String sdCardPath){
        File file = null;
        try{
            sdCardPath += File.separator + System.currentTimeMillis()+".txt";
            file = new File(sdCardPath);
            if(file.exists() && file.canRead() && file.canWrite()){
                return true;
            }
            if(file.createNewFile()){
                return true;
            }
        }catch (Exception e){
            LogUtil.error("checkSDCardAvailable",e);
        }finally{
            if(file != null && file.exists()){
                file.delete();
            }
        }
        return false;
    }

    public static String showSizeTransformation(long size) {
        DecimalFormat df = new DecimalFormat("#.0");
        double tempsize = size / 1024 / 1024;
        if (tempsize > 1023) {
            tempsize = tempsize / 1024;
            return df.format(tempsize) + "GB";
        }
        return df.format(tempsize) + "MB";
    }
}
