package com.hujiang.hjclass.utils;

import com.hujiang.hjclass.Constant.StatusConstant;
import com.hujiang.hjclass.activity.SchemeActivity;

import java.io.File;

/**
 * Created by zhuyi on 16/12/26.
 */

public class SchemeUrlGenerateUtil {
    /**
     * 获取班级列表的schemeUrl
     * @return
     */
    public static String getClassListSchemeUrl(){
        return SchemeActivity.HJCLASS_URI_STRING + File.separator + SchemeActivity.PATH_MY_CLASS_LIST;
    }
    /**
     * 获取学习提醒闹钟的schemeUrl
     * @return
     */
    public static String getLearningRemindSchemeUrl(String classId){
        return SchemeActivity.HJCLASS_URI_STRING + File.separator + SchemeActivity.PATH_LEARNING_REMIND + File.separator + StatusConstant.REMIND_TYPE_LEARNING + File.separator + classId;
    }
    /**
     * 获取班级列表的schemeUrl
     * @return
     */
    public static String getClassIndexSchemeUrl(String classId){
        return SchemeActivity.HJCLASS_URI_STRING + File.separator + SchemeActivity.PATH_TASK_CLASS + File.separator + classId;
    }
}
