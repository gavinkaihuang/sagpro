package com.hujiang.hjclass.utils;

import android.text.TextUtils;

import com.hujiang.bi.utils.BIUtils;
import com.hujiang.common.net.HttpConnectionFactory;
import com.hujiang.framework.api.APIExecutor;
import com.hujiang.framework.api.model.NetworkResponse;
import com.hujiang.framework.api.request.APIGetRequest;
import com.hujiang.framework.api.request.APIPostRequest;
import com.hujiang.hjclass.AppConfig;
import com.hujiang.hjclass.Constant.CommonConstant;
import com.hujiang.hjclass.MainApplication;
import com.hujiang.hjclass.NetWorkConfig;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.util.AppPara;
import com.hujiang.util.CdnUtil;
import com.hujiang.util.DebugUtils;
import com.loopj.android.http.AsyncHttpClient;
import com.mato.sdk.proxy.Proxy;
import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.params.ConnRouteParams;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;

/**
 * 
 * @author gavinhuang
 * 
 */
public class ServerConnecter {

	private static final String TAG = "ServerConnecter";

	public static final String URL_ENCODE = "UTF-8";

	/**
	 * get请求
	 * @param url
	 * @return
	 */
	public static String requestByGet(String url) {
		long startTime = System.currentTimeMillis();
		NetworkResponse<String> response=new HJClassAPIExecutor()
				.syncExecute(getAPIGetRequest(url), String.class, null)
				.getNetworkResponse();

		long endTime = System.currentTimeMillis();
		BIUtils.httpResponseLog(MainApplication.getContext(), "get:" + url, (endTime - startTime));
		LogUtil.error(TAG, "requestByGet  url  : "+url);
		if(response!=null && response.mData!=null) {
			LogUtil.error(TAG, "requestByGet  response  data : "+response.mData);
			return response.mData;
		}
		LogUtil.error(TAG, "requestByGet  response  data  is null ! ");
		return null;
	}


	/**
	 * post 请求
	 * @param url
	 * @param contentBody
	 * @return
	 */
	public static String postContentBody(String url, String contentBody) {
		return postContentBody(url, contentBody, null);
	}

	/**
	 * post 请求
	 * @param url
	 * @param contentBody
	 * @param cookies
	 * @return
	 */
	public static String postContentBody(String url, String contentBody, String cookies) {
		APIPostRequest apiPostRequest = getAPIPostRequest(url, contentBody);
		if(!TextUtils.isEmpty(cookies)) {
			apiPostRequest.addHeader("Cookie", cookies);
		}

		NetworkResponse<String> response = new HJClassAPIExecutor()
				.syncExecute(apiPostRequest, String.class, null)
				.getNetworkResponse();
		if (response != null && response.mData != null) {
			return response.mData;
		}
		return null;
	}

	/**
	 *替换post请求中的默认token
	 * @param url
	 * @param contentBody
	 * @param token
	 * @return
	 */
	public static String postContentBodyByToken(String url, String contentBody, String token) {
		APIPostRequest apiPostRequest = getAPIPostRequest(url, contentBody);
		if(!TextUtils.isEmpty(token)) {
			apiPostRequest.addHeader("Access-Token", token);
		}
		NetworkResponse<String> response = new HJClassAPIExecutor()
				.syncExecute(apiPostRequest, String.class, null)
				.getNetworkResponse();
		if (response != null && response.mData != null) {
			return response.mData;
		}
		return null;
	}

	/**
	 * 暂时自己写参数，是否考虑用JSon lib 暂时不考虑
	 * 
	 * @param htable
	 *            key : value value 可以是 Integer, String 简单数据对象 也可以是Hashtable, 这时key是 list
	 * @return
	 */
	public static String generateJSonParams(Hashtable htable) {
		if (htable == null) {
			return "{}";
		}

		boolean alreadyAddParams = false;
		StringBuffer sb = new StringBuffer();
		sb.append("{");
		Enumeration eeKeys = htable.keys();
		while (eeKeys.hasMoreElements()) {
			if (alreadyAddParams) {
				sb.append(",");
			}
			String key = (String) eeKeys.nextElement();
			Object value = htable.get(key);
			if (value instanceof Hashtable) {
				sb.append("\"list\":[" + generateJSonParams((Hashtable) value) + "]");// 如果参数是List
			} else {
				// if (value instanceof String) {
				String sValue = formatValue(value);
				if (sValue.startsWith("[") && sValue.endsWith("]")) {
					// aleady is json array
					sb.append("\"" + key + "\":" + "" + formatValue(value) + "");
				} else {
					sb.append("\"" + key + "\":" + "\"" + formatValue(value) + "\"");
				}
				// }

			}
			alreadyAddParams = true;// 已经添加过参数，下次会添加 ','
		}

		sb.append("}");
		return sb.toString();
	}

	/**
	 * 将value作为转移符编码
	 * 
	 * @param
	 * @return
	 */
	private static String formatValue(Object obj) {
		String value = "" + obj;
		value = value.replaceAll("\"", "\\\"");
		return value;
	}

	public static String generateClassJSonParams(Hashtable htable) {
		if (htable == null) {
			return "{}";
		}
		try {
			// 增加渠道参数
			if (htable.containsKey("data")) {
				Object obj = htable.get("data");
				if (obj instanceof Hashtable) {
					Hashtable tempHtable = (Hashtable) htable.get("data");
					tempHtable.put("channel", getQudaoKey());
					tempHtable.put("app_info", DeviceInfo.getHeadUserAgent());
				}
			}
		} catch (Exception e) {
		}
		boolean alreadyAddParams = false;
		StringBuffer sb = new StringBuffer();
		sb.append("{");
		Enumeration eeKeys = htable.keys();
		while (eeKeys.hasMoreElements()) {
			if (alreadyAddParams) {
				sb.append(",");
			}
			String key = (String) eeKeys.nextElement();
			Object value = htable.get(key);
			if (value instanceof Hashtable) {
				sb.append("\"data\":" + generateJSonParams((Hashtable) value) + "");
			} else {
				// if (value instanceof String) {
				String sValue = formatValue(value);
				if (sValue.startsWith("{") && sValue.endsWith("}")) {
					// aleady is json array
					sb.append("\"" + key + "\":" + "" + formatValue(value) + "");
				} else {
					sb.append("\"" + key + "\":" + "\"" + formatValue(value) + "\"");
				}
				// }

			}
			alreadyAddParams = true;// 已经添加过参数，下次会添加 ','
		}

		sb.append("}");

		DebugUtils.println("request data is " + sb.toString());
		return sb.toString();
	}

	/**
	 * @param
	 * @return
	 */
	public static String getQudaoKey() {
		String qudao = "";
		try {
			qudao = AppPara.getMetaData(MainApplication.getContext(), "UMENG_CHANNEL");
			qudao = qudao.replaceAll("\\{", "");
			qudao = qudao.replaceAll("\\}", "");
		} catch (Exception e) {
		}
		return qudao;
	}

	/** maa cdn 加速 */
	public static void maaAcceleration(HttpClient httpclient) {
		try {
			if (CdnUtil.isCdnOn(MainApplication.getContext())) {
				if (Proxy.getAddress() != null) {
					final HttpHost proxyHost = new HttpHost(Proxy.getAddress().getHost(), Proxy.getAddress().getPort());
					httpclient.getParams().setParameter(ConnRouteParams.DEFAULT_PROXY, proxyHost);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static HashMap<String, String> getHeader() {
		String userAgent = NetWorkConfig.getAPIHeadUserAgent(MainApplication.getContext());
		String accessToken = LoginUtils.getUserToken(MainApplication.getContext());
		String deviceId = NetWorkConfig.getDrviceID(MainApplication.getContext());
		HashMap<String, String> hs = new HashMap<String, String>();
		hs.put("User-Agent", userAgent);
		hs.put("Access-Token", accessToken);
		hs.put("Device-Id", deviceId);
		LogUtil.error(TAG, "User-Agent:" +userAgent);
		LogUtil.error(TAG,"Access-Token:" + accessToken);
		LogUtil.error(TAG,"Device-Id:" + deviceId);
		return hs;
	}


	private static class HJClassAPIExecutor extends APIExecutor{

		public static final int TIMEOUT = 60 * 1000;

		@Override
		protected AsyncHttpClient onCreateHttpClient(boolean isSycn) {
			AsyncHttpClient httpClient = HttpConnectionFactory.newHttpClientInstance(isSycn);
			httpClient.setTimeout(TIMEOUT);
			maaAcceleration(httpClient.getHttpClient());
			return httpClient;
		}
	}

	private static APIGetRequest getAPIGetRequest(String url){
		APIGetRequest apiGetRequest=new APIGetRequest(url,null);
		apiGetRequest.addHeader(getHeader());
		return apiGetRequest;
	}

	private static APIPostRequest getAPIPostRequest(String url, String contentBody){
		APIPostRequest apiPostRequest=new APIPostRequest(url,null);
		try {
			ByteArrayEntity baEntity = new ByteArrayEntity(contentBody.getBytes("UTF8"));
			baEntity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
			apiPostRequest.setContentType("application/json");
			apiPostRequest.setHttpEntity(baEntity);
		}catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		apiPostRequest.addHeader(getHeader());
		return apiPostRequest;
	}

	/**
	 * 下载文件并保存到filePath地址(如果下载并保存成功则返回该文件的完整路径,否则返回null)
	 *
	 * @param url
	 * @param filePath
	 * @return
	 */
	public static String requestNetFile(String url, String filePath) {
		if (TextUtils.isEmpty(url) || TextUtils.isEmpty(filePath)) {
			return null;
		}
		LogUtil.error(TAG,"download file url : "+url);
		File fileTemp = null;
		int nRead = 0;
		int totalRead = 0;
		byte[] readBuffer = null;
		InputStream inputStream = null;
		FileOutputStream outputStream = null;
		try {
			File netFile = new File(filePath);
			fileTemp = new File(filePath + CommonConstant.TEMP_NAME);//临时文件

			URL requestURL = new URL(url);
			HttpURLConnection httpConnection = (HttpURLConnection) requestURL.openConnection();
			httpConnection.setConnectTimeout(CommonConstant.CONNECTION_TIMEOUT);
			long fileLength = httpConnection.getContentLength();
			if (fileLength <= 0) {
				return null;
			}
			//存储空间不足
			if (fileLength > FileCacheUtils.getAvailableStore()) {
				return null;
			}
			readBuffer = new byte[8 * 1024];
			inputStream = httpConnection.getInputStream();
			outputStream = new FileOutputStream(fileTemp);
			while (true) {
				nRead = inputStream.read(readBuffer, 0, readBuffer.length);
				if (nRead == -1) {
					break;
				}
				outputStream.write(readBuffer, 0, nRead);
				totalRead += nRead;
			}
			if (totalRead == fileLength) {
				fileTemp.renameTo(netFile);
				LogUtil.error(TAG,"download file success  filePath : "+filePath);
				return filePath;
			}
		} catch (Exception e) {
			LogUtil.error(TAG, e);
		} finally {
			if (fileTemp != null && fileTemp.exists()) {
				fileTemp.delete();
			}
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					LogUtil.error(TAG, e);
				}
			}
			if (outputStream != null) {
				try {
					outputStream.close();
				} catch (IOException e) {
					LogUtil.error(TAG, e);
				}
			}
		}
		return null;
	}
}
