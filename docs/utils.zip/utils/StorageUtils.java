package com.hujiang.hjclass.utils;

import java.io.File;

import android.os.Environment;
import android.util.Log;

public class StorageUtils {

    public static boolean isExternalStorageWriteable() {
        boolean mExternalStorageAvailable;
        boolean mExternalStorageWriteable;
        String state = Environment.getExternalStorageState();

        if (Environment.MEDIA_MOUNTED.equals(state)) {
            // We can read and write the media
            mExternalStorageAvailable = true;
            mExternalStorageWriteable = true;
        } else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            // We can only read the media
            mExternalStorageAvailable = true;
            mExternalStorageWriteable = false;
        } else {
            // Something else is wrong. It may be one of many other states, but
            // all we need to know is we can neither read nor write
            mExternalStorageAvailable = false;
            mExternalStorageWriteable = false;
        }

        return mExternalStorageAvailable && mExternalStorageWriteable;
    }

    public static boolean delete(File path) {
        if (path.exists()) {
            long time = System.currentTimeMillis();
            File newPath = new File(path + "_" + time);
            boolean rt = path.renameTo(newPath);

            if(rt) {
                rt = realDelete(newPath);
            }
            return rt;
        } else {
            Log.e(null, "File does not exist.");
            return false;
        }
    }
    
    private static boolean realDelete(File path) {
        boolean result = true;
        if (path.exists()) {
            if (path.isDirectory()) {
                for (File child : path.listFiles()) {
                    result &= delete(child);
                }
                result &= path.delete(); // Delete empty directory.
            }
            if (path.isFile()) {
                result &= path.delete();
            }
            if (!result) {
                Log.e(null, "Delete failed;");
            }
            return result;
        } else {
            Log.e(null, "File does not exist.");
            return false;
        }
    }
}
