package com.hujiang.hjclass.utils;

import android.os.Build;
import android.os.StrictMode;

import com.hujiang.hjclass.BuildConfig;

/**
 * Created by lvhuacheng on 2015/10/27.
 */
public class StrictModeUtil {

    public static void startStrictMode(){
        if(!BuildConfig.PRINT_LOG){
            return;
        }
        if(android.os.Build.VERSION.SDK_INT <= 9){
            return;
        }
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                .detectDiskReads()
                .detectDiskWrites()
                .detectNetwork()
                .penaltyDialog()
                .penaltyLog()
                .build();
        StrictMode.setThreadPolicy(policy);
    }

}
