package com.hujiang.hjclass.utils;

import java.util.Enumeration;
import java.util.Hashtable;

import android.content.Context;

import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.util.DebugUtils;
import com.loopj.android.http.RequestParams;

/**
 * Created by Gavin on 13-10-14.
 */
public class SyncDataGenerater {

    /**
     * 我的网校每页显示数量
     */
    public static final int MY_CLASS_PER_PAGE = 500;

    /**
     * Lesson List
     * 班级列表
     * @param context
     * @return
     */
    public static RequestParams generateUserInfoParams(Context context) {

        RequestParams requestParams = new RequestParams();
        requestParams.add("action", Constant.ACTION_USER_MESSAGE);

        String token = LoginUtils.getUserToken(context);
        RequestParams subParams = new RequestParams();
        subParams.add("user_agent", DeviceInfo.getUserAgent(context));
        subParams.add("token", token);
//        requestParams.add("data", subParams);
        requestParams.put("data", subParams);
        return requestParams;
//        Hashtable root = new Hashtable();
//        root.put("action", Constant.ACTION_USER_MESSAGE);
//
//
//        String token = LoginUtils.getUserToken(context);
//        Hashtable htable = new Hashtable();
//        htable.put("user_agent", DeviceInfo.getUserAgent(context));
//        htable.put("token", token);
//        root.put("data", htable);
//
//        return root;
    }

    /**
     * 打卡请求
     * 班级列表
     * @param context
     * @return
     */
    public static RequestParams generatePunchParams(Context context, String classID) {
        RequestParams requestParams = new RequestParams();
        requestParams.add("action", Constant.ACTION_PUNCH);

//        Set<String> dataSet = generateOneSubParmas()

//
//        String token = LoginUtils.getUserToken(context);
//        Map<String, String> subParams = new HashMap<String, String>();
//        subParams.put("user_agent", DeviceInfo.getUserAgent(context));
//        subParams.put("class_id", classID);
//        subParams.put("token", token);
////        requestParams.add("data", subParams);
//        requestParams.put("data", subParams);

        DebugUtils.println("params:" + requestParams.toString());
        return requestParams;

//        String token = LoginUtils.getUserToken(context);
//        Hashtable htable = new Hashtable();
//        htable.put("user_agent", DeviceInfo.getUserAgent(context));
//        htable.put("class_id", classID);
//        htable.put("token", token);
//        root.put("data", htable);
//
//        return root;
    }

    /**
     * 暂时自己写参数，是否考虑用JSon lib 暂时不考虑
     *
     * @param htable
     *            key : value value 可以是 Integer, String 简单数据对象 也可以是Hashtable,
     *            这时key是 list
     * @return
     */
    private static String generateJSonParams(Hashtable htable) {
        if (htable == null) {
            return "{}";
        }

        boolean alreadyAddParams = false;
        StringBuffer sb = new StringBuffer();
        sb.append("{");
        Enumeration eeKeys = htable.keys();
        while (eeKeys.hasMoreElements()) {
            if (alreadyAddParams) {
                sb.append(",");
            }
            String key = (String) eeKeys.nextElement();
            Object value = htable.get(key);
            if (value instanceof Hashtable) {
                sb.append("\"list\":[" + generateJSonParams((Hashtable) value) + "]");// 如果参数是List
            } else {
                // if (value instanceof String) {
                String sValue = formatValue(value);
                if (sValue.startsWith("[") && sValue.endsWith("]")) {
                    // aleady is json array
                    sb.append("\"" + key + "\":" + "" + formatValue(value) + "");
                } else {
                    sb.append("\"" + key + "\":" + "\"" + formatValue(value) + "\"");
                }
                // }

            }
            alreadyAddParams = true;// 已经添加过参数，下次会添加 ','
        }

        sb.append("}");
        return sb.toString();
    }


    /**
     * 将value作为转移符编码
     *
     * @param
     * @return
     */
    private static String formatValue(Object obj) {
        String value = "" + obj;
        value = value.replaceAll("\"", "\\\"");
        return value;
    }
}
