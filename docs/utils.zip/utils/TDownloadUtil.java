package com.hujiang.hjclass.utils;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.util.SparseIntArray;

import com.hujiang.hjclass.db.ClassPorvider;
import com.hujiang.hjclass.db.tables.TClassColumns;
import com.hujiang.hjclass.db.tables.TClassDownloadColumns;
import com.hujiang.hjclass.db.tables.TDownloadColumns;
import com.hujiang.hjclass.db.tables.URIList;

public class TDownloadUtil {
    final static int TYPE_INT = 1;
    final static int TYPE_LONG = 2;
    final static int TYPE_STRING = 3;
    Context mContext = null;

    public TDownloadUtil(Context context) {
        mContext = context;
    }
    
    public static void deleteItemByID(Context context, String classId, String lessonId, String userId) {
        try{
            ArrayList<String> selectionList = new ArrayList<String>();
            ArrayList<String> params = new ArrayList<String>();
            if(userId != null) {
                params.add(userId);
                selectionList.add(TClassDownloadColumns.USER_ID);
            }
            if(classId != null) {
                params.add(classId);
                selectionList.add(TClassDownloadColumns.CLASS_ID);
            }
            if(lessonId != null) {
                params.add(lessonId);
                selectionList.add(TClassDownloadColumns.LESSON_ID);
            }
            String[] paramValues = (String[]) params.toArray(new String[params.size()]);
            String selection = "";
            for(int i  = 0; i < selectionList.size(); i ++) {
                selection += selectionList.get(i) + "=?";
                if(i < (selectionList.size() - 1))
                    selection += " and ";
            }

            context.getContentResolver().delete(URIList.TDOWNLOAD_URI, selection, paramValues);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static String getStringByID(Context context, String column, String classId, String lessonId, String userId) {
        String rt = "";
        Object obj = getItemFromDB(TYPE_STRING, context, column, classId, lessonId, userId);
        if(obj != null) {
            rt = (String) obj;
        }
        return rt;        
    }

    public static int getIntByColumn(Context context, String column, String classId, String lessonId, String userId) {
        int rt = -1;
        Object obj = getItemFromDB(TYPE_INT, context, column, classId, lessonId, userId);
        if(obj != null) {
            rt = (Integer) obj;
        }
        return rt;        
    }


    public static long getLongByID(Context context, String column, String classId, String lessonId, String userId) {
        long rt = -1;
        Object obj = getItemFromDB(TYPE_LONG, context, column, classId, lessonId, userId);
        if(obj != null) {
            rt = (Long) obj;
        }
        return rt;        
    }
    private static Object getItemFromDB(int type, Context context,
            String column, String classId, String lessonId, String userId) {
        Object rt = null;
        String[] projection = {
                column,//TDownloadColumns.LESSON_VERSION,
            };
        ArrayList<String> params = new ArrayList<String>();
        ArrayList<String> selectionList = new ArrayList<String>();
        if(userId != null) {
            params.add(userId);
            selectionList.add(TClassDownloadColumns.USER_ID);
        }
        if(classId != null) {
            params.add(classId);
            selectionList.add(TClassDownloadColumns.CLASS_ID);
        }
        if(lessonId != null) {
            params.add(lessonId);
            selectionList.add(TClassDownloadColumns.LESSON_ID);
        }

        String[] paramValues = (String[]) params.toArray(new String[params.size()]);
        String selection = "";
        for(int i  = 0; i < selectionList.size(); i ++) {
            selection += selectionList.get(i) + "=?";
            if(i < (selectionList.size() - 1))
                selection += " and ";
        }
//        debugInfo.loge(new Exception(), "params:" + params.toString());
//        debugInfo.loge(new Exception(), "selection:" + selection);
        
        Cursor c = context.getContentResolver().query(URIList.TDOWNLOAD_URI, projection,
                selection, paramValues, null);
        int count = (c != null) ? c.getCount() : 0;
        if(count > 0) {
            c.moveToFirst();
            switch(type) {
            case TYPE_INT:
                rt = c.getInt(c.getColumnIndexOrThrow(column));
                break;
            case TYPE_LONG:
                rt = c.getLong(c.getColumnIndexOrThrow(column));
                break;
            case TYPE_STRING:
                rt = c.getString(c.getColumnIndexOrThrow(column));
                break;
            }
        }

        if (c != null) {
            c.close();
        }

        return rt;
    }

    private static final int CLASS_ID_FOR_INTRO = 999999;
    public static SparseIntArray getExpiredLessonsArray() {
        SparseIntArray array = new SparseIntArray();
        String sql = "select a." + TClassDownloadColumns.LESSON_ID + " from " + URIList.TABLE_NAME_TCLASS_DOWNLOAD
                + " a left join " + URIList.TABLE_NAME_TCLASS + " b on a." + TClassDownloadColumns.CLASS_ID
                + "=b." + TClassColumns.CLASS_ID + " where a." + TClassDownloadColumns.CLASS_ID + " <> " + CLASS_ID_FOR_INTRO +" and (" + "b." + TClassColumns.CLASS_ID + " is null or b." + TClassColumns.CLASS_KIND + "=2)";
        ClassPorvider provider = new ClassPorvider();
        Cursor c = provider.rawQuery(sql, null);
        int count = (c != null) ? c.getCount() : 0;
        if(count > 0) {
            for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()) {
                String lessonId = c.getString(c.getColumnIndex(TClassDownloadColumns.LESSON_ID));
                Integer id = Integer.parseInt(lessonId);
                array.put(id, id);
//                debugInfo.loge(new Exception(), "array.size():" + array.size());
            }
        }
        return array;
    }
}
