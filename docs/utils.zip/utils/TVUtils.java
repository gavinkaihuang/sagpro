package com.hujiang.hjclass.utils;

import android.content.Context;
import android.util.Log;
import com.hujiang.account.api.AccountRequestWrapper;
import com.hujiang.common.util.DeviceUtils;
import com.hujiang.framework.api.request.BaseAPIRequest;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.util.AppPara;
import com.loopj.android.http.HttpGet;
import org.apache.http.HttpResponse;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

/**
 * Created by rarnu on 3/3/16.
 */
public class TVUtils {


    private static boolean DEBUG = true;

    public interface TVUtilsCallback {
        void onSentDataToTV(String data, boolean result);
    }

    private static final String REQ_TV = "http://%s:%s/hujiang";
    private static final String REQ_TV_PARAM = "act=token&token=%s&userid=%s&username=%s";

    public static void sendDataToTV(final Context ctx, final String data, final TVUtilsCallback callback) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                // ipHost=XX&port=XXX
                String ipKey = "ipHost=";
                String portKey = "&port=";
                /// XX&port=XXX
                String ipAddr = data.substring(data.indexOf(ipKey) + ipKey.length());
                // XXX
                String port = ipAddr.substring(ipAddr.indexOf(portKey) + portKey.length());
                ipAddr = ipAddr.substring(0, ipAddr.indexOf(portKey));
                Log.e("LOG", "sendDataToTV => " + String.format("ip: %s, port: %s", ipAddr, port));
                String token = "";
                if (DEBUG) {
                    token = LoginUtils.getUserToken(ctx);
                } else {
                    token = exchangeToken(ctx);
                    if (token.equals("")) {
                        token = LoginUtils.getUserToken(ctx);
                    }
                }
                String name = LoginUtils.getUsername(ctx);
                String uid = LoginUtils.getUserId(ctx);
                String host = String.format(REQ_TV, ipAddr, port);
                String params = String.format(REQ_TV_PARAM, token, uid, name);
                HttpGet request = new HttpGet(host + "?" + params);
                Log.e("LOG", "sendDataToTV => " + host + "?" + params);
                boolean ret = false;
                try {
                    DefaultHttpClient client = new DefaultHttpClient();
                    HttpResponse response = client.execute(request);
                    int statusCode = response.getStatusLine().getStatusCode();
                    if (statusCode == 200) {
                        ret  = true;
                    }
                } catch (Exception e) {

                }
                if (callback != null) {
                    callback.onSentDataToTV(data, ret);
                }
            }
        }).start();
    }

    public static String exchangeToken(Context ctx) {
        String token = LoginUtils.getUserToken(ctx);

        String host = "https://pass.hjapi.com/v1.1/";
        String action = "account/accesstokenexchange";
        String param = String.format("access_token=%s", token);

        String newToken = "";
        try {
            HttpGet req = new HttpGet(host + action + "?" + param);
            req.addHeader("hj_appkey", AppPara.getLoginKey(ctx));
            Log.e("LOG", "appkey => " + AppPara.getLoginKey(ctx));
            // appsign
            BaseAPIRequest apiReq = new BaseAPIRequest(host, action);
            apiReq.setToken("access_token", token);
            apiReq.addQueryParam("access_token", token);
            AccountRequestWrapper wrapper = new AccountRequestWrapper(apiReq);
            String appsign = (String) wrapper.getWrappedRequest().getHeaders().get("hj_appsign");
            Log.e("LOG", "appsign => " + appsign);
            req.addHeader("hj_appsign", appsign);
            req.addHeader("hj_signmethod", "md5");
            req.addHeader("hj_deviceId", DeviceUtils.getDeviceID(ctx));
            Log.e("LOG", "DeviceId => " + DeviceUtils.getDeviceID(ctx));
            req.addHeader("hj_devicetype", "tv");
            DefaultHttpClient client = new DefaultHttpClient();
            HttpResponse resp = client.execute(req);
            int statusCode = resp.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                String jsonStirng = EntityUtils.toString(resp.getEntity(), HTTP.UTF_8);
                Log.e("LOG", "jsonString => " + jsonStirng);
                JSONObject json = new JSONObject(jsonStirng);
                if (json.getInt("code") == 0) {
                    newToken = json.getJSONObject("data").getString("refresh_token");
                }
            }
        } catch (Exception e) {

        }
        return newToken;
    }

}
