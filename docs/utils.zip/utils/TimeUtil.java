package com.hujiang.hjclass.utils;

import android.content.res.Resources;
import android.text.TextUtils;

import com.hujiang.hjclass.R;

import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by lvhuacheng on 2015/10/27.
 * 时间操作类
 */
public class TimeUtil {

    private static final String TAG = "TimeUtil";

    public static final String PATTERN_DATE = "yyyy-MM-dd";

    public static final String PATTERN_TIME = "yyyy-MM-dd HH:mm:ss";

    public static final String PATTERN_HUJIANG_TIME = "yyyy-MM-dd'T'HH:mm:ssZ";

    /**
     * 把格式化时间转化成毫秒
     * @param timeStr
     * @param pattern
     * @return
     */
    public static long convertTimeToLong(String timeStr, String pattern){
        if(TextUtils.isEmpty(timeStr) || TextUtils.isEmpty(pattern)){
            return 0;
        }
        try{
            SimpleDateFormat formatter = new SimpleDateFormat(pattern);
            Date date = formatter.parse(timeStr);
            return date.getTime();
        }catch (Exception e){
            LogUtil.error(TAG,e);
        }
        return 0;
    }

    /**
     * 把毫秒时间转化成格式化串
     * @param time      时间(毫秒)
     * @param pattern   格式
     * @return
     */
    public static String convertTimeToString(long time, String pattern){
        if(TextUtils.isEmpty(pattern)){
            return null;
        }
        try{
            SimpleDateFormat formatter = new SimpleDateFormat(pattern);
            Date date = new Date(time);
            return formatter.format(date);
        }catch (Exception e){
            LogUtil.error(TAG,e);
        }
        return null;
    }

    /**
     * 把格式化时间转化成日期
     * @param timeStr
     * @param pattern
     * @return
     */
    public static Date convertTimeToDate(String timeStr, String pattern){
        if(TextUtils.isEmpty(timeStr) || TextUtils.isEmpty(pattern)){
            return null;
        }
        try{
            SimpleDateFormat formatter = new SimpleDateFormat(pattern);
            Date date = formatter.parse(timeStr);
            return date;
        }catch (Exception e){
            LogUtil.error(TAG,e);
        }
        return null;
    }

    /**
     * 把毫秒时间转换成日历对象
     * @param time
     * @return
     */
    public static Calendar convertTimeToCalendar(long time){
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(time);
        return calendar;
    }

    /**
     * 把格式化时间转换成日历对象
     * @param timeStr
     * @param pattern
     * @return
     */
    public static Calendar convertTimeToCalendar(String timeStr, String pattern){
        if(TextUtils.isEmpty(timeStr) || TextUtils.isEmpty(pattern)){
            return null;
        }
        try{
            SimpleDateFormat formatter = new SimpleDateFormat(pattern);
            Date date = formatter.parse(timeStr);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            return calendar;
        }catch (Exception e){
            LogUtil.error(TAG,e);
        }
        return null;
    }

    /**
     * 得到系统日期，格式：yyyy-MM-dd
     * @return
     */
    public static String getSystemDate(){
        return getSystemDate(PATTERN_DATE);
    }

    /**
     * 得到系统日期
     * @param pattern 日期格式
     * @return
     */
    public static String getSystemDate(String pattern){
        if(TextUtils.isEmpty(pattern)){
            pattern = PATTERN_DATE;
        }
        return convertTimeToString(System.currentTimeMillis(),pattern);
    }

    /**
     * 得到系统时间,格式："yyyy-MM-dd'T'HH:mm:ssZ"
     * @return
     */
    public static String getSystemTime(){
        return getSystemTime(PATTERN_HUJIANG_TIME);
    }

    /**
     * 得到系统时间串
     * @param pattern 时间串格式
     * @return
     */
    public static String getSystemTime(String pattern){
        if(TextUtils.isEmpty(pattern)){
            pattern = PATTERN_HUJIANG_TIME;
        }
        return convertTimeToString(System.currentTimeMillis(),pattern);
    }

    /**
     * 把沪江标准时间串转换成毫秒
     * 2016-11-04T14:29:30+0800
     * 2016-11-04T14:29:30+08:00
     * @param hjTimeStr
     * @return
     */
    public static long convertHujiangTimeToLong(String hjTimeStr){
        try{
            if(TextUtils.isEmpty(hjTimeStr)){
                return 0;
            }
            return convertTimeToLong(hjTimeStr,PATTERN_HUJIANG_TIME);
        }catch (Exception e){
            LogUtil.error(TAG,e);
        }
        return 0;
    }

    /**
     * 把沪江标准时间串转换成日期对象
     * 2016-11-04T14:29:30+0800
     * 2016-11-04T14:29:30+08:00
     * @param hjTimeStr
     * @return
     */
    public static Date convertHujiangTimeToDate(String hjTimeStr){
        long time = convertHujiangTimeToLong(hjTimeStr);
        if(time <= 0){
            return null;
        }
        return new Date(time);
    }

    /**
     * 把毫秒时间转换成沪江标准时间串
     * @param time
     * @return
     */
    public static String convertToHujiangTime(long time){
        return convertTimeToString(time,PATTERN_HUJIANG_TIME);
    }



    public static String getNowDate() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date curDate = new Date(System.currentTimeMillis());
        return formatter.format(curDate);
    }

    /**
     * 得到输入时间和系统当前时间之间的间隔(以天为单位)
     *
     * @param inputDateStr 输入时间字符串(格式：yyyy-MM-dd)
     * @return
     */
    public static long getDistanceOfDataToTaday(String inputDateStr) {
        if (TextUtils.isEmpty(inputDateStr)) {
            return 0;
        }
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date1 = formatter.parse(inputDateStr);
            Date data2 = formatter.parse(formatter.format(new Date()));
            long l = date1.getTime() - data2.getTime();
            long d = l / (24 * 60 * 60 * 1000);
            return d;
        } catch (ParseException e) {
            LogUtil.error(TAG, e);
        }
        return 0;
    }

    /**
     * 得到当前时间串
     *
     * @return 返回格式: yyyy-MM-dd
     */
    public static String getCurrentDate() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        StringBuffer sb = new StringBuffer();
        sb.append(year).append("-");
        if (month < 10) {
            sb.append("0");
        }
        sb.append(month).append("-");
        if (day < 10) {
            sb.append("0");
        }
        sb.append(day);
        return sb.toString();
    }

    /**
     * 得到当前时间串
     * @param time
     * @return 返回格式: yyyy-MM-dd
     */
    public static String getDateString(long time){
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(time);
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        StringBuffer sb = new StringBuffer();
        sb.append(year).append("-");
        if (month < 10) {
            sb.append("0");
        }
        sb.append(month).append("-");
        if (day < 10) {
            sb.append("0");
        }
        sb.append(day);
        return sb.toString();
    }

    /**
     * 得到时间串inputDateStr1和时间串inputDateStr2之间的间隔天数
     *
     * @param inputDateStr1
     * @param inputDateStr2
     * @return
     */
    public static long getDistanceOfTwoDate(String inputDateStr1, String inputDateStr2) {
        if (TextUtils.isEmpty(inputDateStr1) || TextUtils.isEmpty(inputDateStr2)) {
            return 0;
        }
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date1 = formatter.parse(inputDateStr1);
            Date data2 = formatter.parse(inputDateStr2);
            long l = date1.getTime() - data2.getTime();
            long d = l / (24 * 60 * 60 * 1000);
            return d;
        } catch (ParseException e) {
            LogUtil.error(TAG, e);
        }
        return 0;
    }

    /**
     * 转换输入时间串的格式
     *
     * @param inputDateStr 输入时间字符串
     * @return xxxx年xx月xx日
     */
    public static String convertDateString(String inputDateStr) {
        if (TextUtils.isEmpty(inputDateStr)) {
            return inputDateStr;
        }
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = formatter.parse(inputDateStr);
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(date.getTime());
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH) + 1;
            int day = cal.get(Calendar.DAY_OF_MONTH);
            return year + "年" + month + "月" + day + "日";
        } catch (ParseException e) {
            LogUtil.error(TAG, e);
        }
        return inputDateStr;
    }

    /**
     * 将时间转化为yyyy-MM-dd'T'HH:mm:ssZ格式
     * @param time
     * @return
     */
    public static String convertDateString(long time) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        Date date = new Date(time);
        return formatter.format(date);
    }

    /**
     * 将yyyy-MM-dd'T'HH:mm:ssZ格式时间转化为数值
     * @param inputDateStr
     * @return
     */
    public static long convertDateStringToLong(String inputDateStr) {
        if(TextUtils.isEmpty(inputDateStr)){
            return 0;
        }
        try{
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
            ParsePosition pos = new ParsePosition(0);
            Date strtodate = formatter.parse(inputDateStr, pos);
            return strtodate.getTime();
        }catch (Exception e){
            LogUtil.error(TAG,e);
        }
        return 0;
    }

    /**
     * 判断输入日期是否是系统当前日期
     *
     * @param inputDateStr 输入时间字符串,格式：yyyy-MM-dd
     * @return
     */
    public static boolean isToday(String inputDateStr) {
        if (TextUtils.isEmpty(inputDateStr)) {
            return false;
        }
        String todayDateStr = getCurrentDate();
        if (inputDateStr.equals(todayDateStr)) {
            return true;
        }
        return false;
    }

    /**
     * 判断指定日期是否在本周
     *
     * @param date date
     * @return 是否在本周
     */
    public static boolean isCurrentWeek(String date) {
        String curDate = getCurrentDate();
        return inSameWeek(date,curDate);
    }

    /**
     * 判断连个日期是否在一周(日期格式: yyyy-MM-dd)
     *
     * @param dateStr1
     * @param dateStr2
     * @return
     */
    public static boolean inSameWeek(String dateStr1, String dateStr2) {
        if (TextUtils.isEmpty(dateStr1) || TextUtils.isEmpty(dateStr2)) {
            return false;
        }
        try {
            //两者相差天数
            long distance = getDistanceOfTwoDate(dateStr1, dateStr2);
            if (distance == 0) {
                return true;
            }
            if (Math.abs(distance) >= 7) {
                return false;
            }

            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

            Calendar cal1 = Calendar.getInstance();
            cal1.setFirstDayOfWeek(Calendar.MONDAY);
            cal1.setTimeInMillis(formatter.parse(dateStr1).getTime());

            Calendar cal2 = Calendar.getInstance();
            cal2.setFirstDayOfWeek(Calendar.MONDAY);
            cal2.setTimeInMillis(formatter.parse(dateStr2).getTime());

            if (cal1.get(Calendar.WEEK_OF_YEAR) == cal2.get(Calendar.WEEK_OF_YEAR)) {
                return true;
            }
        } catch (ParseException e) {
            LogUtil.error(TAG, e);
        }
        return false;
    }

    /**
     * 判断是否需要提醒
     *
     * @param graduateDay      距离毕业天数
     * @param class_valid_date 课程有效期
     * @return
     */
    public static boolean needRedRemind(long graduateDay, int class_valid_date) {
        return graduateDay < class_valid_date * 15 / 100;
    }

    /**
     * 计算时间差
     *
     * @param time      秒
     * @param resources
     * @return
     */
    public static String timeDifference(long time, Resources resources) {
        if (resources == null) return "";
        Date date = new Date();
        long timeDifference = date.getTime() / 1000 - time;
        if (timeDifference <= 30) {
            return resources.getString(R.string.rightnow);
        } else if (timeDifference <= 60) {//一分钟前
            return String.format(resources.getString(R.string.before_x_min), 1);
        } else if (timeDifference <= 59 * 60) {
            return String.format(resources.getString(R.string.before_x_min), (int) (timeDifference / 60));
        } else if (timeDifference <= 24 * 59 * 60) {
            return String.format(resources.getString(R.string.before_x_hour), (int) (timeDifference / 60 / 60));
        } else if (timeDifference > 24 * 59 * 60) {
            return String.format(resources.getString(R.string.before_x_day), (int) (timeDifference / 24 / 60 / 60));
        }
        return "";
    }

    /**
     * 得到直播课时间(时分，不同时区)
     * @param inputDateStr
     * @return
     */
    public static String getLiveTime(String inputDateStr){
        long time = TimeUtil.convertDateStringToLong(inputDateStr);
        if(time > 0){
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(time);
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int min = calendar.get(Calendar.MINUTE);
            StringBuffer sb = new StringBuffer();
            if (hour < 10) {
                sb.append("0");
            }
            sb.append(hour).append(":");
            if (min < 10) {
                sb.append("0");
            }
            sb.append(min);
            return sb.toString();
        }
        return null;
    }

    /**
     * 得到直播课日期(月日，不同时区)
     * @param inputDateStr
     * @return
     */
    public static String getLiveDate(String inputDateStr){
        long time = TimeUtil.convertDateStringToLong(inputDateStr);
        if(time > 0){
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(time);
            int month = calendar.get(Calendar.MONTH)+1;
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            return month + "月" + day + "日";
        }
        return null;
    }

}
