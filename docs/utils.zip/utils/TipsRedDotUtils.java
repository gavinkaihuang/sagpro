package com.hujiang.hjclass.utils;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.SharedPreferences;

import com.hujiang.hjclass.MainApplication;

/**
 * 提示红点
 * 
 * @author pengjia
 * 
 */
public class TipsRedDotUtils {
	private static final int SHOW = 1;
	private static final int HIDE = 0;
	private static final String ACTION_SWITCHING_SD_CARD = "switching sdCard";

	private String packName = "com.hujiang.hjclass";
	private static TipsRedDotUtils tipsRedDotUtils = null;
	private SharedPreferences settings;
	private Context app;

	public static List<String> settingTipsRedDot; // 设置下面的红点提示

	private TipsRedDotUtils(Context ctx) {
		app = ctx;
		packName = ctx.getPackageName();
		settings = app.getSharedPreferences(packName, Context.MODE_PRIVATE);
		settingTipsRedDot = new ArrayList<String>();
		initConfig();
	}

	public static TipsRedDotUtils getInstance() {
		if (tipsRedDotUtils == null) {
			tipsRedDotUtils = new TipsRedDotUtils(MainApplication.getContext());
		}
		return tipsRedDotUtils;
	}

	/**
	 * 获取配置以后需要增加更多的红点 此方法需要增加
	 */
	private void initConfig() {
		addList(ACTION_SWITCHING_SD_CARD);
	}

	private void addList(String key) {
		int value = getTipsRedDotConfig(key, SHOW);
		if (value == SHOW) {
			settingTipsRedDot.add(key);
		}

	}

	/**
	 * 主界面返回左侧菜单是否提示红点
	 * 
	 * @return
	 */
	public boolean isShowMemuTips() {
		if (settingTipsRedDot.size() == 0) {
			return false;
		}
		return true;
	}

	/**
	 * 返回左侧菜单菜单下的设置是否显示红点
	 * 
	 * @return
	 */
	public boolean isShowSeetingTips() {
		if (settingTipsRedDot.size() == 0) {
			return false;
		}
		return true;
	}

	/**
	 * 是否显示sd卡切换的红点
	 * 
	 * @return
	 */
	public boolean isShowSeetingSwitchingSDcardRedDot() {
		if (getTipsRedDotConfig(ACTION_SWITCHING_SD_CARD, SHOW) == HIDE)
			return false;
		return true;
	}

	/**
	 * 点击了sd卡选择功能
	 */
	public void onClickSwitchingSDcard() {
		removeRedDot(ACTION_SWITCHING_SD_CARD);
		saveTipsRedDotConfig(ACTION_SWITCHING_SD_CARD, HIDE);
	}

	/**
	 * 移除红点
	 */
	private void removeRedDot(String value) {
		if (settingTipsRedDot.size() == 0) {
			return;
		}
		for (int i = 0; i < settingTipsRedDot.size(); i++) {
			if (settingTipsRedDot.get(i).equals(value)) {
				settingTipsRedDot.remove(i);
			}
		}
	}

	private void refresh() {

	}

	/**
	 * 保存最新的提示红点配置
	 * 
	 * @param json
	 */
	private void saveTipsRedDotConfig(String key, int value) {
		SharedPreferences.Editor editor = settings.edit();
		editor.putInt(key, value);
		editor.commit();
	}

	/**
	 * 获取红点配置
	 * 
	 * @param json
	 */
	private int getTipsRedDotConfig(String key, int defaultValue) {
		return settings.getInt(key, defaultValue);
	}

}
