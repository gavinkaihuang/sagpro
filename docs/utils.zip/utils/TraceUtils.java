/**
 * 
 */
package com.hujiang.hjclass.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.Context;
import android.content.SharedPreferences;

import com.umeng.analytics.MobclickAgent;

/**
 * @author lidongkai
 *
 */
public class TraceUtils {

    //播放器每日启动标志  == 每日听课学员数（打开播放器播放过课程的用户）
    static public void trace_player(Context context) {
        trace_event(context, Constant.HJCLASS_PLAYER_TRACE);
    }

    //体验班每日启动标志
    static public void trace_trial_class(Context context) {
        trace_event(context, Constant.HJCLASS_TRIAL_CLASS_TRACE);
    }

    //销售活动每日启动标志
    static public void trace_marketing_activity(Context context) {
        trace_event(context, Constant.HJCLASS_MARKETING_ACTIVITY_TRACE);
    }

    //消息中心每日启动标志
    static public void trace_message_center(Context context) {
        trace_event(context, Constant.HJCLASS_MESSAGE_CENTER_TRACE);
    }

    //每日登录用户数
    static public void trace_longon_count(Context context) {
        trace_event(context, Constant.HJCLASS_LOGON_COUNT_PER_DAY_TRACE);
    }

    //每日登录学员数（有开过课程的用户（包含免费和收费））
    static public void trace_valid_logon_count(Context context) {
        trace_event(context, Constant.HJCLASS_VALID_LOGON_COUNT_PER_DAY_TRACE);
    }

    static private void trace_event(Context context, String eventName) {
        long now = System.currentTimeMillis();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = new Date(now);
        String str1 = dateFormat.format(date1); 

        long time = getPreference(context, eventName);
        Date date2 = new Date(time);
        String str2 = dateFormat.format(date2); 


        if(!str1.equalsIgnoreCase(str2)) {
            setPreference(context, eventName, now);
            MobclickAgent.onEvent(context, eventName);
        } else {
        }
    }

    static private long getPreference(Context context, String key) {
        SharedPreferences preferences = context.getSharedPreferences(Constant.PRE_SETTING, Context.MODE_PRIVATE);
        long rt = 0;
        if(preferences != null) {
            rt = preferences.getLong(key, 0);
        }
        return rt;
    }

    static private void setPreference(Context context, String key, long value) {
        SharedPreferences preferences = context.getSharedPreferences(Constant.PRE_SETTING, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putLong(key, value);
        editor.commit();
    }
}
