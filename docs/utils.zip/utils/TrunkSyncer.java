package com.hujiang.hjclass.utils;

import android.app.Activity;
import android.os.Handler;

import com.hujiang.hjclass.MainApplication;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.trunk.TrunkFileUtils;
import com.hujiang.util.DebugUtils;

/**
 * Created by Gavin on 13-12-31.
 */
public class TrunkSyncer {

	Activity activity = null;

	public TrunkSyncer(Activity activity) {
		this.activity = activity;
	}

	public void sync() {
		// 1天更新一次
		final String userID = LoginUtils.getUserId(MainApplication.getContext());
		if (!RecordUtils.isNeedReflash(activity, Constant.ACTION_TRUNK_FILE, 1, userID, 1440)) {
			return;
		}

		new Handler().postDelayed(new Runnable() {
			public void run() {
				int result = 0;
				try {

					String userToken = LoginUtils.getUserToken(MainApplication.getContext());

					result = TrunkFileUtils.checkOnLine(MainApplication.getContext(), userToken, userID, true);
					// result = 88020007;
					if (result == 88020007) {
						ClassUtils.showNDKAlertDialog(activity, result);
					} else if (result == 0) {
						DebugUtils.println("NDK result is 0");
					} else {
						// 其他错误信息
					}
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (result == 0) {
						// 同步成功，记录时间
						RecordUtils.saveRequestRecord(activity, Constant.ACTION_TRUNK_FILE, 1, userID);
					}
				}
			}
		}, 1000);
	}
}
