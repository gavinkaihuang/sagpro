/**
 * 
 */
package com.hujiang.hjclass.utils;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;


/**
 * @author lidongkai
 *
 */
public class TrunkTCPUtils {
    final static String HOST = "114.80.167.91";
    final static int PORT = 21577;
    final static long LIMIT = 30000;

    /**
     * @param params
     * @param fileName
     * @return
     */
    static public boolean getTrunkFile(String params, String fileName) {
        // TODO Auto-generated constructor stub
        boolean rt = false;
        final boolean done[] = {false};
        final Socket socket[] = {null};
        try {
            socket[0] = new Socket();
//            socket[0] = new Socket(HOST, PORT);
            InetSocketAddress address = new InetSocketAddress(HOST, PORT);
            socket[0].connect(address, 8000);
            new Thread() {
                public void run() {
                    long start = System.currentTimeMillis();
                    while (!done[0]) {
                        try {
                            long end = System.currentTimeMillis();
                            long duration = end - start;
                            if (duration > LIMIT) {

                                start = System.currentTimeMillis();
                                if (socket[0] != null) {
                                    socket[0].close();
                                }
                                return;
                            }
                            sleep(100);
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }.start();
            DataInputStream is = new DataInputStream(new BufferedInputStream(socket[0].getInputStream()));
            PrintWriter os = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
                    socket[0].getOutputStream())), true);
            if (socket[0].isConnected()) {
                if (!socket[0].isOutputShutdown()) {

                    os.print(params);
                    os.flush();
                    rt = readData(socket[0], is, fileName);
                }
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        } finally {
            if(socket[0] != null) {
                try {
                    socket[0].close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                socket[0] = null;
            }
            done[0] = true;
        }
        return rt;  
    }

    /**
     * @param socket
     * @param is
     * @param fileName
     */
    private static boolean readData(Socket socket, DataInputStream is, String fileName) {
        boolean rt = false;

        if(checkStatus(is)) {
            rt = saveTrunckFile(socket, is,fileName);
        }
        return rt;
    }

    /**
     * @param is
     * @return
     */
    private static boolean checkStatus(DataInputStream is) {

        try {
            Byte b = is.readByte();
            int status = (b & 0xFF);

            if(status != 0) {
                String msg =new String();
                byte[] buffer = new byte[1024];
                int len = 0;
                while((len = is.read(buffer)) != -1){

                }
                msg = String.valueOf(buffer);

                return false;
            } else {
                return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * @param socket
     * @param is
     * @param fileName
     */
    private static boolean saveTrunckFile(Socket socket, DataInputStream is, String fileName) {
        boolean rt = false;
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(fileName);

            byte[] buffer = new byte[1024];
            int len = -1;
            while((len = is.read(buffer)) != -1){

                fos.write(buffer, 0, len);
            }
            rt = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(fos != null) {
                    fos.close();
                }
                is.close();
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return rt;
    }

}
