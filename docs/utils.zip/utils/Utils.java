package com.hujiang.hjclass.utils;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.media.ExifInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Display;

import com.hujiang.hjclass.MainApplication;
import com.hujiang.loginmodule.LoginUtils;
import com.hujiang.preferences.ClassPerferenceChangKey;
import com.hujiang.preferences.ClassPerferenceSmall;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Gavin on 13-10-17.
 */
public class Utils {

	/**
	 * 产生翻页的limit
	 * 
	 * @param pageNo
	 * @param perPageNo
	 * @return
	 */
	public static String generateSqlLimit(int pageNo, int perPageNo) {
		int startNo = caculatorCoursorPosition(pageNo, perPageNo);
		// String value = " limit " + perPageNo + " , " + startNo;
		String value = startNo + "," + perPageNo;
		return value;
	}

	public static String generateSqlLimitContainPreRecord(int pageNo, int perPageNo) {
		int startNo = caculatorCoursorPosition(pageNo, perPageNo);
		// String value = " limit " + perPageNo + " , " + startNo;
		int endNo = startNo + perPageNo;
		String value = 0 + "," + endNo;
		return value;
	}

	/**
	 * 计算翻页的时候，当前页的偏移量
	 * 
	 * @param pageNo
	 * @param perPageNo
	 * @return
	 */
	public static int caculatorCoursorPosition(int pageNo, int perPageNo) {

		int no = (pageNo - 1) * perPageNo;
		if (no <= 0)
			return 0;
		return no;
	}

	public static String getVersionName(Context context) {
		PackageManager pm = context.getPackageManager();
		PackageInfo info = null;
		String versionName = "3.0.0";
		try {
			info = pm.getPackageInfo(context.getPackageName(), 0);
		} catch (PackageManager.NameNotFoundException e) {
			e.printStackTrace();
		}
		if (info != null) {
			versionName = String.valueOf(info.versionName);
		}
		return versionName;
	}

	public static String getVersionCode(Context context) {
		PackageManager pm = context.getPackageManager();
		PackageInfo info = null;
		String versionCode = "0";
		try {
			info = pm.getPackageInfo(context.getPackageName(), 0);
		} catch (PackageManager.NameNotFoundException e) {
			e.printStackTrace();
		}
		if (info != null) {
			versionCode = String.valueOf(info.versionCode);
		}
		return versionCode;
	}

	public static String format(String str, Object... args) {
		// 这里用于验证数据有效性
		if (str == null || "".equals(str))
			return "";
		if (args.length == 0) {
			return str;
		}
		String result = str;
		Pattern p = Pattern.compile("\\{(\\d+)\\}");
		Matcher m = p.matcher(str);

		while (m.find()) {
			int index = Integer.parseInt(m.group(1));

			if (index < args.length) {
				result = result.replace(m.group(), args[index].toString());
			}
		}
		return result;
	}

	public static long dateFormatStringToLong(String classEndTime) {
		long time = 0;
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			time = df.parse(classEndTime + " 00:00:00").getTime();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return time;
	}

	public static Date stringToDateShort(String dateString) {
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		try {
			date = formatDate.parse(dateString);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return date;
	}

	/**
	 * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
	 */
	public static int dip2px(Context context, float dpValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dpValue * scale + 0.5f);
	}

	/**
	 * 根据手机的分辨率从 px(像素) 的单位 转成为 dp
	 */
	public static int px2dip(Context context, float pxValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (pxValue / scale + 0.5f);
	}

	public static boolean isNetworkAvailable(Context ctx) {
		if (ctx == null)
			return false;
		ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm == null) {
			return false;
		}
		NetworkInfo[] netinfo = cm.getAllNetworkInfo();
		if (netinfo == null) {
			return false;
		}
		for (int i = 0; i < netinfo.length; i++) {
			if (netinfo[i].isConnected()) {
				return true;
			}
		}
		return false;
	}

	public static boolean isMobileNO(String mobiles) {
		String expression = "(^(1)[0-9]{10}$)";
		Pattern p = Pattern.compile(expression);
		Matcher m = p.matcher(mobiles);
		return m.matches();
	}

	public static LinkedList<String> string2LinkedList(String x){
		String[] split = x.split(",");
		LinkedList<String> linkedList = new LinkedList<String>();
		for (int i = 0; i < split.length; i++) {
			String word = split[i];
			if(!TextUtils.isEmpty(word)){
				if(linkedList.contains(word)){
					linkedList.remove(word);
					linkedList.addFirst(word);
				}else{
					linkedList.add(word);
				}
			}
		}
		return linkedList;
	}

	public static String linkedlist2String(LinkedList<String> list){
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			String first = list.get(i);
			if(i == list.size() - 1){
				sb.append(first);
			}else{
				sb.append(first+",");
			}
		}
		return sb.toString();
	}

	public static String encodeToBase64(String path) {
		byte[] soundBytes = getBytesFromFile(new File(path));
		if(soundBytes == null){
			return "";
		}
		byte[] bytes = Base64.encode(soundBytes, Base64.DEFAULT);
		return new String(bytes);
	}

	public static byte[] getBytesFromFile(File f) {
		FileInputStream stream = null;
		ByteArrayOutputStream out = null;
		try {
			stream = new FileInputStream(f);
			out = new ByteArrayOutputStream();
			byte[] b = new byte[1024];
			int n;
			while ((n = stream.read(b)) != -1) {
				out.write(b, 0, n);
			}
			return out.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (out != null) {
					out.close();
				}
			} catch (Exception e2) {
			}
		}
		return null;
	}

	/**
	 * 将一个list分隔为pageSize个list
	 * @param list		源list
	 * @param newListSize	目标list.size()
	 * @param <T>		list中的元素类型
	 * @return
	 */
	public static <T> List<List<T>> splitList(List<T> list, int newListSize) {
		List<List<T>> targetLists = new ArrayList<List<T>>();
		ArrayList<T> al = new ArrayList<T>();
		int sourceListSize = list.size();
		for (int i = 0; i < sourceListSize; i++) {
			T x = list.get(i);
			al.add(x);
			if (newListSize == al.size()){
				targetLists.add(al);
				al = new ArrayList<T>();
			}
		}

		if (al.size() != 0){
			targetLists.add(al);
		}

		return targetLists;
	}

	/**
	 * string 转 list<String> 以splitRegex为分隔符</>
	 * @param str
	 * @param splitRegex
	 * @return
	 */
	public static List<String> string2list(String str, String splitRegex){
		try {
			String[] split = str.split(splitRegex);
			List<String> asList = Arrays.asList(split);
			return asList;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * list转string,以splitRegex为分隔符
	 * @param list
	 * @param splitRegex
	 * @return
	 */
	public static <T> String list2String(List<T> list, String splitRegex){
		StringBuilder sb = new StringBuilder();
		int size = list.size();
		for (int i = 0; i < size; i++) {
			T obj = list.get(i);
			String str = "";
			if(obj instanceof String){
				str = (String) obj;
			}else{
				str = GsonUtil.objectToJson(obj);
			}
			if(i == size - 1){
				sb.append(str);
				break;
			}
			sb.append(str+splitRegex);
		}
		return sb.toString();
	}

	/**
	 * string 转 list<String> 以splitRegex为分隔符</>
	 * @param str
	 * @param splitRegex
	 * @return
	 */
	public static <T> List<T> string2list(String str, Class<T> classOfT, String splitRegex){
		try {
			ArrayList<T> al = new ArrayList<T>();
			String[] split = str.split(splitRegex);
			for (int i = 0; i < split.length; i++) {
				al.add(GsonUtil.jsonToObject(split[i], classOfT));
			}
			return al;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}


	public static boolean isKeyBoardShow(Activity paramActivity) {
		int height = getScreenHeight(paramActivity) - getStatusBarHeight(paramActivity) - getAppHeight(paramActivity);
		return height != 0;
	}

	public static int getAppHeight(Activity paramActivity) {
		Rect localRect = new Rect();
		paramActivity.getWindow().getDecorView().getWindowVisibleDisplayFrame(localRect);
		return localRect.height();
	}

	public static int getScreenHeight(Activity paramActivity) {
		Display display = paramActivity.getWindowManager().getDefaultDisplay();
		DisplayMetrics metrics = new DisplayMetrics();
		display.getMetrics(metrics);
		return metrics.heightPixels;
	}

	public static int getStatusBarHeight(Activity paramActivity) {
		Rect localRect = new Rect();
		paramActivity.getWindow().getDecorView().getWindowVisibleDisplayFrame(localRect);
		return localRect.top;

	}

	public static int getKeyboardHeight(Activity paramActivity) {
		return getScreenHeight(paramActivity) - getStatusBarHeight(paramActivity) - getAppHeight(paramActivity);
	}

	/**
	 * Try to return the absolute file path from the given Uri
	 *
	 * @param context
	 * @param uri
	 * @return the file path or null
	 */
	public static String getPhotoPath(Uri uri, Context context) {
		try {
			if (null == uri)
                return null;
			final String scheme = uri.getScheme();
			String data = null;
			if (scheme == null)
                data = uri.getPath();
            else if (ContentResolver.SCHEME_FILE.equals(scheme)) {
                data = uri.getPath();
            } else if (ContentResolver.SCHEME_CONTENT.equals(scheme)) {
                Cursor cursor = context.getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.DATA}, null, null, null);
                if (null != cursor) {
                    if (cursor.moveToFirst()) {
                        int index = cursor.getColumnIndex(MediaStore.MediaColumns.DATA);
                        if (index > -1) {
                            data = cursor.getString(index);
                        }
                    }
                    cursor.close();
                }
            }
			return data;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static int[] getIntArrayFromStr(String string){
		if (TextUtils.isEmpty(string))return null;
		int[] temple = new int[2];
		if (string.contains("/")){
			String[] splitStr = string.split("/");
			if (splitStr != null && splitStr.length > 0){
				try {
					temple[0] = Integer.parseInt(splitStr[0]);
					temple[1] = Integer.parseInt(splitStr[1]);

					return temple;
				}catch (Exception e){
					e.printStackTrace();
					return null;
				}
			}
		}
		return null;
	}


	public static String thirdCompress(String sourceFilePath, String targetFilePath) {
		try {
			double size;
			String filePath = sourceFilePath;
			File file = new File(filePath);
			LogUtil.error("thirdCompress", "thirdCompress sourceFilePath: "+filePath + ", targetFilePath : "+targetFilePath);
			int angle = getImageSpinAngle(filePath);
			int width = getImageSize(filePath)[0];
			int height = getImageSize(filePath)[1];
			int thumbW = width % 2 == 1 ? width + 1 : width;
			int thumbH = height % 2 == 1 ? height + 1 : height;

			width = thumbW > thumbH ? thumbH : thumbW;
			height = thumbW > thumbH ? thumbW : thumbH;

			double scale = ((double) width / height);

			if (scale <= 1 && scale > 0.5625) {
                if (height < 1664) {
                    if (file.length() / 1024 < 150) {
                        LogUtil.error("thirdCompress", "thirdCompress return scale <= 1 && scale > 0.5625: and height < 1664 and file.length() / 1024 < 150 no compressed path : "+filePath);
                        return filePath;
                    }

                    size = (width * height) / Math.pow(1664, 2) * 150;
                    size = size < 60 ? 60 : size;
                } else if (height >= 1664 && height < 4990) {
                    thumbW = width / 2;
                    thumbH = height / 2;
                    size = (thumbW * thumbH) / Math.pow(2495, 2) * 300;
                    size = size < 60 ? 60 : size;
                } else if (height >= 4990 && height < 10240) {
                    thumbW = width / 4;
                    thumbH = height / 4;
                    size = (thumbW * thumbH) / Math.pow(2560, 2) * 300;
                    size = size < 100 ? 100 : size;
                } else {
                    int multiple = height / 1280 == 0 ? 1 : height / 1280;
                    thumbW = width / multiple;
                    thumbH = height / multiple;
                    size = (thumbW * thumbH) / Math.pow(2560, 2) * 300;
                    size = size < 100 ? 100 : size;
                }
            } else if (scale <= 0.5625 && scale > 0.5) {
                if (height < 1280 && file.length() / 1024 < 200) {
                    LogUtil.error("thirdCompress", "thirdCompress return scale <= 0.5625 && scale > 0.5  and height < 1280 && file.length() / 1024 < 200 no compressed path : "+filePath);
                    return filePath;
                }

                int multiple = height / 1280 == 0 ? 1 : height / 1280;
                thumbW = width / multiple;
                thumbH = height / multiple;
                size = (thumbW * thumbH) / (1440.0 * 2560.0) * 400;
                size = size < 100 ? 100 : size;
            } else {
                int multiple = (int) Math.ceil(height / (1280.0 / scale));
                thumbW = width / multiple;
                thumbH = height / multiple;
                size = ((thumbW * thumbH) / (1280.0 * (1280 / scale))) * 500;
                size = size < 100 ? 100 : size;
            }
			return compress(filePath, targetFilePath, thumbW, thumbH, angle, (long) size);
		} catch (Exception e) {
			e.printStackTrace();
			LogUtil.error("thirdCompress", e.toString());
		}
		LogUtil.error("thirdCompress", "thirdCompress has exception return sourceFilePath : "+sourceFilePath);
		return sourceFilePath;
	}


	/**
	 * obtain the image rotation angle
	 *
	 * @param path path of target image
	 */
	private static int getImageSpinAngle(String path) {
		int degree = 0;
		try {
			ExifInterface exifInterface = new ExifInterface(path);
			int orientation = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
			switch (orientation) {
				case ExifInterface.ORIENTATION_ROTATE_90:
					degree = 90;
					break;
				case ExifInterface.ORIENTATION_ROTATE_180:
					degree = 180;
					break;
				case ExifInterface.ORIENTATION_ROTATE_270:
					degree = 270;
					break;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return degree;
	}

	/**
	 * obtain the image's width and height
	 *
	 * @param imagePath the path of image
	 */
	public static int[] getImageSize(String imagePath) {
		int[] res = new int[2];
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		options.inSampleSize = 1;
		BitmapFactory.decodeFile(imagePath, options);

		res[0] = options.outWidth;
		res[1] = options.outHeight;
		return res;
	}

	/**
	 * obtain the thumbnail that specify the size
	 *
	 * @param imagePath the target image path
	 * @param width     the width of thumbnail
	 * @param height    the height of thumbnail
	 * @return {@link Bitmap}
	 */
	private static Bitmap compress(String imagePath, int width, int height) {
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeFile(imagePath, options);

		int outH = options.outHeight;
		int outW = options.outWidth;
		int inSampleSize = 1;

		if (outH > height || outW > width) {
			int halfH = outH / 2;
			int halfW = outW / 2;

			while ((halfH / inSampleSize) > height && (halfW / inSampleSize) > width) {
				inSampleSize *= 2;
			}
		}

		options.inSampleSize = inSampleSize;

		options.inJustDecodeBounds = false;

		int heightRatio = (int) Math.ceil(options.outHeight / (float) height);
		int widthRatio = (int) Math.ceil(options.outWidth / (float) width);

		if (heightRatio > 1 || widthRatio > 1) {
			if (heightRatio > widthRatio) {
				options.inSampleSize = heightRatio;
			} else {
				options.inSampleSize = widthRatio;
			}
		}
		options.inJustDecodeBounds = false;

		return BitmapFactory.decodeFile(imagePath, options);
	}

	/**
	 * 指定参数压缩图片
	 * create the thumbnail with the true rotate angle
	 *
	 * @param largeImagePath the big image path
	 * @param thumbFilePath  the thumbnail path
	 * @param width          width of thumbnail
	 * @param height         height of thumbnail
	 * @param angle          rotation angle of thumbnail
	 * @param size           the file size of image
	 */
	private static String compress(String largeImagePath, String thumbFilePath, int width, int height, int angle, long size) {
		Bitmap thbBitmap = compress(largeImagePath, width, height);
		thbBitmap = rotatingImage(angle, thbBitmap);
		return saveImage(thumbFilePath, thbBitmap, size);
	}

	/**
	 * 旋转图片
	 * rotate the image with specified angle
	 *
	 * @param angle  the angle will be rotating 旋转的角度
	 * @param bitmap target image               目标图片
	 */
	private static Bitmap rotatingImage(int angle, Bitmap bitmap) {
		//rotate image
		Matrix matrix = new Matrix();
		matrix.postRotate(angle);

		//create a new image
		return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
	}

	/**
	 * 保存图片到指定路径
	 * Save image with specified size
	 *
	 * @param filePath the image file save path 储存路径
	 * @param bitmap   the image what be save   目标图片
	 * @param size     the file size of image   期望大小
	 */
	private static String saveImage(String filePath, Bitmap bitmap, long size) {
		File result = new File(filePath.substring(0, filePath.lastIndexOf("/")));

		if (!result.exists() && !result.mkdirs()) return filePath;

		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		int options = 100;
		bitmap.compress(Bitmap.CompressFormat.JPEG, options, stream);

		while (stream.toByteArray().length / 1024 > size && options > 6) {
			stream.reset();
			options -= 6;
			bitmap.compress(Bitmap.CompressFormat.JPEG, options, stream);
		}

		try {
			FileOutputStream fos = new FileOutputStream(filePath);
			fos.write(stream.toByteArray());
			fos.flush();
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		LogUtil.error("thirdCompress", "return compressed path : "+filePath);
		return filePath;
	}

	/**
	 * 队列比较
	 * @param a	list a
	 * @param b	list b
	 * @return	true 相同, false 不同
	 */
	public static <T> boolean compareListsSameOrNot(List<T> a, List<T> b) {
		if (a == null || b == null){
			return false;
		}
		if (a.size() != b.size())
			return false;
		for (int i = 0; i < a.size(); i++) {
			if (!b.contains(a.get(i))){
				LogUtil.error("compareListsSameOrNot", "compareListsSameOrNot: b do not contain a's"+a.get(i));
				return false;
			}
		}
		LogUtil.error("compareListsSameOrNot", "compareListsSameOrNot: a  b is same");
		return true;
	}

	public static void setArticleTaskDone(boolean done){
		String taskDone = TimeUtil.getNowDate()+"," + (done ? "1" : "0");
		LogUtil.error("setArticleTaskDone","class_article_detail : article task done : "+taskDone);
		ClassPerferenceSmall.getInstance(MainApplication.getContext()).saveSharedString(ClassPerferenceChangKey.getTaskCardDataKey(LoginUtils.getUserId()), taskDone);
	}
}
