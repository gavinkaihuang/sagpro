package com.hujiang.hjclass.utils;

import android.os.Build;
import android.view.View;

/**
 * Created by lvhuacheng on 2015/7/23.
 * 用于去除View下拉悬停效果,例如：ListView、ScrollView、GridView
 */
public class ViewOverScrollModeUtil {

    /**
     * 禁止View的下拉悬停效果
     * @param view
     */
    public static void forbidViewOverScroll(View view){
        if(view == null){
            return;
        }
        if(Build.VERSION.SDK_INT < 11){
            return;
        }
        view.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }
}
