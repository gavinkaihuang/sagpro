package com.hujiang.hjclass.utils;

import android.view.View;

/**
 * Created by lvhuacheng on 2016/12/7.
 */

public class ViewUtils {

    public static boolean pointInView(View view, int pointX, int pointY){
        if(view == null || view.getVisibility() != View.VISIBLE){
            return false;
        }
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        if(pointX < location[0] || pointX > (location[0] + view.getWidth())){
            return false;
        }
        if(pointY < location[1] || pointY > (location[1] + view.getHeight())){
            return false;
        }
        return true;
    }

}
