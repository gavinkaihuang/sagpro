package com.hujiang.hjclass.utils.network;

/**
 * 网络请求callback
 */
public interface RequestCallback<T> {

    /**
     * 业务成功
     *
     * @param result
     */
    void onSuccess(ResponseResult<T> result);

    /**
     * 业务失败
     *
     * @param result
     */
    void onFailed(ResponseResult<T> result);
}
