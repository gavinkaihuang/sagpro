package com.hujiang.hjclass.utils.network;

import android.text.TextUtils;

import com.google.gson.Gson;
import com.hujiang.hjclass.utils.LogUtil;
import com.hujiang.hjclass.utils.ServerConnecter;
import com.hujiang.util.DebugUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by wyiyong on 14/12/20.
 */
public class RequestController {

    private static RequestController _requestController;
    private Gson gson;
    /**BI http request start time*/
    private long startTime;

    private RequestController() {
        gson = new Gson();
    }

    public static RequestController getInstance() {
        if (_requestController == null) {
            _requestController = new RequestController();
        }

        return _requestController;
    }

    public <T> void request(String URL, HashMap<String, String> params, final Type classType, final RequestCallback<T> callback) {
        try {
            String jsonString = ServerConnecter.requestByGet(joinUrl(URL, params));
            LogUtil.error("RequestController","jsonString : "+jsonString);
            if (TextUtils.isEmpty(jsonString)) {
                throw new JSONException("response null");
            }
            ResponseResult<T> result = new ResponseResult<T>();
            result.setResultStr(jsonString);
            JSONObject a = new JSONObject(jsonString);
            result.setStatus(a.getInt("status"));
            result.setMessage(a.getString("message"));
            if (classType != null && a.has("content")) {
                String d = a.getString("content");
                if (!TextUtils.isEmpty(d)) {
                    T t = gson.<T>fromJson(d, classType);
                    result.setData(t);
                }
            }
            if (callback != null) {
                callback.onSuccess(result);
            }
        } catch (JSONException e) {
            ResponseResult<T> result = new ResponseResult<T>();
            result.setParseFailed(e.getMessage());

            if (callback != null) {
                callback.onFailed(result);
            }
        } catch (Exception e) {
            ResponseResult<T> result = new ResponseResult<T>();
            result.setNetworkFailed(e.getMessage());

            if (callback != null) {
                callback.onFailed(result);
            }
        }
    }

    private String joinUrl(String url, HashMap<String, String> params) {
        if (url == null || params == null || params.size() == 0) {
            DebugUtils.d(url);
            return url;
        }
        String paramsStr = encodeParameters(params, "utf-8");

        if (!url.endsWith("?")) {
            url = url + "?" + paramsStr;
        } else {
            url = url + "&" + paramsStr;
        }

        LogUtil.error("requestController","request url :"+url);

        return url;
    }

    private String encodeParameters(Map<String, String> params, String paramsEncoding) {
        if (params == null || params.size() == 0) {
            return "";
        }
        StringBuilder encodedParams = new StringBuilder();
        try {
            for (Map.Entry<String, String> entry : params.entrySet()) {
                if (entry.getValue() == null) {
                    continue;
                }
                encodedParams.append(URLEncoder.encode(entry.getKey(), paramsEncoding));
                encodedParams.append('=');
                encodedParams.append(URLEncoder.encode(entry.getValue(), paramsEncoding));
                encodedParams.append('&');
            }
            return encodedParams.toString();
        } catch (UnsupportedEncodingException uee) {
            throw new RuntimeException("Encoding not supported: " + paramsEncoding, uee);
        }
    }
}
