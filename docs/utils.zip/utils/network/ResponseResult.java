package com.hujiang.hjclass.utils.network;

import java.io.Serializable;

public class ResponseResult<T> implements Serializable {

    private static final long serialVersionUID = -8975114609117986913L;

    private static final int CODE_OK = 0;
    private static final int CODE_PARSE_ERR = -99;
    private static final int CODE_NETWORK_ERR = -9999;

    private String resultStr;

    private int status;
    private String message;

    private T data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setParseFailed(String errorMsg) {
        this.status = CODE_PARSE_ERR;
        this.message = errorMsg;
    }

    public boolean isParseFailed() {
        return CODE_PARSE_ERR == status;
    }

    public void setNetworkFailed(String errorMsg) {
        this.status = CODE_NETWORK_ERR;
        this.message = errorMsg;
    }

    public boolean isNetworkFailed() {
        return CODE_NETWORK_ERR == status;
    }

    public boolean isOK() {
        return CODE_OK == status;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getResultStr() {
        return resultStr;
    }

    public void setResultStr(String jsonStr) {
        this.resultStr = jsonStr;
    }
}

